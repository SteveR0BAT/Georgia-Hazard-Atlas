import { chromium } from 'playwright';
const browser = await chromium.launch();
const errors=[];
const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
page.on('pageerror', e=>errors.push('PAGEERROR: '+e.message));
page.on('console', m=>{ if(m.type()==='error') errors.push(m.text()) });
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
await page.screenshot({ path: '/home/user/sandbox/qa-desktop.png' });
// zoom in twice
await page.getByRole('button', { name: 'Zoom in' }).click();
await page.waitForTimeout(300);
await page.screenshot({ path: '/home/user/sandbox/qa-zoom.png' });
// regions silhouette
await page.getByRole('button', { name: 'Regions' }).first().click();
await page.waitForTimeout(500);
await page.screenshot({ path: '/home/user/sandbox/qa-regions.png' });
// search dialog
await page.getByRole('button', { name: 'Search' }).first().click();
await page.waitForTimeout(300);
await page.locator('input[placeholder]').last().fill('Keda');
await page.waitForTimeout(300);
await page.screenshot({ path: '/home/user/sandbox/qa-search.png' });
await page.keyboard.press('Escape');
// emergency panel
await page.locator('header').getByRole('button', { name: /Emergency info/i }).click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-emergency.png' });
await page.keyboard.press('Escape');
// Georgian language
await page.getByRole('button', { name: 'ქა' }).click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-georgian.png' });
// mobile
const m = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
m.on('pageerror', e=>errors.push('MOBILE PAGEERROR: '+e.message));
await m.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await m.waitForTimeout(500);
await m.screenshot({ path: '/home/user/sandbox/qa-mobile.png' });
await m.evaluate(()=>window.scrollTo(0, 700));
await m.waitForTimeout(300);
await m.screenshot({ path: '/home/user/sandbox/qa-mobile2.png' });
console.log('errors', errors.slice(0,8));
await browser.close();
