import type { HazardZone } from "../types";

/**
 * Generalized susceptibility corridors compiled from national hazard mapping and
 * published regional descriptions. They are deliberately coarse. A zone is NOT a
 * forecast, an alert, or proof that a disaster occurred at a particular point.
 */
export const ZONES: HazardZone[] = [
  {
    id: "greater-caucasus-seismic",
    hazard: "earthquake",
    name: { en: "Greater Caucasus seismic belt", ka: "დიდი კავკასიონის სეისმური სარტყელი" },
    strength: "higher",
    labelAt: [43.4, 42.85],
    polygon: [
      [40.1, 43.35], [41.1, 43.32], [42.0, 43.22], [42.8, 43.02], [43.6, 42.78],
      [44.4, 42.63], [45.2, 42.55], [46.25, 42.18], [46.45, 42.02], [45.35, 42.28],
      [44.4, 42.42], [43.6, 42.52], [42.8, 42.72], [42.0, 42.95], [41.15, 43.05],
      [40.2, 43.12],
    ],
    note: {
      en: "Active thrust belt; includes the 1991 Racha epicentral area. Broad zone only.",
      ka: "აქტიური აქცევითი სარტყელი; მოიცავს 1991 წლის რაჭის ეპიცენტრს. მხოლოდ განზოგადებული ზონა.",
    },
  },
  {
    id: "adjara-trialeti-seismic",
    hazard: "earthquake",
    name: { en: "Adjara–Trialeti seismic zone", ka: "აჭარა–თრიალეთის სეისმური ზონა" },
    strength: "higher",
    labelAt: [42.55, 41.82],
    polygon: [
      [41.35, 41.48], [42.0, 41.58], [42.6, 41.75], [43.2, 41.82], [43.7, 41.65],
      [43.25, 41.63], [42.6, 41.68], [42.0, 41.5], [41.45, 41.38],
    ],
    note: {
      en: "Fault system linking Adjara with the Trialeti range; includes the 2002 Tbilisi epicentre area.",
      ka: "რღვევათა სისტემა აჭარასა და თრიალეთის ქედს შორის; მოიცავს 2002 წლის თბილისის ეპიცენტრს.",
    },
  },
  {
    id: "javakheti-seismic",
    hazard: "earthquake",
    name: { en: "Javakheti plateau seismic zone", ka: "ჯავახეთის პლატოს სეისმური ზონა" },
    strength: "higher",
    labelAt: [43.45, 41.35],
    polygon: [
      [42.75, 41.2], [43.3, 41.08], [44.0, 41.12], [44.15, 41.5], [43.55, 41.65], [42.9, 41.55],
    ],
    note: {
      en: "Volcanic plateau crossed by active faults; local site effects are not resolved at this scale.",
      ka: "ვულკანური პლატო აქტიური რღვევებით; ლოკალური ნიადაგური ეფექტები ამ მასშტაბზე არ ჩანს.",
    },
  },
  {
    id: "adjara-guria-landslide",
    hazard: "landslide",
    name: { en: "Adjara–Guria landslide and mudflow belt", ka: "აჭარა–გურიის მეწყერ-ღვარცოფის სარტყელი" },
    strength: "higher",
    labelAt: [41.75, 41.9],
    polygon: [
      [41.35, 41.5], [42.0, 41.55], [42.6, 41.72], [42.7, 42.1], [42.4, 42.42],
      [41.9, 42.32], [41.5, 42.05], [41.28, 41.8],
    ],
    note: {
      en: "Extremely wet, steep terrain with a dense documented landslide and mudflow inventory.",
      ka: "უკიდურესად ნოტიო, ციცაბო რელიეფი მეწყრებისა და ღვარცოფების მდიდარი აღრიცხვით.",
    },
  },
  {
    id: "racha-svaneti-landslide",
    hazard: "landslide",
    name: { en: "Racha–Svaneti mass-movement corridor", ka: "რაჭა–სვანეთის გრავიტაციური პროცესების დერეფანი" },
    strength: "higher",
    labelAt: [42.65, 42.85],
    polygon: [
      [41.8, 42.72], [42.4, 42.6], [43.0, 42.68], [43.7, 42.6], [43.95, 42.9],
      [43.35, 43.08], [42.6, 43.2], [42.02, 43.0],
    ],
    note: {
      en: "Steep glacial valleys; Shovi (2023) and many smaller debris flows are recorded here.",
      ka: "ციცაბო მყინვარული ხეობები; აქ დაფიქსირდა შოვი (2023) და მრავალი მცირე ღვარცოფი.",
    },
  },
  {
    id: "tkibuli-chiatura-landslide",
    hazard: "landslide",
    name: { en: "Imereti upland landslide cluster", ka: "იმერეთის მაღლობის მეწყრული კერა" },
    strength: "moderate",
    labelAt: [43.0, 42.34],
    polygon: [
      [42.7, 42.15], [43.05, 42.12], [43.5, 42.25], [43.55, 42.42], [43.15, 42.55], [42.75, 42.4],
    ],
    note: {
      en: "Tkibuli, Chiatura and Terjola municipalities report recurrent landslides damaging homes and roads.",
      ka: "ტყიბულის, ჭიათურისა და თერჯოლის მუნიციპალიტეტებში ხშირია სახლებისა და გზების დამაზიანებელი მეწყრები.",
    },
  },
  {
    id: "vere-flash-flood",
    hazard: "flood",
    name: { en: "Tbilisi–Vere flash-flood corridor", ka: "თბილისი–ვერეს მყისიერი წყალდიდობის დერეფანი" },
    strength: "higher",
    labelAt: [44.76, 41.77],
    polygon: [
      [44.62, 41.65], [44.82, 41.65], [44.92, 41.75], [44.7, 41.82], [44.54, 41.79],
    ],
    note: {
      en: "Very small, steep catchment. Intense rain can generate a debris flood within minutes (2015).",
      ka: "ძალიან პატარა, ციცაბო აუზი. ინტენსიური წვიმა წუთებში ღვარცოფულ წყალდიდობას იწვევს (2015).",
    },
  },
  {
    id: "rioni-floodplain",
    hazard: "flood",
    name: { en: "Rioni river floodplain", ka: "რიონის მდინარის დაჭალა" },
    strength: "moderate",
    labelAt: [42.3, 42.2],
    polygon: [
      [41.55, 42.1], [42.0, 42.18], [42.5, 42.15], [42.82, 42.35], [42.7, 42.6],
      [42.2, 42.75], [41.75, 42.55], [41.55, 42.35],
    ],
    note: {
      en: "Low-lying Kutaisi, Samtredia and Poti districts; riverine and compound flood exposure.",
      ka: "ქუთაისის, სამტრედიისა და ფოთის დაბლობი რაიონები; მდინარისა და კომბინირებული წყალდიდობის რისკი.",
    },
  },
  {
    id: "mtkvari-floodplain",
    hazard: "flood",
    name: { en: "Mtkvari (Kura) floodplain", ka: "მტკვრის დაჭალა" },
    strength: "moderate",
    labelAt: [44.3, 41.75],
    polygon: [
      [42.85, 41.45], [43.35, 41.58], [44.0, 41.68], [44.8, 41.62], [45.25, 41.4],
      [45.5, 41.45], [44.95, 41.8], [44.0, 41.92], [43.4, 41.88], [42.95, 41.7],
    ],
    note: {
      en: "Urban and agricultural floodplain from Akhaltsikhe through Gori and Tbilisi to Rustavi.",
      ka: "ურბანული და სასოფლო-სამეურნეო დაჭალა ახალციხიდან გორისა და თბილისის გავლით რუსთავამდე.",
    },
  },
  {
    id: "high-caucasus-avalanche",
    hazard: "avalanche",
    name: { en: "High Caucasus avalanche terrain", ka: "მაღალი კავკასიონის ზვავსაშიში რელიეფი" },
    strength: "higher",
    labelAt: [43.5, 42.45],
    polygon: [
      [41.5, 42.9], [42.4, 42.72], [43.3, 42.58], [44.3, 42.42], [45.5, 42.32],
      [46.05, 42.24], [45.2, 42.08], [44.2, 42.22], [43.2, 42.34], [42.3, 42.5], [41.6, 42.72],
    ],
    note: {
      en: "Svaneti, Racha, Kazbegi and Tusheti: deep snow and road exposure. Not an avalanche forecast.",
      ka: "სვანეთი, რაჭა, ყაზბეგი და თუშეთი: ღრმა თოვლი და გზების რისკი. ეს ზვავის პროგნოზი არ არის.",
    },
  },
  {
    id: "javakheti-avalanche",
    hazard: "avalanche",
    name: { en: "Javakheti high plateau snow zone", ka: "ჯავახეთის მაღალი პლატოს თოვლის ზონა" },
    strength: "moderate",
    labelAt: [43.65, 41.35],
    polygon: [
      [42.7, 41.1], [43.6, 41.0], [44.3, 41.15], [44.4, 41.55], [43.7, 41.68], [43.0, 41.62], [42.78, 41.4],
    ],
    note: {
      en: "High, windy plateau; snowstorms and avalanches can isolate villages and roads.",
      ka: "მაღალი, ქარიანი პლატო; თოვლის ქარიშხალი და ზვავი სოფლებსა და გზებს იზოლირებს.",
    },
  },
  {
    id: "borjomi-wildfire",
    hazard: "wildfire",
    name: { en: "Borjomi forest fire zone", ka: "ბორჯომის ტყის ხანძრის ზონა" },
    strength: "higher",
    labelAt: [43.5, 41.83],
    polygon: [
      [43.08, 41.62], [43.7, 41.58], [43.92, 41.88], [43.5, 42.03], [43.12, 41.94],
    ],
    note: {
      en: "Conifer forests and protected areas; severe fires in August and September 2017.",
      ka: "წიწვოვანი ტყეები და დაცული ტერიტორიები; მძიმე ხანძრები 2017 წლის აგვისტოსა და სექტემბერში.",
    },
  },
  {
    id: "east-wildfire",
    hazard: "wildfire",
    name: { en: "Vashlovani–Lagodekhi fire zone", ka: "ვაშლოვანი–ლაგოდეხის ხანძრის ზონა" },
    strength: "moderate",
    labelAt: [46.15, 41.35],
    polygon: [
      [45.5, 41.08], [46.42, 40.98], [46.62, 41.38], [46.2, 41.7], [45.6, 41.55],
    ],
    note: {
      en: "Dry lowlands and semi-arid protected areas with high summer fire danger.",
      ka: "მშრალი დაბლობები და ნახევრად უდაბნო დაცული ტერიტორიები ზაფხულის მაღალი ხანძარსაშიშროებით.",
    },
  },
  {
    id: "east-drought",
    hazard: "drought",
    name: { en: "Eastern drought and heat zone", ka: "აღმოსავლეთის გვალვისა და სიცხის ზონა" },
    strength: "higher",
    labelAt: [45.6, 41.55],
    polygon: [
      [44.5, 41.2], [45.4, 41.12], [46.3, 41.15], [46.62, 41.5], [46.35, 42.0],
      [45.4, 42.05], [44.8, 41.9], [44.6, 41.6],
    ],
    note: {
      en: "Semi-arid lowlands of Kakheti and Kvemo Kartli; 2000 drought hit these plains hardest.",
      ka: "კახეთისა და ქვემო ქართლის ნახევრად მშრალი დაბლობები; 2000 წლის გვალვამ სწორედ ეს ვაკეები ყველაზე მძიმედ დააზარალა.",
    },
  },
  {
    id: "kakheti-hail",
    hazard: "storm",
    name: { en: "Kakheti hail and wind corridor", ka: "კახეთის სეტყვა-ქარის დერეფანი" },
    strength: "higher",
    labelAt: [45.75, 41.8],
    polygon: [
      [45.15, 41.4], [46.0, 41.22], [46.55, 41.48], [46.28, 42.08], [45.5, 42.22], [45.0, 41.92],
    ],
    note: {
      en: "Alazani valley agriculture: recurring hail and wind losses (2012, 2023).",
      ka: "ალაზნის ველის სოფლის მეურნეობა: განმეორებადი სეტყვისა და ქარის ზარალი (2012, 2023).",
    },
  },
  {
    id: "black-sea-coast",
    hazard: "coastal",
    name: { en: "Black Sea storm and erosion strip", ka: "შავი ზღვის ქარიშხლისა და ეროზიის ზოლი" },
    strength: "higher",
    labelAt: [41.55, 42.35],
    polygon: [
      [41.5, 41.55], [41.82, 41.58], [41.88, 41.78], [41.72, 43.28], [41.52, 43.4],
      [41.58, 42.5], [41.46, 41.9],
    ],
    note: {
      en: "Batumi–Kobuleti–Poti–Anaklia: storm waves, surge, flooding and chronic erosion.",
      ka: "ბათუმი–ქობულეთი–ფოთი–ანაკლია: შტორმული ტალღები, დატბორვა და ქრონიკული ეროზია.",
    },
  },
];
