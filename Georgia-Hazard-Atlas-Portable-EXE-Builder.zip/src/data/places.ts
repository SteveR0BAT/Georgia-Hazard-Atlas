import type { Loc } from "../types";

export interface City {
  name: Loc;
  lon: number;
  lat: number;
  size: "capital" | "major" | "town";
  note?: Loc;
}

export const CITIES: City[] = [
  { name: { en: "Tbilisi", ka: "თბილისი" }, lon: 44.8271, lat: 41.7151, size: "capital" },
  { name: { en: "Batumi", ka: "ბათუმი" }, lon: 41.6367, lat: 41.6168, size: "major" },
  { name: { en: "Kutaisi", ka: "ქუთაისი" }, lon: 42.6946, lat: 42.2679, size: "major" },
  { name: { en: "Rustavi", ka: "რუსთავი" }, lon: 45.0106, lat: 41.5495, size: "major" },
  { name: { en: "Gori", ka: "გორი" }, lon: 44.1089, lat: 41.9844, size: "major" },
  { name: { en: "Zugdidi", ka: "ზუგდიდი" }, lon: 41.8709, lat: 42.5088, size: "major" },
  { name: { en: "Telavi", ka: "თელავი" }, lon: 45.4736, lat: 41.9198, size: "town" },
  { name: { en: "Akhaltsikhe", ka: "ახალციხე" }, lon: 42.9826, lat: 41.639, size: "town" },
  { name: { en: "Mtskheta", ka: "მცხეთა" }, lon: 44.7202, lat: 41.8456, size: "town" },
  { name: { en: "Poti", ka: "ფოთი" }, lon: 41.6716, lat: 42.1462, size: "town" },
  { name: { en: "Ozurgeti", ka: "ოზურგეთი" }, lon: 42.0042, lat: 41.9244, size: "town" },
  { name: { en: "Ambrolauri", ka: "ამბროლაური" }, lon: 43.1514, lat: 42.5211, size: "town" },
  { name: { en: "Mestia", ka: "მესტია" }, lon: 42.7279, lat: 43.0457, size: "town" },
  { name: { en: "Oni", ka: "ონი" }, lon: 43.4423, lat: 42.5794, size: "town" },
  { name: { en: "Borjomi", ka: "ბორჯომი" }, lon: 43.3902, lat: 41.8384, size: "town" },
  { name: { en: "Kobuleti", ka: "ქობულეთი" }, lon: 41.7833, lat: 41.8167, size: "town" },
  { name: { en: "Stepantsminda", ka: "სტეფანწმინდა" }, lon: 44.6433, lat: 42.6577, size: "town" },
  { name: { en: "Dusheti", ka: "დუშეთი" }, lon: 44.7, lat: 42.0833, size: "town" },
  { name: { en: "Kvareli", ka: "ყვარელი" }, lon: 45.8154, lat: 41.9547, size: "town" },
  { name: { en: "Sukhumi", ka: "სოხუმი" }, lon: 41.0235, lat: 43.0015, size: "town" },
  { name: { en: "Gagra", ka: "გაგრა" }, lon: 40.267, lat: 43.328, size: "town" },
  { name: { en: "Tsageri", ka: "ცაგერი" }, lon: 42.7675, lat: 42.6472, size: "town" },
];

export const RIVERS: { name: Loc; points: [number, number][]; width: number }[] = [
  {
    name: { en: "Mtkvari (Kura)", ka: "მტკვარი" },
    width: 2.1,
    points: [
      [42.55, 41.1], [43.0, 41.6], [43.38, 41.83], [44.1, 41.98], [44.55, 41.84],
      [44.83, 41.69], [45.02, 41.55], [45.4, 41.45], [45.95, 41.32], [46.6, 41.2],
    ],
  },
  {
    name: { en: "Rioni", ka: "რიონი" },
    width: 2,
    points: [
      [43.68, 42.71], [43.44, 42.58], [43.15, 42.52], [42.86, 42.42], [42.69, 42.26],
      [42.34, 42.16], [42.06, 42.15], [41.85, 42.18], [41.67, 42.15],
    ],
  },
  {
    name: { en: "Enguri", ka: "ენგური" },
    width: 1.7,
    points: [
      [42.88, 43.02], [42.78, 42.75], [42.62, 42.4], [42.45, 42.15], [42.25, 41.98], [41.87, 42.51], [41.68, 42.33],
    ],
  },
  {
    name: { en: "Alazani", ka: "ალაზანი" },
    width: 1.5,
    points: [[45.25, 42.02], [45.48, 41.92], [45.74, 41.82], [46.0, 41.65], [46.28, 41.48], [46.6, 41.24]],
  },
  {
    name: { en: "Chorokhi", ka: "ჭოროხი" },
    width: 1.4,
    points: [[42.55, 41.45], [42.25, 41.5], [41.95, 41.55], [41.75, 41.6], [41.66, 41.64]],
  },
  {
    name: { en: "Terek", ka: "თერგი" },
    width: 1.2,
    points: [[44.64, 42.66], [44.55, 42.78], [44.45, 42.95], [44.52, 43.25]],
  },
  {
    name: { en: "Kvirila", ka: "ყვირილა" },
    width: 1.1,
    points: [[43.45, 42.28], [43.25, 42.26], [43.0, 42.25], [42.82, 42.29], [42.68, 42.27]],
  },
  {
    name: { en: "Iori", ka: "იორი" },
    width: 1.1,
    points: [[45.5, 41.72], [45.2, 41.62], [44.95, 41.52], [44.75, 41.45]],
  },
];

export const LAKES: { name: Loc; lon: number; lat: number; rx: number; ry: number }[] = [
  { name: { en: "Paravani", ka: "ფარავანი" }, lon: 43.8, lat: 41.45, rx: 5.2, ry: 2.2 },
  { name: { en: "Tabatskuri", ka: "ტაბაწყური" }, lon: 43.65, lat: 41.66, rx: 3.4, ry: 1.6 },
  { name: { en: "Kartsakhi", ka: "კარწახი" }, lon: 43.22, lat: 41.22, rx: 2.8, ry: 1.2 },
  { name: { en: "Bazaleti", ka: "ბაზალეთი" }, lon: 44.68, lat: 42.05, rx: 1.6, ry: 1.1 },
];

export const RANGES: { name: Loc; labelAt: [number, number]; points: [number, number][] }[] = [
  {
    name: { en: "GREATER CAUCASUS", ka: "დიდი კავკასიონი" },
    labelAt: [43.05, 42.72],
    points: [[40.4, 43.3], [41.3, 43.15], [42.1, 42.98], [42.8, 42.78], [43.5, 42.55], [44.2, 42.42], [45.0, 42.33], [45.8, 42.22], [46.35, 42.05]],
  },
  {
    name: { en: "LESSER CAUCASUS", ka: "მცირე კავკასიონი" },
    labelAt: [43.85, 41.53],
    points: [[41.65, 41.62], [42.4, 41.56], [43.2, 41.64], [44.0, 41.52], [44.7, 41.46], [45.35, 41.3]],
  },
  {
    name: { en: "LIKHI RANGE", ka: "ლიხის ქედი" },
    labelAt: [42.28, 42.55],
    points: [[42.2, 42.22], [42.2, 42.48], [42.23, 42.72], [42.27, 42.95], [42.32, 43.12]],
  },
  {
    name: { en: "TRIALETI RANGE", ka: "თრიალეთის ქედი" },
    labelAt: [43.65, 41.77],
    points: [[43.22, 41.82], [43.55, 41.76], [43.9, 41.68], [44.18, 41.58]],
  },
];

export const NEIGHBOURS = [
  { label: "RUSSIA", lon: 44.55, lat: 43.5 },
  { label: "TÜRKİYE", lon: 42.4, lat: 41.18 },
  { label: "ARMENIA", lon: 44.45, lat: 41.14 },
  { label: "AZERBAIJAN", lon: 46.45, lat: 41.15 },
  { label: "BLACK SEA", lon: 40.55, lat: 42.45, sea: true },
];
