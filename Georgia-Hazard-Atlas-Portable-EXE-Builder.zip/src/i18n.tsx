import { createContext, useContext, useState, type ReactNode } from "react";
import type { Lang, Loc } from "./types";

export const UI = {
  navMap: { en: "Map", ka: "რუკა" },
  navGuide: { en: "Preparedness", ka: "მზადყოფნა" },
  navTimeline: { en: "Timeline", ka: "ქრონოლოგია" },
  navRegions: { en: "Regions", ka: "რეგიონები" },
  navSources: { en: "Sources", ka: "წყაროები" },
  brand: { en: "Hazard Atlas Georgia", ka: "საფრთხეების ატლასი საქართველო" },
  brandSub: { en: "Natural hazards & preparedness", ka: "ბუნებრივი საფრთხეები და მზადყოფნა" },
  brandShort: { en: "Hazard Atlas", ka: "საფრთხეების ატლასი" },
  emergencyBtn: { en: "Emergency info", ka: "საგანგებო ინფორმაცია" },
  staticChip: { en: "Static educational atlas", ka: "სტატიკური საგანმანათლებლო ატლასი" },
  ribbonPrefix: { en: "Emergency? Call", ka: "საგანგებო სიტუაცია? დარეკეთ" },
  notLive: { en: "Not a live warning service", ka: "არ არის ცოცხალი გაფრთხილების სერვისი" },
  langEn: { en: "EN", ka: "EN" },
  langKa: { en: "ქართული", ka: "ქართული" },
  search: { en: "Search", ka: "ძიება" },
  searchPlaceholder: {
    en: "Search places, regions, hazards or events…",
    ka: "მოძებნეთ ადგილი, რეგიონი, საფრთხე ან მოვლენა…",
  },
  searchHint: { en: "Type at least two letters", ka: "შეიყვანეთ მინიმუმ ორი ასო" },
  searchNoRes: { en: "No matching records in this atlas.", ka: "ატლასში შესაბამისი ჩანაწერი ვერ მოიძებნა." },
  searchIncidents: { en: "Historical events", ka: "ისტორიული მოვლენები" },
  searchPlaces: { en: "Regions & municipalities", ka: "რეგიონები და მუნიციპალიტეტები" },
  searchGuides: { en: "Preparedness guides", ka: "მზადყოფნის გიდები" },
  searchClose: { en: "Close search", ka: "ძიების დახურვა" },
  close: { en: "Close", ka: "დახურვა" },
  menu: { en: "Menu", ka: "მენიუ" },
  all: { en: "All", ka: "ყველა" },
  allHazards: { en: "All hazard types", ka: "ყველა ტიპის საფრთხე" },
  allRegions: { en: "All regions", ka: "ყველა რეგიონი" },
  reset: { en: "Reset", ka: "გადატვირთვა" },
  resetFilters: { en: "Reset filters", ka: "ფილტრების გასუფთავება" },
  learnMore: { en: "Learn more", ka: "ვრცლად" },
  readGuide: { en: "Open preparedness guide", ka: "მზადყოფნის გიდის გახსნა" },
  viewTimeline: { en: "View on timeline", ka: "ქრონოლოგიაში ნახვა" },
  viewOnMap: { en: "View on map", ka: "რუკაზე ნახვა" },
  source: { en: "Source", ka: "წყარო" },
  sources: { en: "Sources", ka: "წყაროები" },
  documented: { en: "Documented", ka: "დოკუმენტირებული" },
  partial: { en: "Partial record", ka: "ნაწილობრივი ჩანაწერი" },
  figuresDisputed: { en: "Figures disputed", ka: "მონაცემები განსხვავებული" },
  catastrophic: { en: "Catastrophic impact", ka: "კატასტროფული ზეგავლენა" },
  major: { en: "Major impact", ka: "მძიმე ზეგავლენა" },
  moderate: { en: "Moderate impact", ka: "ზომიერი ზეგავლენა" },
  impact: { en: "Impact class", ka: "ზეგავლენის კლასი" },
  mapKicker: { en: "National atlas · Georgia", ka: "ეროვნული ატლასი · საქართველო" },
  mapTitle1: { en: "Hazards are not", ka: "საფრთხეები არ არის" },
  mapTitle2: { en: "evenly distributed.", ka: "თანაბრად განაწილებული." },
  mapIntro: {
    en: "Explore documented disasters, the landscapes that produce them, and what to do before, during and after an emergency. Every event is sourced; every zone is labelled as generalised.",
    ka: "გაეცანით დოკუმენტირებულ კატასტროფებს, მათ გამომწვევ ლანდშაფტებსა და ქმედებებს კრიზისამდე, დროსა და შემდეგ. თითოეული მოვლენა წყაროებითაა დადასტურებული; ყოველი ზონა განზოგადებულია.",
  },
  statRegions: { en: "regions", ka: "რეგიონი" },
  statEvents: { en: "documented events", ka: "დოკუმენტირებული მოვლენა" },
  statHazards: { en: "hazard layers", ka: "საფრთხის ფენა" },
  statSources: { en: "cited sources", ka: "ციტირებული წყარო" },
  layersTitle: { en: "Map layers", ka: "რუკის ფენები" },
  layersIntro: { en: "Toggle hazards independently. Markers are historical events; shaded shapes are generalised susceptibility zones.", ka: "საფრთხეები დამოუკიდებლად ჩართეთ. მარკერები ისტორიული მოვლენებია; ფერადი ფორმები განზოგადებული რისკის ზონებია." },
  hazardLayers: { en: "Hazard layers", ka: "საფრთხის ფენები" },
  mapFeatures: { en: "Map features", ka: "რუკის ელემენტები" },
  showZones: { en: "Susceptibility zones", ka: "მოწყვლადობის ზონები" },
  showIncidents: { en: "Historical markers", ka: "ისტორიული მარკერები" },
  showBoundaries: { en: "Region boundaries", ka: "რეგიონების საზღვრები" },
  showMunicipalities: { en: "Municipality boundaries", ka: "მუნიციპალიტეტების საზღვრები" },
  showRivers: { en: "Rivers, lakes & relief", ka: "მდინარეები, ტბები და რელიეფი" },
  showCities: { en: "Cities & place labels", ka: "ქალაქები და დასახელებები" },
  allOn: { en: "All on", ka: "ყველა ჩართვა" },
  allOff: { en: "All off", ka: "ყველას გამორთვა" },
  zoneWarning: {
    en: "Shaded zones show where hazards are known to occur. They are not forecasts and do not mean a disaster happened at any specific pin.",
    ka: "ფერადი ზონები აჩვენებს, სად ხდება საფრთხეები. ისინი პროგნოზი არ არის და არ ნიშნავს, რომ კატასტროფა კონკრეტულ ადგილას მომხდარა.",
  },
  zoomIn: { en: "Zoom in", ka: "გადიდება" },
  zoomOut: { en: "Zoom out", ka: "შემცირება" },
  resetView: { en: "Reset map view", ka: "რუკის ხედის აღდგენა" },
  legend: { en: "Legend", ka: "ლეგენდა" },
  historicalMarkers: { en: "Historical incident", ka: "ისტორიული შემთხვევა" },
  susceptibilityZone: { en: "Generalised hazard zone", ka: "განზოგადებული საფრთხის ზონა" },
  mapCredit: { en: "Boundaries: geoBoundaries (CC BY 3.0). Vector atlas, not a live map.", ka: "საზღვრები: geoBoundaries (CC BY 3.0). ვექტორული ატლასი, არა ცოცხალი რუკა." },
  selectPrompt: { en: "Explore the national picture", ka: "გაეცანით ეროვნულ სურათს" },
  selectPromptBody: {
    en: "Click an incident marker for a sourced record, or a region for its hazard profile. This atlas explains history and risk — it does not issue live alerts.",
    ka: "დააწკაპუნეთ მოვლენის მარკერზე წყაროებით დადასტურებული ჩანაწერისთვის ან რეგიონზე მისი რისკის პროფილისთვის. ატლასი განმარტავს ისტორიასა და რისკს და არ ავრცელებს ცოცხალ გაფრთხილებებს.",
  },
  overview: { en: "Atlas overview", ka: "ატლასის მიმოხილვა" },
  documentedEvents: { en: "Documented events", ka: "დოკუმენტირებული მოვლენები" },
  keyHazards: { en: "Principal hazards", ka: "ძირითადი საფრთხეები" },
  dangerHotspots: { en: "Regions with the widest hazard profiles", ka: "ყველაზე მრავალფეროვანი საფრთხის პროფილის რეგიონები" },
  quickAccess: { en: "Quick access", ka: "სწრაფი წვდომა" },
  prepareNow: { en: "Prepare your household", ka: "მოემზადეთ ოჯახთან ერთად" },
  seeEmergency: { en: "Emergency information", ka: "საგანგებო ინფორმაცია" },
  howWeKnow: { en: "How evidence is labelled", ka: "როგორ არის მონიშნული მტკიცებულება" },
  date: { en: "Date", ka: "თარიღი" },
  place: { en: "Location", ka: "ადგილი" },
  hazardType: { en: "Hazard", ka: "საფრთხე" },
  alsoRelevant: { en: "Also relevant", ka: "ასევე შესაბამისი" },
  killed: { en: "Casualties", ka: "მსხვერპლი" },
  affected: { en: "People & assets affected", ka: "დაზარალებული ადამიანები და ობიექტები" },
  damage: { en: "Damage & losses", ka: "ზარალი" },
  context: { en: "Historical context", ka: "ისტორიული კონტექსტი" },
  confidence: { en: "Evidence note", ka: "მტკიცებულების შენიშვნა" },
  regionalContext: { en: "Regional context", ka: "რეგიონული კონტექსტი" },
  locatedApprox: { en: "Marker placed at municipal centre", ka: "მარკერი მუნიციპალიტეტის ცენტრშია" },
  sitePrecision: { en: "Marker placed at or near documented site", ka: "მარკერი დოკუმენტირებულ ადგილთანაა" },
  eventSources: { en: "Sources for this record", ka: "ამ ჩანაწერის წყაროები" },
  openSource: { en: "Open source", ka: "წყაროს გახსნა" },
  regionalHazards: { en: "Hazards in this region", ka: "საფრთხეები ამ რეგიონში" },
  documentedHistory: { en: "Documented history", ka: "დოკუმენტირებული ისტორია" },
  vulnerabilities: { en: "Geographical vulnerabilities", ka: "გეოგრაფიული მოწყვლადობა" },
  prepRecommendations: { en: "Preparedness recommendations", ka: "მზადყოფნის რეკომენდაციები" },
  regionalOfficial: { en: "Official & regional resources", ka: "ოფიციალური და რეგიონული რესურსები" },
  noIncidents: {
    en: "No verified historical event from our set is assigned to this region. Absence of a marker is a data gap, not proof of low risk.",
    ka: "ჩვენი მონაცემთა ბაზიდან ამ რეგიონს არცერთი დადასტურებული მოვლენა არ მიეკუთვნება. მარკერის არარსებობა ხარვეზია და არა დაბალი რისკის მტკიცებულება.",
  },
  dataGap: { en: "Data gap", ka: "მონაცემთა ხარვეზი" },
  exploreRegion: { en: "Explore region profile", ka: "რეგიონის პროფილის ნახვა" },
  backToMap: { en: "Back to map overview", ka: "რუკის მიმოხილვაზე დაბრუნება" },
  allRegionsTitle: { en: "All 12 first-order regions", ka: "ყველა 12 პირველი დონის რეგიონი" },
  timelineKicker: { en: "Historical record · 1920–2024", ka: "ისტორიული ჩანაწერი · 1920–2024" },
  timelineTitle: { en: "A century of disaster.", ka: "კატასტროფების საუკუნე." },
  timelineIntro: {
    en: "Not a ranking of suffering, but a trace of how hazards have repeatedly met Georgian communities. Filter by hazard, region and impact; open a record to see its sources.",
    ka: "ეს არ არის ტანჯვის რეიტინგი, არამედ კვალი იმისა, თუ როგორ დაუპირისპირდა საფრთხეები ქართულ თემებს. გაფილტრეთ ტიპის, რეგიონისა და ზეგავლენის მიხედვით.",
  },
  eventsShown: { en: "events shown", ka: "ნაჩვენები მოვლენა" },
  filterSeverity: { en: "Impact class", ka: "ზეგავლენის კლასი" },
  yearRange: { en: "Period", ka: "პერიოდი" },
  noResults: { en: "No records match these filters.", ka: "ამ ფილტრებს ჩანაწერი არ შეესაბამება." },
  guideKicker: { en: "Preparedness guide", ka: "მზადყოფნის გიდი" },
  guideTitle: { en: "Know exactly what to do.", ka: "იცოდეთ ზუსტად რა უნდა გააკეთოთ." },
  guideIntro: {
    en: "Practical, sequenced instructions for each natural hazard. Work through a stage, then save your checklist progress in this browser.",
    ka: "პრაქტიკული, ეტაპობრივი ინსტრუქციები თითოეული ბუნებრივი საფრთხისთვის. გაიარეთ ეტაპები და შეინახეთ ჩამონათვალის პროგრესი ამ ბრაუზერში.",
  },
  chooseHazard: { en: "Choose a hazard", ka: "აირჩიეთ საფრთხე" },
  whyGeorgia: { en: "Why this happens in Georgia", ka: "რატომ ხდება ეს საქართველოში" },
  warningSigns: { en: "Warning signs & systems", ka: "გაფრთხილების ნიშნები და სისტემები" },
  before: { en: "Before", ka: "მანამდე" },
  during: { en: "During", ka: "დროს" },
  after: { en: "After", ka: "შემდეგ" },
  mistakes: { en: "Dangerous misconceptions", ka: "საშიში მცდარი წარმოდგენები" },
  checklist: { en: "Household checklist", ka: "ოჯახის ჩამონათვალი" },
  checklistProgress: { en: "prepared", ka: "მზადაა" },
  resetChecklist: { en: "Reset checklist", ka: "ჩამონათვალის გასუფთავება" },
  vulnerable: { en: "Children, older people & disabilities", ka: "ბავშვები, მოხუცები და შეზღუდული შესაძლებლობები" },
  emergencyContacts: { en: "Emergency contacts", ka: "საგანგებო კონტაქტები" },
  emergencyShort: { en: "One number: police, fire-rescue and ambulance", ka: "ერთი ნომერი: პოლიცია, მაშველები და სასწრაფო" },
  officialsLinks: { en: "Official resources", ka: "ოფიციალური რესურსები" },
  printGuide: { en: "Print this guide", ka: "გიდის დაბეჭდვა" },
  savedNote: {
    en: "Checklist progress is stored only in this browser. It is not sent anywhere.",
    ka: "ჩამონათვალის პროგრესი მხოლოდ ამ ბრაუზერში ინახება და არსად იგზავნება.",
  },
  regionsKicker: { en: "Risk profiles", ka: "რისკის პროფილები" },
  regionsTitle: { en: "Risk looks different from every valley.", ka: "რისკი ყოველი ხეობიდან განსხვავებულად გამოიყურება." },
  regionsIntro: {
    en: "Select a region to see its documented hazards, verified incidents, structural vulnerabilities and preparedness priorities. Municipalities are listed from the map boundary dataset.",
    ka: "აირჩიეთ რეგიონი დოკუმენტირებული საფრთხეების, დადასტურებული მოვლენების, სტრუქტურული მოწყვლადობისა და მზადყოფნის პრიორიტეტების სანახავად.",
  },
  regionProfile: { en: "Region profile", ka: "რეგიონის პროფილი" },
  municipalityList: { en: "Municipalities on the map", ka: "მუნიციპალიტეტები რუკაზე" },
  regionDataNote: {
    en: "Profiles are qualitative summaries from cited national assessments. They are not engineering surveys or official risk grades.",
    ka: "პროფილები ციტირებული ეროვნული შეფასებების თვისებრივი შეჯამებაა. ეს არ არის საინჟინრო კვლევა ან ოფიციალური რისკის კლასი.",
  },
  sourcesKicker: { en: "Evidence & method", ka: "მტკიცებულება და მეთოდი" },
  sourcesTitle: { en: "Nothing here without a source.", ka: "აქ არაფერია წყაროს გარეშე." },
  sourcesIntro: {
    en: "This is a static research atlas, last reviewed in June 2026. It is not connected to live monitoring. Official services remain the only authority for active warnings and evacuations.",
    ka: "ეს სტატიკური კვლევითი ატლასია, გადამოწმებული 2026 წლის ივნისში. ის ცოცხალ მონიტორინგთან არ არის დაკავშირებული. აქტიური გაფრთხილებებისა და ევაკუაციის ერთადერთი ავტორიტეტი ოფიციალური სამსახურები არიან.",
  },
  methodology: { en: "How this atlas separates evidence", ka: "როგორ აცალკევებს ატლასი მტკიცებულებას" },
  class1: { en: "Historical event", ka: "ისტორიული მოვლენა" },
  class1Desc: {
    en: "A dated, located incident reported by a named source. Ranges are shown when accounts disagree.",
    ka: "დათარიღებული, მდებარეობით განსაზღვრული მოვლენა დასახელებული წყაროდან. განსხვავებისას დიაპაზონია ნაჩვენები.",
  },
  class2: { en: "Generalised hazard zone", ka: "განზოგადებული საფრთხის ზონა" },
  class2Desc: {
    en: "A coarse area where a hazard process is known to occur. It is not a precise boundary, forecast or event location.",
    ka: "უხეში არე, სადაც საფრთხის პროცესი ცნობილია. ეს არ არის ზუსტი საზღვარი, პროგნოზი ან მოვლენის ადგილი.",
  },
  class3: { en: "Scientific risk estimate", ka: "სამეცნიერო რისკის შეფასება" },
  class3Desc: {
    en: "Published hazard, exposure or climate projections, described as assessments rather than certainties.",
    ka: "გამოქვეყნებული საფრთხის, მოწყვლადობის ან კლიმატური პროგნოზები, აღწერილი როგორც შეფასება და არა სიზუსტე.",
  },
  class4: { en: "Active emergency", ka: "აქტიური საგანგებო სიტუაცია" },
  class4Desc: {
    en: "Real-time warnings are deliberately not displayed. Use 112 and the National Environmental Agency for live information.",
    ka: "რეალურ დროში გაფრთხილებები განზრახ არ ჩანს. ცოცხალი ინფორმაციისთვის გამოიყენეთ 112 და ეროვნული გარემოსდაცვითი სააგენტო.",
  },
  bibliography: { en: "Source directory", ka: "წყაროების კატალოგი" },
  whatItSupports: { en: "What it supports", ka: "რას ადასტურებს" },
  accessedLabel: { en: "Accessed", ka: "გადამოწმებულია" },
  sourcesLangNote: {
    en: "Source titles are shown in their original language, with an English description of what each supports.",
    ka: "წყაროების სათაურები თავდაპირველ ენაზეა, ინგლისურად აღწერილია თითოეულის მხარდამჭერი ინფორმაცია.",
  },
  gapsTitle: { en: "Known gaps, disputes & limitations", ka: "ცნობილი ხარვეზები, დაპირისპირებები და შეზღუდვები" },
  licenseTitle: { en: "Data credits & licence", ka: "მონაცემების წყაროები და ლიცენზია" },
  footDisclaimer: {
    en: "Research and education only. This atlas is not affiliated with the Government of Georgia and does not provide live alerts, evacuation orders or emergency response.",
    ka: "მხოლოდ კვლევისა და განათლებისთვის. ატლასი არ არის საქართველოს მთავრობის ოფიციალური პროდუქტი და არ აწვდის ცოცხალ გაფრთხილებებს, ევაკუაციის ბრძანებებს ან საგანგებო რეაგირებას.",
  },
  footCrisis: { en: "In danger now? Call 112.", ka: "საფრთხეში ხართ? დარეკეთ 112-ში." },
  emergencyTitle: { en: "Emergency information", ka: "საგანგებო ინფორმაცია" },
  emergencySub: {
    en: "Georgia's unified emergency number. Free from any phone, including without credit or a SIM.",
    ka: "საქართველოს ერთიანი საგანგებო ნომერი. უფასოა ნებისმიერი ტელეფონიდან, ბალანსისა და SIM ბარათის გარეშეც.",
  },
  call112: { en: "Call 112", ka: "დარეკეთ 112-ში" },
  whatToSay: { en: "What to tell the operator", ka: "რა უთხრათ ოპერატორს" },
  whatToSay1: { en: "What happened and which service you need (police, fire, ambulance, rescue).", ka: "რა მოხდა და რომელი სამსახური გჭირდებათ (პოლიცია, მაშველები, სასწრაფო)." },
  whatToSay2: { en: "Your exact location or the nearest landmark; share GPS coordinates if you can.", ka: "ზუსტი მდებარეობა ან უახლოესი ორიენტირი; შეძლებისდაგვარად გაგზავნეთ GPS კოორდინატები." },
  whatToSay3: { en: "How many people are affected, injuries, and hazards such as fire, gas or rising water.", ka: "რამდენი ადამიანია დაზარალებული, დაშავებულები და საფრთხეები: ცეცხლი, გაზი, მზარდი წყალი." },
  whatToSay4: { en: "Your name and phone number; do not hang up until told to.", ka: "სახელი და ტელეფონის ნომერი; ნუ გათიშავთ, სანამ არ გეტყვიან." },
  officialMonitoring: { en: "Official information & monitoring", ka: "ოფიციალური ინფორმაცია და მონიტორინგი" },
  noLiveTitle: { en: "This atlas is not a warning system", ka: "ატლასი გაფრთხილების სისტემა არ არის" },
  noLiveBody: {
    en: "No live sensors, alerts or emergency feeds are connected. A hazard zone is not an alert. For an active emergency call 112 and follow instructions from the Emergency Situations Management Service.",
    ka: "ცოცხალი სენსორები, გაფრთხილებები და საგანგებო არხები არ არის მიერთებული. საფრთხის ზონა გაფრთხილება არ არის. აქტიური საგანგებო სიტუაციისას დარეკეთ 112-ში და შეასრულეთ გადაუდებელი სიტუაციების მართვის სამსახურის ინსტრუქციები.",
  },
  guidesForAll: { en: "All hazard guides", ka: "ყველა საფრთხის გიდი" },
  openGuide: { en: "Open guide", ka: "გიდის გახსნა" },
  mapContext: { en: "National context", ka: "ეროვნული კონტექსტი" },
  eventSummary: { en: "What happened", ka: "რა მოხდა" },
  evidenceNote: { en: "Evidence note", ka: "მტკიცებულების შენიშვნა" },
  legendTitle: { en: "Reading the map", ka: "რუკის კითხვა" },
  legendPin: { en: "Pin = dated historical incident", ka: "ნიშანი = დათარიღებული ისტორიული მოვლენა" },
  legendZone: { en: "Shaded band = generalised hazard zone", ka: "ფერადი ზოლი = განზოგადებული საფრთხის ზონა" },
  legendSource: { en: "All records carry source links", ka: "ყველა ჩანაწერს აქვს წყაროს ბმული" },
  imageDisclaimer: { en: "No photographs are used for individual events where licensing or authenticity could not be verified.", ka: "ინდივიდუალური მოვლენებისთვის ფოტოები არ გამოიყენება, სადაც ლიცენზია ან ავთენტურობა ვერ დადასტურდა." },
  countryContext: { en: "Country context", ka: "ქვეყნის კონტექსტი" },
  allMunicipalities: { en: "Municipalities", ka: "მუნიციპალიტეტები" },
  viewRegion: { en: "View region", ka: "რეგიონის ნახვა" },
  mapInstruction: { en: "Drag to pan · scroll or use + / − to zoom · click for details", ka: "გადაათრიეთ · გადაადგილეთ ან გამოიყენეთ + / − · დააწკაპუნეთ დეტალებისთვის" },
  researchDate: { en: "Research review", ka: "კვლევის გადახედვა" },
  editorialNote: { en: "Editorial classification", ka: "რედაქციული კლასიფიკაცია" },
  mapAria: { en: "Interactive hazard map of Georgia", ka: "საქართველოს ინტერაქტიული საფრთხეების რუკა" },
  severityNote: {
    en: "Impact classes are this atlas's editorial summary of documented deaths, displacement and damage — not official government ratings.",
    ka: "ზეგავლენის კლასები ატლასის რედაქციული შეჯამებაა დოკუმენტირებული მსხვერპლის, გადაადგილებისა და ზარალის მიხედვით — და არა ოფიციალური სამთავრობო შეფასება.",
  },
} as const;

export type UIKey = keyof typeof UI;

type Ctx = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: UIKey) => string;
  bi: <T>(value: Loc<T>) => T;
};

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({
  lang,
  setLang,
  children,
}: {
  lang: Lang;
  setLang: (lang: Lang) => void;
  children: ReactNode;
}) {
  const t = (key: UIKey) => UI[key][lang];
  const bi = <T,>(value: Loc<T>) => value[lang];
  return <LanguageContext.Provider value={{ lang, setLang, t, bi }}>{children}</LanguageContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useI18n must be used inside LanguageProvider");
  return ctx;
}

export function useLocalStorageState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  const update = (next: T) => {
    setValue(next);
    try {
      localStorage.setItem(key, JSON.stringify(next));
    } catch {
      /* storage may be unavailable */
    }
  };
  return [value, update] as const;
}
