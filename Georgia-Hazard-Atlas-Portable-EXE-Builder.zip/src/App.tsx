import { useEffect, useState } from "react";
import { LanguageProvider } from "./i18n";
import type { HazardKey, Lang, MapSelection, Page } from "./types";
import { INCIDENTS } from "./data/incidents";
import { Header, Footer, SearchDialog, EmergencyPanel } from "./components/Chrome";
import { MapPage } from "./pages/MapPage";
import { GuidesPage } from "./pages/GuidesPage";
import { TimelinePage } from "./pages/TimelinePage";
import { RegionsPage } from "./pages/RegionsPage";
import { SourcesPage } from "./pages/SourcesPage";

const REGION_COORDS: Record<string, { lon: number; lat: number }> = {
  Tbilisi: { lon: 44.8271, lat: 41.7151 },
  Adjara: { lon: 41.6367, lat: 41.6168 },
  Guria: { lon: 42.0042, lat: 41.9244 },
  Imereti: { lon: 42.6946, lat: 42.2679 },
  Kakheti: { lon: 45.4736, lat: 41.9198 },
  "Kvemo Kartli": { lon: 45.0106, lat: 41.5495 },
  "Mtskheta-Mtianeti": { lon: 44.7202, lat: 41.8456 },
  "Racha-Lechkhumi and Kvemo Svaneti": { lon: 43.1514, lat: 42.5211 },
  "Samegrelo-Zemo Svaneti": { lon: 41.8709, lat: 42.5088 },
  "Samtskhe–Javakheti": { lon: 42.9826, lat: 41.639 },
  "Shida Kartli": { lon: 44.1089, lat: 41.9844 },
  Abkhazia: { lon: 41.0235, lat: 43.0015 },
};

export default function App() {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const saved = localStorage.getItem("hazard-atlas-lang");
      return saved === "ka" ? "ka" : "en";
    } catch {
      return "en";
    }
  });
  const [page, setPage] = useState<Page>("map");
  const [selection, setSelection] = useState<MapSelection>(null);
  const [focus, setFocus] = useState<{ lon: number; lat: number; token: number } | null>(null);
  const [guideHazard, setGuideHazard] = useState<HazardKey>("earthquake");
  const [regionPageId, setRegionPageId] = useState<string | null>("tbilisi");
  const [timelineFocusId, setTimelineFocusId] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [emergencyOpen, setEmergencyOpen] = useState(false);

  const setLang = (next: Lang) => {
    setLangState(next);
    try {
      localStorage.setItem("hazard-atlas-lang", next);
    } catch {
      /* ignore */
    }
  };

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable);
      if ((e.key === "/" || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k")) && !typing) {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const navigate = (next: Page) => {
    setPage(next);
    setSearchOpen(false);
    setEmergencyOpen(false);
    window.scrollTo(0, 0);
  };

  const openIncidentOnMap = (id: string) => {
    const incident = INCIDENTS.find((i) => i.id === id);
    setSelection({ kind: "incident", id });
    if (incident) setFocus({ lon: incident.lon, lat: incident.lat, token: Date.now() });
    navigate("map");
  };

  const openRegionOnMap = (name: string) => {
    setSelection({ kind: "region", name });
    const coords = REGION_COORDS[name];
    if (coords) setFocus({ lon: coords.lon, lat: coords.lat, token: Date.now() });
    navigate("map");
  };

  const openGuide = (hazard: HazardKey) => {
    setGuideHazard(hazard);
    navigate("guides");
  };

  const openRegionProfile = (id: string) => {
    setRegionPageId(id);
    navigate("regions");
  };

  const openTimeline = (id?: string) => {
    setTimelineFocusId(id ?? null);
    navigate("timeline");
  };

  return (
    <LanguageProvider lang={lang} setLang={setLang}>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:rounded-md focus:bg-[var(--ink)] focus:px-3 focus:py-2 focus:text-sm focus:text-white"
      >
        {lang === "en" ? "Skip to content" : "მთავარ შიგთავსზე გადასვლა"}
      </a>
      <div className="min-h-screen">
        <Header
          page={page}
          onNavigate={navigate}
          onSearch={() => setSearchOpen(true)}
          onEmergency={() => setEmergencyOpen(true)}
          lang={lang}
          setLang={setLang}
        />
        <main id="main">
          {page === "map" && (
            <MapPage
              selection={selection}
              setSelection={setSelection}
              focus={focus}
              onOpenGuide={openGuide}
              onOpenEmergency={() => setEmergencyOpen(true)}
              onOpenRegionPage={openRegionProfile}
              onOpenTimeline={openTimeline}
            />
          )}
          {page === "guides" && (
            <GuidesPage selectedHazard={guideHazard} onSelectHazard={setGuideHazard} onOpenEmergency={() => setEmergencyOpen(true)} />
          )}
          {page === "timeline" && (
            <TimelinePage focusId={timelineFocusId} onOpenMap={openIncidentOnMap} onOpenGuide={openGuide} />
          )}
          {page === "regions" && (
            <RegionsPage
              initialRegionId={regionPageId}
              onOpenIncident={openIncidentOnMap}
              onOpenGuide={openGuide}
              onOpenEmergency={() => setEmergencyOpen(true)}
            />
          )}
          {page === "sources" && <SourcesPage onOpenEmergency={() => setEmergencyOpen(true)} />}
        </main>
        <Footer onNavigate={navigate} onEmergency={() => setEmergencyOpen(true)} onSearch={() => setSearchOpen(true)} />
      </div>

      {searchOpen && (
        <SearchDialog
          onClose={() => setSearchOpen(false)}
          onPickIncident={(id) => {
            setSearchOpen(false);
            openIncidentOnMap(id);
          }}
          onPickRegion={(region) => {
            setSearchOpen(false);
            openRegionOnMap(region.name);
          }}
          onPickGuide={(hazard) => {
            setSearchOpen(false);
            openGuide(hazard);
          }}
        />
      )}
      {emergencyOpen && (
        <EmergencyPanel
          onClose={() => setEmergencyOpen(false)}
          onPickGuide={(hazard) => {
            setEmergencyOpen(false);
            openGuide(hazard);
          }}
        />
      )}
    </LanguageProvider>
  );
}
