import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  CircleAlert,
  MapPin,
  Search,
  SlidersHorizontal,
} from "lucide-react";
import { useI18n } from "../i18n";
import { HAZARD_KEYS, HAZARD_META, REGION_NAME_KA, type HazardKey, type Severity } from "../types";
import { INCIDENTS } from "../data/incidents";
import { REGIONS } from "../data/regions";
import { SOURCES } from "../data/sources";
import { HazardGlyph } from "../components/HazardGlyph";

const MIN_YEAR = 1920;
const MAX_YEAR = 2024;
const SOURCE_INDEX = new Map(SOURCES.map((s) => [s.id, s]));

const severityColor: Record<Severity, string> = {
  catastrophic: "#8f2f19",
  major: "#b9542f",
  moderate: "#8a6a2f",
};

export function TimelinePage({
  focusId,
  onOpenMap,
  onOpenGuide,
}: {
  focusId?: string | null;
  onOpenMap: (id: string) => void;
  onOpenGuide: (h: HazardKey) => void;
}) {
  const { t, bi, lang } = useI18n();
  const [hazards, setHazards] = useState<Set<HazardKey>>(new Set(HAZARD_KEYS));
  const [region, setRegion] = useState("all");
  const [severity, setSeverity] = useState<"all" | Severity>("all");
  const [from, setFrom] = useState(MIN_YEAR);
  const [to, setTo] = useState(MAX_YEAR);
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(focusId ?? null);

  useEffect(() => {
    if (focusId) setOpenId(focusId);
  }, [focusId]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...INCIDENTS]
      .filter((i) => {
        const year = Number(i.startDate.slice(0, 4));
        if (year < from || year > to) return false;
        if (!hazards.has(i.hazard)) return false;
        if (severity !== "all" && i.severity !== severity) return false;
        if (region !== "all" && i.region !== region && !i.affectedRegions?.includes(region)) return false;
        if (q) {
          const haystack = [
            i.title.en,
            i.title.ka,
            i.location.en,
            i.location.ka,
            i.summary.en,
            bi(HAZARD_META[i.hazard].label),
            i.region,
            i.dateLabel.en,
          ]
            .join(" ")
            .toLowerCase();
          if (!haystack.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.startDate.localeCompare(a.startDate));
  }, [hazards, region, severity, from, to, query, bi]);

  const toggleHazard = (h: HazardKey) => {
    const next = new Set(hazards);
    if (next.has(h)) next.delete(h);
    else next.add(h);
    setHazards(next);
  };

  const reset = () => {
    setHazards(new Set(HAZARD_KEYS));
    setRegion("all");
    setSeverity("all");
    setFrom(MIN_YEAR);
    setTo(MAX_YEAR);
    setQuery("");
    setOpenId(null);
  };

  const railEvents = filtered;

  return (
    <div>
      <section className="border-b border-[rgba(20,43,37,0.13)] bg-[var(--paper)] paper-grain">
        <div className="mx-auto max-w-[1440px] px-4 pb-8 pt-9 sm:px-6">
          <div className="grid gap-7 lg:grid-cols-[1fr_340px] lg:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2.5">
                <span className="h-px w-6 bg-[var(--clay)]" />
                <p className="eyebrow">{t("timelineKicker")}</p>
              </div>
              <h1 className="display text-[37px] leading-[1.02] sm:text-[49px]">
                {lang === "en" ? "A century of" : "კატასტროფების"}
                <br />
                <span className="italic text-[var(--forest)]">{lang === "en" ? "disasters, traced." : "საუკუნე."}</span>
              </h1>
              <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[var(--ink-2)]">{t("timelineIntro")}</p>
            </div>
            <div className="card p-4">
              <div className="flex items-end justify-between">
                <div>
                  <p className="eyebrow !text-[9px]">{t("documentedEvents")}</p>
                  <p className="display mt-1 text-[46px] leading-none text-[var(--ink)]">{INCIDENTS.length}</p>
                </div>
                <div className="text-right text-[10px] leading-snug text-[var(--muted)]">
                  1920 – 2024
                  <br />
                  8 {t("statHazards")}
                </div>
              </div>
              <p className="mt-2 border-t border-[rgba(20,43,37,0.1)] pt-2 text-[9px] leading-relaxed text-[var(--muted)]">
                {lang === "en"
                  ? "A curated set of documented incidents, not a complete disaster census. Absence of a record does not mean absence of risk."
                  : "დოკუმენტირებული შემთხვევების შერჩეული ნაკრები და არა სრული კატასტროფების აღწერა. ჩანაწერის არარსებობა რისკის არარსებობას არ ნიშნავს."}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        {/* timeline scrubber */}
        <div className="card overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[rgba(20,43,37,0.1)] px-4 py-2.5">
            <p className="flex items-center gap-1.5 text-[11.5px] font-bold text-[var(--ink)]">
              <CalendarDays size={14} className="text-[var(--clay)]" />
              {lang === "en" ? "Chronology rail" : "ქრონოლოგიური ღერძი"}
            </p>
            <p className="text-[9.5px] text-[var(--muted)]">
              {filtered.length} {t("eventsShown")} · {lang === "en" ? "click a dot to open" : "დააწკაპუნეთ წერტილს"}
            </p>
          </div>
          <div className="overflow-x-auto scroll-area px-4 pb-2 pt-4">
            <div className="relative h-[92px] min-w-[700px]">
              <div className="absolute inset-x-0 top-[44px] h-px bg-[rgba(20,43,37,0.22)]" />
              {[1920, 1940, 1960, 1980, 2000, 2010, 2020, 2024].map((year) => {
                const pct = ((year - MIN_YEAR) / (MAX_YEAR - MIN_YEAR)) * 100;
                return (
                  <div key={year} className="absolute top-[44px] -translate-x-1/2" style={{ left: `${pct}%` }}>
                    <span className="block h-2 w-px bg-[rgba(20,43,37,0.4)]" />
                    <span className="mt-1 block text-[8.5px] font-semibold tabular-nums text-[var(--muted)]">{year}</span>
                  </div>
                );
              })}
              <div
                className="absolute top-[42px] h-[5px] rounded-full bg-[rgba(185,84,47,0.24)]"
                style={{
                  left: `${((from - MIN_YEAR) / (MAX_YEAR - MIN_YEAR)) * 100}%`,
                  width: `${((to - from) / (MAX_YEAR - MIN_YEAR)) * 100}%`,
                }}
              />
              {railEvents.map((e, idx) => {
                const year = Number(e.startDate.slice(0, 4));
                const pct = ((year - MIN_YEAR) / (MAX_YEAR - MIN_YEAR)) * 100;
                const top = 18 + (idx % 3) * 11;
                const open = openId === e.id;
                return (
                  <button
                    key={e.id}
                    onClick={() => setOpenId(open ? null : e.id)}
                    className={`absolute h-3 w-3 -translate-x-1/2 rounded-full border-2 border-[var(--cream)] transition-transform hover:scale-150 ${open ? "z-10 ring-2 ring-[var(--ink)] ring-offset-1" : ""}`}
                    style={{ left: `${pct}%`, top, background: HAZARD_META[e.hazard].color }}
                    title={`${bi(e.title)} (${year})`}
                    aria-label={`${bi(e.title)}, ${bi(e.dateLabel)}`}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* filters */}
        <div className="card mt-3 p-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[180px] flex-1">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={lang === "en" ? "Search event, place or year…" : "მოძებნეთ მოვლენა, ადგილი ან წელი…"}
                className="w-full rounded-full border border-[rgba(20,43,37,0.18)] bg-white/55 py-2 pl-8 pr-3 text-[11.5px] text-[var(--ink)] outline-none placeholder:text-[var(--muted)] focus:border-[var(--forest)]"
              />
            </div>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              aria-label={t("allRegions")}
              className="rounded-full border border-[rgba(20,43,37,0.18)] bg-white/55 px-3 py-2 text-[11px] font-semibold text-[var(--ink-2)] outline-none"
            >
              <option value="all">{t("allRegions")}</option>
              {REGIONS.map((r) => (
                <option key={r.id} value={r.name}>
                  {lang === "en" ? r.name : r.nameKa}
                </option>
              ))}
            </select>
            <select
              value={severity}
              onChange={(e) => setSeverity(e.target.value as "all" | Severity)}
              aria-label={t("filterSeverity")}
              className="rounded-full border border-[rgba(20,43,37,0.18)] bg-white/55 px-3 py-2 text-[11px] font-semibold text-[var(--ink-2)] outline-none"
            >
              <option value="all">{t("filterSeverity")}: {t("all")}</option>
              <option value="catastrophic">{t("catastrophic")}</option>
              <option value="major">{t("major")}</option>
              <option value="moderate">{t("moderate")}</option>
            </select>
            <button onClick={reset} className="flex items-center gap-1 rounded-full px-2 py-1.5 text-[10px] font-bold uppercase tracking-wide text-[var(--muted)] hover:bg-[rgba(20,43,37,0.06)]">
              <SlidersHorizontal size={12} /> {t("resetFilters")}
            </button>
          </div>

          <div className="mt-2.5 flex flex-wrap gap-1">
            {HAZARD_KEYS.map((h) => {
              const active = hazards.has(h);
              return (
                <button
                  key={h}
                  onClick={() => toggleHazard(h)}
                  aria-pressed={active}
                  className={`flex items-center gap-1 rounded-full border px-2 py-1 text-[9.5px] font-semibold transition-all ${
                    active ? "text-white" : "border-[rgba(20,43,37,0.18)] text-[var(--muted)] hover:border-[rgba(20,43,37,0.35)]"
                  }`}
                  style={active ? { background: HAZARD_META[h].color, borderColor: HAZARD_META[h].color } : undefined}
                >
                  <HazardGlyph hazard={h} size={11} />
                  {bi(HAZARD_META[h].label)}
                </button>
              );
            })}
          </div>

          <div className="mt-3 grid gap-x-5 gap-y-1 border-t border-[rgba(20,43,37,0.1)] pt-2.5 sm:grid-cols-2">
            <label className="block">
              <span className="flex items-center justify-between text-[9px] font-bold uppercase tracking-wide text-[var(--muted)]">
                <span>{lang === "en" ? "From year" : "წლიდან"}</span>
                <span className="tabular-nums text-[var(--ink)]">{from}</span>
              </span>
              <input
                type="range"
                min={MIN_YEAR}
                max={MAX_YEAR}
                value={from}
                onChange={(e) => setFrom(Math.min(Number(e.target.value), to))}
                className="mt-1 w-full"
                aria-label={lang === "en" ? "From year" : "წლიდან"}
              />
            </label>
            <label className="block">
              <span className="flex items-center justify-between text-[9px] font-bold uppercase tracking-wide text-[var(--muted)]">
                <span>{lang === "en" ? "To year" : "წლამდე"}</span>
                <span className="tabular-nums text-[var(--ink)]">{to}</span>
              </span>
              <input
                type="range"
                min={MIN_YEAR}
                max={MAX_YEAR}
                value={to}
                onChange={(e) => setTo(Math.max(Number(e.target.value), from))}
                className="mt-1 w-full"
                aria-label={lang === "en" ? "To year" : "წლამდე"}
              />
            </label>
          </div>
        </div>

        {/* records */}
        <div className="mt-4">
          {filtered.length === 0 ? (
            <div className="card flex flex-col items-center gap-2 px-6 py-12 text-center">
              <CircleAlert size={22} className="text-[var(--clay)]" />
              <p className="text-[13px] font-semibold text-[var(--ink)]">{t("noResults")}</p>
              <button onClick={reset} className="btn btn-ghost !py-1.5 !text-[10px]">
                {t("resetFilters")}
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filtered.map((e) => {
                const open = openId === e.id;
                const meta = HAZARD_META[e.hazard];
                const sources = e.sources.map((s) => SOURCE_INDEX.get(s)).filter(Boolean);
                return (
                  <article key={e.id} id={`event-${e.id}`} className={`card overflow-hidden transition-shadow ${open ? "shadow-md" : ""}`}>
                    <button onClick={() => setOpenId(open ? null : e.id)} className="flex w-full items-start gap-3 p-3.5 text-left hover:bg-[rgba(20,43,37,0.025)] sm:gap-4">
                      <div className="hidden w-[74px] shrink-0 border-r border-[rgba(20,43,37,0.12)] pr-2 sm:block">
                        <p className="display text-[19px] leading-none text-[var(--ink)]">{e.startDate.slice(0, 4)}</p>
                        <p className="mt-0.5 text-[9px] text-[var(--muted)]">{bi(e.dateLabel).replace(/,\s*\d{4}/, "")}</p>
                        <span className="mt-1.5 inline-block rounded px-1 py-0.5 text-[8px] font-bold uppercase tracking-wide text-white" style={{ background: meta.color }}>
                          {e.hazard === "earthquake" ? (lang === "en" ? "Seismic" : "სეისმ.") : bi(meta.label).split(" ")[0]}
                        </span>
                      </div>
                      <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white sm:h-9 sm:w-9" style={{ background: meta.color }}>
                        <HazardGlyph hazard={e.hazard} size={17} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[9px] font-bold uppercase tracking-wide text-[var(--muted)] sm:hidden">{e.startDate.slice(0, 4)}</span>
                          <span
                            className="rounded-full px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide"
                            style={{ color: severityColor[e.severity], background: `${severityColor[e.severity]}14` }}
                          >
                            {t(e.severity)}
                          </span>
                          {e.confidence !== "documented" && (
                            <span className="rounded-full border border-[#dcc59d] bg-[#f7eddc] px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide text-[#85592a]">
                              {t(e.confidence === "partial" ? "partial" : "figuresDisputed")}
                            </span>
                          )}
                        </div>
                        <h3 className="display mt-0.5 text-[17px] leading-tight text-[var(--ink)] sm:text-[19px]">{bi(e.title)}</h3>
                        <p className="mt-0.5 flex items-start gap-1 text-[10px] text-[var(--muted)]">
                          <MapPin size={10} className="mt-0.5 shrink-0" />
                          <span>
                            {bi(e.location)} · {lang === "en" ? e.dateLabel.en : e.dateLabel.ka}
                          </span>
                        </p>
                        {!open && (
                          <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-[var(--ink-2)]">{bi(e.summary)}</p>
                        )}
                      </div>
                      <div className="hidden shrink-0 flex-col items-end gap-1 sm:flex">
                        <span className="text-[8.5px] text-[var(--muted)]">{sources.length} {t("sources")}</span>
                        <span className="flex h-6 w-6 items-center justify-center rounded-full border border-[rgba(20,43,37,0.15)] text-[var(--muted)]">
                          <ArrowRight size={12} className={`transition-transform ${open ? "rotate-90" : ""}`} />
                        </span>
                      </div>
                    </button>
                    {open && (
                      <div className="border-t border-[rgba(20,43,37,0.1)] bg-[rgba(20,43,37,0.018)] px-4 py-3.5 sm:px-[110px]">
                        <p className="text-[11.5px] leading-relaxed text-[var(--ink-2)]">{bi(e.summary)}</p>
                        <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">{bi(e.context)}</p>
                        <div className="mt-3 grid gap-2 sm:grid-cols-3">
                          <Loss label={t("killed")} value={bi(e.casualties)} />
                          <Loss label={t("affected")} value={bi(e.affected)} />
                          <Loss label={t("damage")} value={bi(e.damage)} />
                        </div>
                        {e.confidenceNote && (
                          <div className="mt-3 flex gap-1.5 rounded-lg border border-[#dcc59d] bg-[#f7eddc] px-3 py-2">
                            <CircleAlert size={12} className="mt-0.5 shrink-0 text-[#8a6329]" />
                            <p className="text-[9.5px] leading-relaxed text-[#6f5630]">
                              <strong>{t("evidenceNote")}:</strong> {bi(e.confidenceNote)}
                            </p>
                          </div>
                        )}
                        <div className="mt-3 flex flex-wrap gap-1.5">
                          {sources.map(
                            (s) =>
                              s && (
                                <a
                                  key={s.id}
                                  href={s.url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex max-w-full items-center gap-1 rounded-full border border-[rgba(20,43,37,0.16)] bg-white/50 px-2 py-1 text-[9px] text-[var(--ink-2)] hover:border-[rgba(20,43,37,0.35)]"
                                >
                                  <ArrowUpRight size={9} className="shrink-0" />
                                  <span className="truncate">{s.publisher} ({s.year})</span>
                                </a>
                              )
                          )}
                        </div>
                        <div className="mt-3 flex flex-wrap gap-1.5">
                          <button onClick={() => onOpenMap(e.id)} className="btn btn-primary !py-1.5 !text-[10px]">
                            <MapPin size={11} /> {t("viewOnMap")}
                          </button>
                          <button onClick={() => onOpenGuide(e.hazard)} className="btn btn-ghost !py-1.5 !text-[10px]">
                            {t("readGuide")} <ArrowRight size={11} />
                          </button>
                        </div>
                        <p className="mt-2 text-[8.5px] text-[var(--muted)]">
                          {regionLabel(e.region)} · {t("impact")}: {t(e.severity)}
                        </p>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </div>
        <p className="mt-4 flex items-start gap-1.5 text-[9.5px] leading-relaxed text-[var(--muted)]">
          <CircleAlert size={12} className="mt-0.5 shrink-0" />
          {t("severityNote")}
        </p>
      </section>
    </div>
  );

  function regionLabel(name: string) {
    return lang === "en" ? name : REGION_NAME_KA[name] ?? name;
  }
}

function Loss({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-[rgba(20,43,37,0.12)] bg-[var(--cream)] px-2.5 py-2">
      <p className="text-[8px] font-bold uppercase tracking-[0.06em] text-[var(--muted)]">{label}</p>
      <p className="mt-0.5 text-[10.5px] leading-snug text-[var(--ink-2)]">{value}</p>
    </div>
  );
}
