import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  CircleAlert,
  Database,
  ExternalLink,
  FileText,
  Landmark,
  Library,
  Map as MapIcon,
  Newspaper,
  Search,
  Siren,
  Telescope,
} from "lucide-react";
import { useI18n } from "../i18n";
import { SOURCES, ACCESSED } from "../data/sources";
import { INCIDENTS } from "../data/incidents";
import { REGIONS } from "../data/regions";

const TYPE_META: Record<
  string,
  { label: { en: string; ka: string }; color: string; icon: typeof FileText }
> = {
  official: { label: { en: "Official / agency", ka: "ოფიციალური" }, color: "#2f5547", icon: Landmark },
  scientific: { label: { en: "Scientific", ka: "სამეცნიერო" }, color: "#2f6f8f", icon: Telescope },
  database: { label: { en: "Database", ka: "მონაცემთა ბაზა" }, color: "#5c7597", icon: Database },
  news: { label: { en: "News report", ka: "მედია" }, color: "#8a6a2f", icon: Newspaper },
  encyclopedia: { label: { en: "Encyclopedia", ka: "ენციკლოპედია" }, color: "#8a7455", icon: BookOpen },
  data: { label: { en: "Geospatial data", ka: "გეომონაცემები" }, color: "#3c7c78", icon: MapIcon },
};

const GAPS: { title: { en: string; ka: string }; body: { en: string; ka: string } }[] = [
  {
    title: { en: "1991 Racha fatalities differ by more than a factor of two", ka: "1991 რაჭის მსხვერპლთა რიცხვი ორზე მეტჯერ განსხვავდება" },
    body: {
      en: "A USGS field study reports at least 114 deaths; widely repeated compilations give 270. The atlas shows both and does not choose a single figure.",
      ka: "USGS-ის კვლევა მინიმუმ 114 მსხვერპლს ასახელებს, გავრცელებული შეჯამებები — 270. ატლასი ორივეს აჩვენებს და ერთ ციფრს არ ირჩევს.",
    },
  },
  {
    title: { en: "1987 Svaneti avalanche toll is not consistently recorded", ka: "1987 სვანეთის ზვავების მსხვერპლი თანმიმდევრულად არ არის აღრიცხული" },
    body: {
      en: "National Geographic reports 'at least 80'; Wikidata lists 105. Village-level losses were not found in accessible sources.",
      ka: "National Geographic ასახელებს „მინიმუმ 80“-ს, Wikidata — 105-ს. სოფლების მიხედვით დანაკარგები ხელმისაწვდომ წყაროებში ვერ მოიძებნა.",
    },
  },
  {
    title: { en: "Borjomi 2017: 100 ha vs 646 ha", ka: "ბორჯომი 2017: 100 ჰა 646 ჰა-ს წინააღმდეგ" },
    body: {
      en: "The official public estimate was roughly 100 ha, while Copernicus EMS mapped 646 ha in the Daba area. These may reflect different methods and perimeters; both are reported.",
      ka: "ოფიციალური საჯარო შეფასება ~100 ჰა იყო, Copernicus EMS-მა დაბის არეალში 646 ჰა დააფიქსირა. შესაძლოა მეთოდები და კონტურები განსხვავდებოდეს; ორივე მოცემულია.",
    },
  },
  {
    title: { en: "Tbilisi 2015: initial count vs final recovery", ka: "თბილისი 2015: საწყისი და საბოლოო მონაცემები" },
    body: {
      en: "Twenty deaths were initially confirmed; later reporting cites 21–24 and two missing. The record gives the range and dates it.",
      ka: "თავდაპირველად 20 გარდაცვალება დადასტურდა; გვიანდელი ცნობები 21–24 მსხვერპლსა და 2 დაკარგულს ასახელებს. ჩანაწერი დიაპაზონს და დროს მიუთითებს.",
    },
  },
  {
    title: { en: "Shovi 2023: counts evolved during search", ka: "შოვი 2023: მონაცემები ძებნის დროს იცვლებოდა" },
    body: {
      en: "Daily figures rose as bodies were recovered. The atlas uses the final official count of 32 dead and one missing, while citing early reports for context.",
      ka: "ყოველდღიური მონაცემები იზრდებოდა. ატლასი იყენებს საბოლოო ოფიციალურ 32 დაღუპულსა და 1 დაკარგულს, ადრეულ ცნობებს კონტექსტისთვის ციტირებს.",
    },
  },
  {
    title: { en: "Occupied territories and restricted access", ka: "ოკუპირებული ტერიტორიები და შეზღუდული წვდომა" },
    body: {
      en: "Verified incident-level data for Abkhazia and the Tskhinvali region/South Ossetia are limited in the sources we could access. The atlas marks this as a data gap and includes the territory de jure without implying political recognition of any change.",
      ka: "აფხაზეთისა და ცხინვალის რეგიონის/სამხრეთ ოსეთის დადასტურებული ინციდენტური მონაცემები ხელმისაწვდომ წყაროებში შეზღუდულია. ატლასი ამას ხარვეზად აღნიშნავს და ტერიტორიას დე იურე მოიცავს, პოლიტიკური ცვლილების აღიარების გარეშე.",
    },
  },
  {
    title: { en: "Damage not quantified for some recent events", ka: "ზოგიერთი ბოლო მოვლენის ზარალი არ არის განსაზღვრული" },
    body: {
      en: "Losses for the September 2023 Guria floods and December 2024 Batumi windstorm were not published in the sources consulted. The records say so instead of inventing figures.",
      ka: "2023 წლის სექტემბრის გურიის წყალდიდობისა და 2024 წლის დეკემბრის ბათუმის ქარიშხლის ზარალი გამოყენებულ წყაროებში არ გამოქვეყნდა. ჩანაწერები ამას აღნიშნავს და ციფრებს არ იგონებს.",
    },
  },
  {
    title: { en: "Hazard zones are coarse, not parcels", ka: "საფრთხის ზონები უხეშია და არა ნაკვეთები" },
    body: {
      en: "Zones were drawn from national-scale mapping and published descriptions for orientation. They are not suitable for a permit decision, insurance underwriting or evacuation planning at an address level.",
      ka: "ზონები ეროვნული მასშტაბის რუკებსა და გამოქვეყნებულ აღწერებს ეყრდნობა ორიენტაციისთვის. ისინი არ გამოდგება ნებართვის გადაწყვეტილებისთვის, დაზღვევისთვის ან მისამართის დონის ევაკუაციისთვის.",
    },
  },
  {
    title: { en: "Encyclopedic sources used only as pointers", ka: "ენციკლოპედიური წყაროები მხოლოდ მაჩვენებლად" },
    body: {
      en: "Wikipedia/Wikidata entries were cross-checked against scientific, official or news sources where possible. Uncertain figures are never presented as official statistics.",
      ka: "Wikipedia/Wikidata ჩანაწერები შედარებულია სამეცნიერო, ოფიციალურ ან მედია წყაროებთან. გაურკვეველი ციფრები ოფიციალურ სტატისტიკად არასოდეს არის წარმოდგენილი.",
    },
  },
];

const METHOD = [
  {
    n: "01",
    title: { en: "Hazard identification", ka: "საფრთხეების გამოვლენა" },
    body: {
      en: "Reviewed national hazard mapping and scientific literature covering seismic, hydrological, geomorphological, meteorological and coastal processes.",
      ka: "განხილულია ეროვნული რისკის რუკები და სამეცნიერო ლიტერატურა სეისმური, ჰიდროლოგიური, გეომორფოლოგიური, მეტეოროლოგიური და სანაპირო პროცესების შესახებ.",
    },
  },
  {
    n: "02",
    title: { en: "Event verification", ka: "მოვლენების გადამოწმება" },
    body: {
      en: "Recorded only dated, located incidents with attributable reporting. Cross-checked casualty and damage figures; where sources conflict, ranges are shown.",
      ka: "შეტანილია მხოლოდ დათარიღებული, მდებარეობის მქონე და დასახელებული წყაროს მქონე მოვლენები. მსხვერპლისა და ზარალის ციფრები შედარებულია; განსხვავებისას დიაპაზონია მოცემული.",
    },
  },
  {
    n: "03",
    title: { en: "Geographic screening", ka: "გეოგრაფიული შეფასება" },
    body: {
      en: "Translated published susceptibility into deliberately coarse zones and wrote 12 qualitative regional profiles, explicitly separated from dated events.",
      ka: "გამოქვეყნებული მოწყვლადობა გარდაიქმნა განზრახ უხეშ ზონებად და შედგა 12 თვისებრივი რეგიონული პროფილი, ცალკე დათარიღებული მოვლენებისგან.",
    },
  },
  {
    n: "04",
    title: { en: "Preparedness research", ka: "მზადყოფნის კვლევა" },
    body: {
      en: "Compiled actionable before/during/after guidance for eight hazard families, with attention to children, older people and people with disabilities.",
      ka: "შედგა რვა საფრთხის ოჯახისთვის ქმედითი ინსტრუქციები „მანამდე/დროს/შემდეგ“, ყურადღებით ბავშვებზე, მოხუცებსა და შეზღუდული შესაძლებლობის მქონე პირებზე.",
    },
  },
  {
    n: "05",
    title: { en: "Review & source trail", ka: "გადახედვა და წყაროები" },
    body: {
      en: "Re-checked gaps, resolved avoidable contradictions, documented the remaining ones, and linked every event to its sources.",
      ka: "ხელახლა შემოწმდა ხარვეზები, აღმოიფხვრა თავიდან ასაცილებელი წინააღმდეგობები, დანარჩენი დოკუმენტირდა და ყოველი მოვლენა წყაროებს დაუკავშირდა.",
    },
  },
];

export function SourcesPage({ onOpenEmergency }: { onOpenEmergency: () => void }) {
  const { t, bi, lang } = useI18n();
  const [type, setType] = useState<string>("all");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return SOURCES.filter((s) => {
      if (type !== "all" && s.type !== type) return false;
      if (!query) return true;
      return [s.publisher, s.title, s.supports, s.year].join(" ").toLowerCase().includes(query);
    });
  }, [type, q]);

  const typeCounts = useMemo(() => {
    const map = new Map<string, number>();
    SOURCES.forEach((s) => map.set(s.type, (map.get(s.type) ?? 0) + 1));
    return map;
  }, []);

  return (
    <div>
      <section className="border-b border-[rgba(20,43,37,0.13)] bg-[var(--paper)] paper-grain">
        <div className="mx-auto max-w-[1440px] px-4 pb-8 pt-9 sm:px-6">
          <div className="grid gap-7 lg:grid-cols-[1fr_350px] lg:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2.5">
                <span className="h-px w-6 bg-[var(--clay)]" />
                <p className="eyebrow">{t("sourcesKicker")}</p>
              </div>
              <h1 className="display text-[36px] leading-[1.02] sm:text-[48px]">{t("sourcesTitle")}</h1>
              <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[var(--ink-2)]">{t("sourcesIntro")}</p>
            </div>
            <div className="card p-4">
              <div className="grid grid-cols-3 divide-x divide-[rgba(20,43,37,0.1)] text-center">
                <div>
                  <p className="display text-[27px] leading-none">{SOURCES.length}</p>
                  <p className="mt-1 text-[8px] font-bold uppercase tracking-wide text-[var(--muted)]">{t("sources")}</p>
                </div>
                <div>
                  <p className="display text-[27px] leading-none">{INCIDENTS.length}</p>
                  <p className="mt-1 text-[8px] font-bold uppercase tracking-wide text-[var(--muted)]">{t("statEvents")}</p>
                </div>
                <div>
                  <p className="display text-[27px] leading-none">12</p>
                  <p className="mt-1 text-[8px] font-bold uppercase tracking-wide text-[var(--muted)]">{t("statRegions")}</p>
                </div>
              </div>
              <p className="mt-2.5 border-t border-[rgba(20,43,37,0.1)] pt-2 text-[9.5px] leading-snug text-[var(--muted)]">
                {t("researchDate")}: <strong className="text-[var(--ink)]">June 2026</strong> · {t("accessedLabel")}: {ACCESSED}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6">
        {/* classification */}
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--forest)] text-white">
              <CheckCircle2 size={15} />
            </span>
            <h2 className="display text-[23px]">{t("methodology")}</h2>
          </div>
          <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { k: "class1", d: "class1Desc", color: "#b9542f", icon: MapIcon },
              { k: "class2", d: "class2Desc", color: "#b68a34", icon: LayersIcon },
              { k: "class3", d: "class3Desc", color: "#2f6f8f", icon: Telescope },
              { k: "class4", d: "class4Desc", color: "#8f2f19", icon: Siren },
            ].map((item) => (
              <div
                key={item.k}
                className={`card overflow-hidden p-3.5 ${item.k === "class4" ? "relative" : ""}`}
                style={{ borderTop: `3px solid ${item.color}` }}
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full text-white" style={{ background: item.color }}>
                    <item.icon size={13} />
                  </span>
                  {item.k === "class4" && (
                    <span className="rounded-full bg-[rgba(143,47,25,0.1)] px-1.5 py-0.5 text-[7.5px] font-bold uppercase tracking-wide text-[#8f2f19]">
                      {lang === "en" ? "not displayed" : "არ ჩანს"}
                    </span>
                  )}
                </div>
                <p className="mt-2 text-[11.5px] font-bold text-[var(--ink)]">{t(item.k as "class1")}</p>
                <p className="mt-1 text-[10px] leading-relaxed text-[var(--muted)]">{t(item.d as "class1Desc")}</p>
                {item.k === "class4" && (
                  <button onClick={onOpenEmergency} className="mt-2 flex items-center gap-1 text-[9.5px] font-bold text-[var(--clay)] hover:underline">
                    <Siren size={10} /> 112 · {t("emergencyBtn")}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="card mt-4 overflow-hidden">
          <div className="flex items-center gap-2 border-b border-[rgba(20,43,37,0.11)] px-4 py-2.5">
            <BookOpen size={15} className="text-[var(--forest)]" />
            <h2 className="text-[12px] font-bold text-[var(--ink)]">{lang === "en" ? "Research process — five rounds" : "კვლევითი პროცესი — ხუთი ეტაპი"}</h2>
          </div>
          <div className="grid divide-y divide-[rgba(20,43,37,0.09)] sm:grid-cols-2 sm:divide-y-0 lg:grid-cols-5">
            {METHOD.map((m) => (
              <div key={m.n} className="border-[rgba(20,43,37,0.09)] p-3.5 lg:border-r lg:last:border-r-0">
                <p className="display text-[20px] leading-none text-[var(--gold)]">{m.n}</p>
                <p className="mt-1.5 text-[10.5px] font-bold leading-tight text-[var(--ink)]">{bi(m.title)}</p>
                <p className="mt-1 text-[9px] leading-relaxed text-[var(--muted)]">{bi(m.body)}</p>
              </div>
            ))}
          </div>
        </div>

        {/* bibliography */}
        <div className="mt-7">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--ink)] text-white">
                <Library size={14} />
              </span>
              <h2 className="display text-[24px]">{t("bibliography")}</h2>
              <span className="chip !text-[9px]">{filtered.length}/{SOURCES.length}</span>
            </div>
            <p className="max-w-md text-[9px] leading-relaxed text-[var(--muted)]">{t("sourcesLangNote")}</p>
          </div>

          <div className="card mt-3 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[200px] flex-1">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={lang === "en" ? "Search publishers, titles, topics…" : "მოძებნეთ გამომცემელი, სათაური, თემა…"}
                  className="w-full rounded-full border border-[rgba(20,43,37,0.18)] bg-white/55 py-2 pl-8 pr-3 text-[11px] outline-none placeholder:text-[var(--muted)] focus:border-[var(--forest)]"
                />
              </div>
              <div className="flex flex-wrap gap-1">
                <button onClick={() => setType("all")} className={`chip !text-[9px] ${type === "all" ? "chip-active" : ""}`}>
                  {t("all")} · {SOURCES.length}
                </button>
                {Object.entries(TYPE_META).map(([key, meta]) => (
                  <button
                    key={key}
                    onClick={() => setType(key)}
                    className={`flex items-center gap-1 rounded-full border px-2 py-1 text-[9px] font-semibold ${
                      type === key ? "text-white" : "border-[rgba(20,43,37,0.17)] text-[var(--muted)] hover:border-[rgba(20,43,37,0.34)]"
                    }`}
                    style={type === key ? { background: meta.color, borderColor: meta.color } : undefined}
                  >
                    <meta.icon size={10} />
                    {bi(meta.label)} · {typeCounts.get(key) ?? 0}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-3 grid gap-2 md:grid-cols-2">
            {filtered.map((s) => {
              const meta = TYPE_META[s.type];
              return (
                <article key={s.id} className="card p-3.5">
                  <div className="flex items-start gap-2.5">
                    <span className="display mt-0.5 w-6 shrink-0 text-[14px] text-[var(--gold)]">
                      {String(SOURCES.indexOf(s) + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1">
                        <span
                          className="flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[7.5px] font-bold uppercase tracking-wide text-white"
                          style={{ background: meta.color }}
                        >
                          <meta.icon size={8} />
                          {bi(meta.label)}
                        </span>
                        <span className="text-[8.5px] text-[var(--muted)]">{t("accessedLabel")}: {ACCESSED}</span>
                      </div>
                      <p className="mt-1.5 text-[10px] font-bold uppercase tracking-[0.05em] text-[var(--forest)]">{s.publisher}</p>
                      <a
                        href={s.url}
                        target="_blank"
                        rel="noreferrer"
                        className="group mt-0.5 flex items-start gap-1 text-[12px] font-semibold leading-snug text-[var(--ink)] hover:text-[var(--forest)]"
                      >
                        {s.title}
                        <ArrowUpRight size={11} className="mt-0.5 shrink-0 opacity-55 group-hover:opacity-100" />
                      </a>
                      <p className="mt-0.5 text-[9px] tabular-nums text-[var(--muted)]">{s.year} · {s.language}</p>
                      <p className="mt-1.5 border-t border-[rgba(20,43,37,0.08)] pt-1.5 text-[9.5px] leading-relaxed text-[var(--muted)]">
                        <span className="font-bold text-[var(--ink-2)]">{t("whatItSupports")}: </span>
                        {s.supports}
                      </p>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
          {filtered.length === 0 && (
            <div className="card mt-3 px-5 py-8 text-center text-[12px] text-[var(--muted)]">{t("noResults")}</div>
          )}
        </div>

        {/* gaps */}
        <div className="mt-7">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--clay)] text-white">
              <AlertTriangle size={14} />
            </span>
            <h2 className="display text-[24px]">{t("gapsTitle")}</h2>
          </div>
          <div className="mt-3 grid gap-2.5 md:grid-cols-2 lg:grid-cols-3">
            {GAPS.map((g, i) => (
              <div key={i} className="card p-3.5">
                <p className="flex items-start gap-1.5 text-[11px] font-bold leading-snug text-[var(--ink)]">
                  <CircleAlert size={13} className="mt-0.5 shrink-0 text-[var(--clay)]" />
                  {bi(g.title)}
                </p>
                <p className="mt-1.5 text-[10px] leading-relaxed text-[var(--muted)]">{bi(g.body)}</p>
              </div>
            ))}
          </div>
        </div>

        {/* credits */}
        <div className="mt-6 grid gap-3 md:grid-cols-2">
          <div className="card p-4">
            <p className="eyebrow">{t("licenseTitle")}</p>
            <p className="mt-1.5 text-[10.5px] leading-relaxed text-[var(--ink-2)]">
              {lang === "en"
                ? "Administrative boundaries: geoBoundaries GEO ADM1/ADM2, CC BY 3.0 (William & Mary geoLab; source data from Wikimedia). Projection and simplification were performed for this atlas. Source publications remain under their own rights."
                : "ადმინისტრაციული საზღვრები: geoBoundaries GEO ADM1/ADM2, CC BY 3.0 (William & Mary geoLab; წყარო — Wikimedia). პროექცია და გამარტივება ამ ატლასისთვის შეიქმნა. პუბლიკაციების უფლებები მათ ავტორებს ეკუთვნით."}
            </p>
            <a
              href="https://www.geoboundaries.org/"
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-[10px] font-semibold text-[var(--forest)] hover:underline"
            >
              geoBoundaries <ExternalLink size={10} />
            </a>
          </div>
          <div className="rounded-xl border border-[rgba(185,84,47,0.28)] bg-[rgba(185,84,47,0.06)] p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-[#7d3b21]">
              <AlertTriangle size={12} /> {lang === "en" ? "What this atlas is not" : "რა არ არის ეს ატლასი"}
            </p>
            <p className="mt-1.5 text-[10.5px] leading-relaxed text-[#6d4a35]">
              {lang === "en"
                ? "It is not an official warning product, a real-time monitor, an evacuation guide for a current incident, a substitute for local emergency instructions, or a parcel-level risk certificate. It contains no fabricated events, casualty figures or coordinates. For an emergency call 112."
                : "ეს არ არის ოფიციალური გაფრთხილების პროდუქტი, რეალურ დროში მონიტორინგი, მიმდინარე ინციდენტის ევაკუაციის გზამკვლევი ან უძრავი ქონების რისკის სერტიფიკატი. არ შეიცავს გამოგონილ მოვლენებსა თუ ციფრებს. საგანგებო სიტუაციისას დარეკეთ 112-ში."}
            </p>
            <div className="mt-2 flex gap-1.5">
              <button onClick={onOpenEmergency} className="btn btn-clay !py-1.5 !text-[10px]">
                <Siren size={11} /> {t("emergencyBtn")}
              </button>
              <span className="chip !text-[8.5px]">{REGIONS.length} {t("statRegions")}</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function LayersIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3l9 5-9 5-9-5 9-5z" />
      <path d="M3 13l9 5 9-5" />
      <path d="M3 17.5l9 5 9-5" opacity="0.5" />
    </svg>
  );
}
