import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Building2,
  Check,
  ChevronRight,
  CircleAlert,
  ExternalLink,
  MapPin,
  Phone,
  ShieldCheck,
  Siren,
} from "lucide-react";
import { useI18n } from "../i18n";
import { GEO } from "../data/geo";
import { INCIDENTS } from "../data/incidents";
import { REGIONS } from "../data/regions";
import { HAZARD_KEYS, HAZARD_META, type HazardKey } from "../types";
import { HazardGlyph } from "../components/HazardGlyph";
import { RegionMiniMap } from "../components/RegionMiniMap";

const REGION_GEO = new Map<string, (typeof GEO.regions)[number]>(GEO.regions.map((r) => [r.name, r]));
const REGIONAL_LINKS = [
  { label: "112 Georgia", url: "https://112.gov.ge/", desc: "Unified emergency call service" },
  { label: "National Environmental Agency", url: "https://nea.gov.ge/", desc: "Hydrometeorology & geology" },
  { label: "Emergency Situations Management Service", url: "https://police.ge/en", desc: "Rescue & civil protection" },
  { label: "Ministry of Environmental Protection & Agriculture", url: "https://mepa.gov.ge/En", desc: "Hazard, climate & agricultural information" },
];

export function RegionsPage({
  initialRegionId,
  onOpenIncident,
  onOpenGuide,
  onOpenEmergency,
}: {
  initialRegionId?: string | null;
  onOpenIncident: (id: string) => void;
  onOpenGuide: (h: HazardKey) => void;
  onOpenEmergency: () => void;
}) {
  const { t, bi, lang } = useI18n();
  const [selectedId, setSelectedId] = useState(initialRegionId ?? "tbilisi");
  const [hazardFilter, setHazardFilter] = useState<HazardKey | "all">("all");
  const detailRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialRegionId) setSelectedId(initialRegionId);
  }, [initialRegionId]);

  const selected = REGIONS.find((r) => r.id === selectedId) ?? REGIONS[0];
  const selectedGeo = REGION_GEO.get(selected.name);
  const incidents = selected.incidents.map((id) => INCIDENTS.find((i) => i.id === id)).filter(Boolean);
  const municipalities = GEO.municipalities.filter((m) => m.region === selected.name);
  const filteredRegions = REGIONS.filter((r) => hazardFilter === "all" || r.hazards.includes(hazardFilter));

  const choose = (id: string) => {
    setSelectedId(id);
    window.setTimeout(() => detailRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 40);
  };

  const hazardCount = useMemo(() => {
    const m = new Map<HazardKey, number>();
    HAZARD_KEYS.forEach((h) => m.set(h, REGIONS.filter((r) => r.hazards.includes(h)).length));
    return m;
  }, []);

  return (
    <div>
      <section className="border-b border-[rgba(20,43,37,0.13)] bg-[var(--paper)] paper-grain">
        <div className="mx-auto max-w-[1440px] px-4 pb-8 pt-9 sm:px-6">
          <div className="grid gap-7 lg:grid-cols-[1fr_350px] lg:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2.5">
                <span className="h-px w-6 bg-[var(--clay)]" />
                <p className="eyebrow">{t("regionsKicker")}</p>
              </div>
              <h1 className="display text-[36px] leading-[1.02] sm:text-[48px]">{t("regionsTitle")}</h1>
              <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[var(--ink-2)]">{t("regionsIntro")}</p>
            </div>
            <div className="card overflow-hidden">
              <div className="flex items-center gap-2 bg-[var(--forest)] px-4 py-2.5 text-[var(--cream)]">
                <ShieldCheck size={15} />
                <p className="text-[10.5px] font-bold uppercase tracking-[0.08em]">{lang === "en" ? "How to read a profile" : "როგორ წავიკითხოთ პროფილი"}</p>
              </div>
              <div className="p-3.5">
                <p className="text-[10.5px] leading-relaxed text-[var(--ink-2)]">{t("regionDataNote")}</p>
                <div className="mt-2 flex gap-1.5">
                  <span className="chip !text-[8.5px]">{REGIONS.length} {t("statRegions")}</span>
                  <span className="chip !text-[8.5px]">{GEO.municipalities.length} {t("allMunicipalities")}</span>
                  <span className="chip !text-[8.5px]">{HAZARD_KEYS.length} {t("statHazards")}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setHazardFilter("all")}
            className={`chip ${hazardFilter === "all" ? "chip-active" : ""}`}
            aria-pressed={hazardFilter === "all"}
          >
            {t("allHazards")}
          </button>
          {HAZARD_KEYS.map((h) => (
            <button
              key={h}
              onClick={() => setHazardFilter(h)}
              aria-pressed={hazardFilter === h}
              className={`flex items-center gap-1 rounded-full border px-2 py-1 text-[9.5px] font-semibold transition-all ${
                hazardFilter === h ? "text-white" : "border-[rgba(20,43,37,0.18)] text-[var(--muted)] hover:border-[rgba(20,43,37,0.35)]"
              }`}
              style={hazardFilter === h ? { background: HAZARD_META[h].color, borderColor: HAZARD_META[h].color } : undefined}
            >
              <HazardGlyph hazard={h} size={11} />
              {bi(HAZARD_META[h].label)}
              <span className="opacity-70">{hazardCount.get(h)}</span>
            </button>
          ))}
        </div>

        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredRegions.map((r) => {
            const geo = REGION_GEO.get(r.name);
            const active = r.id === selected.id;
            return (
              <button
                key={r.id}
                onClick={() => choose(r.id)}
                className={`card group relative overflow-hidden p-3.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-md ${
                  active ? "!border-[var(--forest)] ring-1 ring-[var(--forest)]" : ""
                }`}
                aria-pressed={active}
              >
                {active && <span className="absolute left-0 top-0 h-full w-[3px] bg-[var(--forest)]" />}
                <div className="flex items-start gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-[rgba(20,43,37,0.1)] bg-[rgba(47,85,71,0.05)]">
                    {geo ? (
                      <RegionMiniMap regionName={r.name} className="h-9 w-10" />
                    ) : (
                      <MapPin size={18} />
                    )}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-1">
                      <p className="display text-[16px] leading-tight text-[var(--ink)]">{lang === "en" ? r.name : r.nameKa}</p>
                      <ChevronRight size={13} className="mt-0.5 shrink-0 text-[var(--line)] group-hover:text-[var(--forest)]" />
                    </div>
                    <p className="mt-0.5 flex items-center gap-1 text-[9px] text-[var(--muted)]">
                      <MapPin size={9} /> {bi(r.center)} · {r.code}
                    </p>
                  </div>
                </div>
                <p className="mt-2 line-clamp-2 text-[10px] leading-relaxed text-[var(--muted)]">{bi(r.blurb)}</p>
                <div className="mt-2 flex flex-wrap items-center gap-1">
                  {r.hazards.slice(0, 4).map((h) => (
                    <span
                      key={h}
                      title={bi(HAZARD_META[h].label)}
                      className="flex h-5 w-5 items-center justify-center rounded-full"
                      style={{ color: HAZARD_META[h].dark, background: `${HAZARD_META[h].color}16` }}
                    >
                      <HazardGlyph hazard={h} size={11} />
                    </span>
                  ))}
                  {r.hazards.length > 4 && <span className="text-[8.5px] font-semibold text-[var(--muted)]">+{r.hazards.length - 4}</span>}
                  <span className="ml-auto text-[8.5px] text-[var(--muted)]">
                    {r.incidents.length > 0 ? `${r.incidents.length} ${lang === "en" ? "records" : "ჩანაწერი"}` : t("dataGap")}
                  </span>
                </div>
                {r.partialData && (
                  <span className="absolute right-2 top-2 rounded bg-[#f4e4cf] px-1.5 py-0.5 text-[7.5px] font-bold uppercase tracking-wide text-[#8a5d2b]">
                    {t("partial")}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div ref={detailRef} className="mt-5 scroll-mt-28">
          <div className="card overflow-hidden fade-up" key={selected.id}>
            <div className="relative overflow-hidden bg-[#17302a] px-5 py-5 text-[var(--cream)] sm:px-6">
              <div className="topographic absolute inset-0 opacity-20" aria-hidden="true" />
              <div className="relative flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="eyebrow !text-[#e6b394]">{t("regionProfile")} · {selected.code}</p>
                  <h2 className="display mt-1 text-[30px] leading-tight sm:text-[36px]">{lang === "en" ? selected.name : selected.nameKa}</h2>
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-[#b7c3b7]">
                    <Building2 size={12} /> {bi(selected.center)} · {lang === "en" ? "administrative centre" : "ადმინისტრაციული ცენტრი"}
                  </p>
                  <p className="mt-2 max-w-2xl text-[12px] leading-relaxed text-[#cdd6cc]">{bi(selected.blurb)}</p>
                </div>
                {selectedGeo && (
                  <RegionMiniMap
                    regionName={selected.name}
                    className="h-24 w-32 shrink-0"
                    fill="rgba(255,255,255,0.14)"
                    stroke="rgba(255,255,255,0.55)"
                    strokeWidth={4}
                  />
                )}
              </div>
              <div className="relative mt-3 flex flex-wrap gap-1">
                {selected.hazards.map((h) => (
                  <button
                    key={h}
                    onClick={() => onOpenGuide(h)}
                    className="flex items-center gap-1 rounded-full border border-white/20 bg-white/10 px-2 py-1 text-[9.5px] font-semibold text-[#e4e9e1] hover:bg-white/20"
                  >
                    <HazardGlyph hazard={h} size={11} />
                    {bi(HAZARD_META[h].label)}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid gap-0 lg:grid-cols-[1.15fr_1fr]">
              <div className="border-b border-[rgba(20,43,37,0.11)] p-4 sm:p-5 lg:border-b-0 lg:border-r">
                <p className="eyebrow">{t("documentedHistory")}</p>
                {incidents.length === 0 ? (
                  <div className="mt-2 rounded-lg border border-dashed border-[rgba(20,43,37,0.22)] px-3 py-3">
                    <p className="text-[10.5px] leading-relaxed text-[var(--muted)]">{t("noIncidents")}</p>
                  </div>
                ) : (
                  <div className="mt-2 space-y-1.5">
                    {incidents.map(
                      (i) =>
                        i && (
                          <button
                            key={i.id}
                            onClick={() => onOpenIncident(i.id)}
                            className="group flex w-full items-center gap-2.5 rounded-lg border border-[rgba(20,43,37,0.11)] bg-white/40 px-2.5 py-2 text-left hover:border-[rgba(20,43,37,0.3)]"
                          >
                            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-white" style={{ background: HAZARD_META[i.hazard].color }}>
                              <HazardGlyph hazard={i.hazard} size={14} />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[11px] font-semibold text-[var(--ink)] group-hover:underline">{bi(i.title)}</span>
                              <span className="block text-[9px] text-[var(--muted)]">{bi(i.dateLabel)} · {bi(i.casualties)}</span>
                            </span>
                            <span className="hidden text-[8px] font-bold uppercase tracking-wide sm:block" style={{ color: HAZARD_META[i.hazard].dark }}>
                              {t(i.severity)}
                            </span>
                            <ArrowUpRight size={11} className="shrink-0 text-[var(--line)]" />
                          </button>
                        )
                    )}
                  </div>
                )}

                <div className="mt-4">
                  <p className="eyebrow">{t("vulnerabilities")}</p>
                  <ul className="mt-1.5 space-y-1.5">
                    {selected.vulnerabilities.map((v, i) => (
                      <li key={i} className="flex gap-2 text-[11px] leading-relaxed text-[var(--ink-2)]">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--clay)]" />
                        {bi(v)}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4">
                  <p className="eyebrow">{t("municipalityList")} · {municipalities.length}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {municipalities.length > 0 ? (
                      municipalities.map((m) => (
                        <span key={m.name} className="chip !text-[9px]">{m.name}</span>
                      ))
                    ) : (
                      <span className="text-[10px] text-[var(--muted)]">
                        {lang === "en" ? "Boundary dataset lists this as a city-level unit." : "საზღვრების მონაცემებში ეს ქალაქის დონის ერთეულია."}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-4 sm:p-5">
                <p className="eyebrow">{t("prepRecommendations")}</p>
                <ul className="mt-1.5 space-y-2">
                  {selected.preparedness.map((p, i) => (
                    <li key={i} className="flex gap-2 rounded-lg bg-[rgba(47,85,71,0.055)] px-2.5 py-2 text-[11px] leading-relaxed text-[var(--ink-2)]">
                      <Check size={13} className="mt-0.5 shrink-0 text-[var(--forest)]" strokeWidth={3} />
                      {bi(p)}
                    </li>
                  ))}
                </ul>

                {selected.dataCaveat && (
                  <div className="mt-3 rounded-lg border border-[#dcc59d] bg-[#f6ecd9] p-3">
                    <p className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wide text-[#7f5a27]">
                      <CircleAlert size={11} /> {t("dataGap")}
                    </p>
                    <p className="mt-1 text-[10px] leading-relaxed text-[#6f5630]">{bi(selected.dataCaveat)}</p>
                  </div>
                )}

                <div className="mt-4">
                  <p className="eyebrow">{t("regionalOfficial")}</p>
                  <div className="mt-1.5 divide-y divide-[rgba(20,43,37,0.09)] overflow-hidden rounded-lg border border-[rgba(20,43,37,0.12)]">
                    {REGIONAL_LINKS.map((l) => (
                      <a key={l.url} href={l.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-2.5 py-2 hover:bg-[rgba(20,43,37,0.04)]">
                        <ExternalLink size={11} className="shrink-0 text-[var(--forest)]" />
                        <span className="min-w-0 flex-1">
                          <span className="block text-[10px] font-semibold leading-tight text-[var(--ink)]">{l.label}</span>
                          <span className="block text-[8.5px] text-[var(--muted)]">{l.desc}</span>
                        </span>
                        <ArrowUpRight size={10} className="shrink-0 text-[var(--line)]" />
                      </a>
                    ))}
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  <button onClick={() => onOpenIncident(incidents[0]?.id ?? "")} disabled={!incidents[0]} className="btn btn-primary !py-1.5 !text-[10px] disabled:cursor-not-allowed disabled:opacity-40">
                    <MapPin size={11} /> {t("viewOnMap")}
                  </button>
                  <button onClick={onOpenEmergency} className="btn btn-ghost !py-1.5 !text-[10px]">
                    <Phone size={11} /> 112
                  </button>
                </div>
                <p className="mt-2 text-[8.5px] leading-relaxed text-[var(--muted)]">
                  <Siren size={9} className="mr-1 inline" />
                  {lang === "en"
                    ? "For an emergency, call 112. This profile is a static summary, not an alert."
                    : "საგანგებო სიტუაციისას დარეკეთ 112-ში. პროფილი სტატიკური შეჯამებაა და არა გაფრთხილება."}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[rgba(20,43,37,0.13)] bg-[rgba(251,249,242,0.65)] px-4 py-3">
          <p className="text-[10px] leading-relaxed text-[var(--muted)]">
            {lang === "en"
              ? "Regional summaries synthesize national hazard mapping and verified incidents. They are not a substitute for a site-specific geological survey."
              : "რეგიონული შეჯამებები აერთიანებს ეროვნულ რისკის რუკებსა და დადასტურებულ მოვლენებს. ისინი არ ცვლის კონკრეტული ადგილის გეოლოგიურ კვლევას."}
          </p>
          <button onClick={() => onOpenGuide("landslide")} className="flex items-center gap-1 text-[10px] font-bold text-[var(--forest)] hover:underline">
            {t("readGuide")} <ArrowRight size={11} />
          </button>
        </div>
      </section>
    </div>
  );
}
