import { useMemo, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronRight,
  CircleAlert,
  Info,
  Layers3,
  MapPin,
  Phone,
  ShieldAlert,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { useI18n } from "../i18n";
import {
  HAZARD_KEYS,
  HAZARD_META,
  type HazardKey,
  type MapSelection,
} from "../types";
import { GEO } from "../data/geo";
import { INCIDENTS } from "../data/incidents";
import { REGIONS } from "../data/regions";
import { SOURCES } from "../data/sources";
import { ZONES } from "../data/zones";
import { MapView } from "../components/MapView";
import { HazardGlyph } from "../components/HazardGlyph";
import { RegionMiniMap } from "../components/RegionMiniMap";

type Props = {
  selection: MapSelection;
  setSelection: (s: MapSelection) => void;
  focus: { lon: number; lat: number; token: number } | null;
  onOpenGuide: (h: HazardKey) => void;
  onOpenEmergency: () => void;
  onOpenRegionPage: (regionId: string) => void;
  onOpenTimeline: (incidentId?: string) => void;
};

const SOURCE_INDEX = new Map(SOURCES.map((s) => [s.id, s]));

export function MapPage({
  selection,
  setSelection,
  focus,
  onOpenGuide,
  onOpenEmergency,
  onOpenRegionPage,
  onOpenTimeline,
}: Props) {
  const { t, bi, lang } = useI18n();
  const [visibleHazards, setVisibleHazards] = useState<Set<HazardKey>>(new Set(HAZARD_KEYS));
  const [showZones, setShowZones] = useState(true);
  const [showIncidents, setShowIncidents] = useState(true);
  const [showMunicipalities, setShowMunicipalities] = useState(false);
  const [showRivers, setShowRivers] = useState(true);
  const [showCities, setShowCities] = useState(true);
  const [showBoundaries, setShowBoundaries] = useState(true);

  const counts = useMemo(() => {
    const events = new Map<HazardKey, number>();
    const zones = new Map<HazardKey, number>();
    HAZARD_KEYS.forEach((h) => {
      events.set(h, INCIDENTS.filter((i) => i.hazard === h).length);
      zones.set(h, ZONES.filter((z) => z.hazard === h).length);
    });
    return { events, zones };
  }, []);

  const toggleHazard = (hazard: HazardKey) => {
    const next = new Set(visibleHazards);
    if (next.has(hazard)) next.delete(hazard);
    else next.add(hazard);
    setVisibleHazards(next);
  };

  const selectedIncident = selection?.kind === "incident" ? INCIDENTS.find((i) => i.id === selection.id) ?? null : null;
  const selectedRegion = selection?.kind === "region" ? REGIONS.find((r) => r.name === selection.name) ?? null : null;
  const latest = [...INCIDENTS].sort((a, b) => b.startDate.localeCompare(a.startDate)).slice(0, 4);
  const broadHazardRegions = [...REGIONS].sort((a, b) => b.hazards.length - a.hazards.length).slice(0, 4);

  const selectRegion = (name: string) => setSelection({ kind: "region", name });
  const selectIncident = (id: string) => setSelection({ kind: "incident", id });

  return (
    <div>
      <section className="border-b border-[rgba(20,43,37,0.13)] bg-[var(--paper)] paper-grain">
        <div className="mx-auto max-w-[1440px] px-4 pb-7 pt-8 sm:px-6 lg:pt-10">
          <div className="grid gap-7 lg:grid-cols-[1fr_390px] lg:items-end">
            <div className="fade-up">
              <div className="mb-3 flex items-center gap-2.5">
                <span className="h-px w-6 bg-[var(--clay)]" />
                <p className="eyebrow">{t("mapKicker")}</p>
              </div>
              <h1 className="display text-[38px] leading-[1.02] sm:text-[48px] lg:text-[55px]">
                {t("mapTitle1")}
                <br />
                <span className="italic text-[var(--forest)]">{t("mapTitle2")}</span>
              </h1>
              <p className="mt-4 max-w-2xl text-[13.5px] leading-relaxed text-[var(--ink-2)] sm:text-[14px]">
                {t("mapIntro")}
              </p>
            </div>
            <div className="card overflow-hidden">
              <div className="grid grid-cols-4 divide-x divide-[rgba(20,43,37,0.1)]">
                {[
                  { n: 12, label: t("statRegions") },
                  { n: INCIDENTS.length, label: t("statEvents") },
                  { n: 8, label: t("statHazards") },
                  { n: SOURCES.length, label: t("statSources") },
                ].map((s) => (
                  <div key={s.label} className="px-2 py-3 text-center">
                    <p className="display text-[26px] leading-none text-[var(--ink)]">{s.n}</p>
                    <p className="mt-1.5 text-[8.5px] font-semibold uppercase leading-tight tracking-[0.06em] text-[var(--muted)]">
                      {s.label}
                    </p>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 border-t border-[rgba(20,43,37,0.1)] bg-[rgba(185,84,47,0.065)] px-3.5 py-2">
                <CircleAlert size={13} className="shrink-0 text-[var(--clay)]" />
                <p className="text-[10px] leading-snug text-[#6d492f]">
                  <strong>{t("notLive")}.</strong> {t("staticChip")} · {lang === "en" ? "Reviewed June 2026" : "გადამოწმებულია 2026 წლის ივნისში"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        <div className="grid gap-4 lg:grid-cols-[256px_minmax(0,1fr)] xl:grid-cols-[256px_minmax(0,1fr)_366px]">
          {/* layers */}
          <aside className="order-2 lg:order-1">
            <div className="card overflow-hidden lg:sticky lg:top-[126px]">
              <div className="flex items-center justify-between border-b border-[rgba(20,43,37,0.11)] px-3.5 py-2.5">
                <p className="flex items-center gap-1.5 text-[12px] font-bold text-[var(--ink)]">
                  <Layers3 size={14} /> {t("layersTitle")}
                </p>
                <SlidersHorizontal size={13} className="text-[var(--muted)]" />
              </div>
              <div className="p-3">
                <div className="mb-2 flex items-center justify-between">
                  <p className="eyebrow !text-[9.5px]">{t("hazardLayers")}</p>
                  <div className="flex gap-1">
                    <button
                      onClick={() => setVisibleHazards(new Set(HAZARD_KEYS))}
                      className="rounded px-1 text-[8.5px] font-bold uppercase tracking-wide text-[var(--forest)] hover:bg-[rgba(47,85,71,0.08)]"
                    >
                      {t("allOn")}
                    </button>
                    <span className="text-[8px] text-[var(--line)]">|</span>
                    <button
                      onClick={() => setVisibleHazards(new Set())}
                      className="rounded px-1 text-[8.5px] font-bold uppercase tracking-wide text-[var(--muted)] hover:bg-[rgba(20,43,37,0.06)]"
                    >
                      {t("allOff")}
                    </button>
                  </div>
                </div>
                <div className="space-y-0.5">
                  {HAZARD_KEYS.map((h) => {
                    const active = visibleHazards.has(h);
                    const meta = HAZARD_META[h];
                    return (
                      <button
                        key={h}
                        onClick={() => toggleHazard(h)}
                        aria-pressed={active}
                        className={`flex w-full items-center gap-2 rounded-md px-1.5 py-[7px] text-left transition-colors ${
                          active ? "bg-[rgba(47,85,71,0.06)]" : "opacity-55 hover:opacity-80"
                        }`}
                      >
                        <span
                          className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px] border ${
                            active ? "border-transparent text-white" : "border-[rgba(20,43,37,0.3)] bg-transparent"
                          }`}
                          style={active ? { background: meta.color } : undefined}
                        >
                          {active && <Check size={11} strokeWidth={3} />}
                        </span>
                        <span style={{ color: active ? meta.dark : "var(--muted)" }} className="shrink-0">
                          <HazardGlyph hazard={h} size={14} />
                        </span>
                        <span className={`min-w-0 flex-1 text-[11px] leading-tight ${active ? "font-semibold text-[var(--ink-2)]" : "text-[var(--muted)]"}`}>
                          {bi(meta.label)}
                        </span>
                        <span className="shrink-0 rounded-full bg-white/60 px-1.5 py-0.5 text-[8.5px] font-semibold tabular-nums text-[var(--muted)]">
                          {counts.events.get(h)}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-3 border-t border-[rgba(20,43,37,0.1)] pt-2.5">
                  <p className="eyebrow mb-1.5 !text-[9.5px]">{t("mapFeatures")}</p>
                  <div className="space-y-0.5">
                    <FeatureToggle label={t("showZones")} checked={showZones} onChange={setShowZones} />
                    <FeatureToggle label={t("showIncidents")} checked={showIncidents} onChange={setShowIncidents} />
                    <FeatureToggle label={t("showBoundaries")} checked={showBoundaries} onChange={setShowBoundaries} />
                    <FeatureToggle label={t("showMunicipalities")} checked={showMunicipalities} onChange={setShowMunicipalities} />
                    <FeatureToggle label={t("showRivers")} checked={showRivers} onChange={setShowRivers} />
                    <FeatureToggle label={t("showCities")} checked={showCities} onChange={setShowCities} />
                  </div>
                </div>
              </div>
              <div className="border-t border-[rgba(20,43,37,0.1)] bg-[rgba(182,138,52,0.07)] px-3 py-2.5">
                <p className="flex gap-1.5 text-[9px] leading-relaxed text-[#6f5a31]">
                  <Info size={12} className="mt-0.5 shrink-0" />
                  {t("zoneWarning")}
                </p>
              </div>
            </div>
          </aside>

          {/* map */}
          <div className="order-1 min-w-0 lg:order-2">
            <div className="card overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[rgba(20,43,37,0.12)] px-3 py-2 sm:px-4">
                <div className="flex items-center gap-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[rgba(47,85,71,0.1)] text-[var(--forest)]">
                    <MapPin size={13} />
                  </span>
                  <div>
                    <p className="text-[11px] font-bold leading-tight text-[var(--ink)]">
                      {lang === "en" ? "Georgia · national hazard atlas" : "საქართველო · ეროვნული საფრთხეების ატლასი"}
                    </p>
                    <p className="text-[9px] leading-tight text-[var(--muted)]">geoBoundaries ADM1/ADM2 · 12 regions · 68 municipalities</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="chip !py-1 !text-[9px]">
                    <span className="h-1.5 w-1.5 rounded-full bg-[var(--sage)]" />
                    {visibleHazards.size}/8
                  </span>
                  <span className="hidden rounded-full border border-[rgba(185,84,47,0.25)] bg-[rgba(185,84,47,0.08)] px-2 py-1 text-[8.5px] font-bold uppercase tracking-wide text-[var(--clay)] sm:inline">
                    {t("notLive")}
                  </span>
                </div>
              </div>
              <MapView
                visibleHazards={visibleHazards}
                showZones={showZones}
                showIncidents={showIncidents}
                showMunicipalities={showMunicipalities}
                showRivers={showRivers}
                showCities={showCities}
                showBoundaries={showBoundaries}
                selection={selection}
                onSelectIncident={selectIncident}
                onSelectRegion={selectRegion}
                onClearSelection={() => setSelection(null)}
                focus={focus}
              />
              <div className="flex flex-wrap items-center justify-between gap-1.5 border-t border-[rgba(20,43,37,0.1)] bg-[rgba(20,43,37,0.025)] px-3 py-1.5 text-[9px] text-[var(--muted)]">
                <span>{t("mapInstruction")}</span>
                <button onClick={() => onOpenRegionPage(REGIONS[1].id)} className="hidden items-center gap-1 font-semibold text-[var(--forest)] hover:underline sm:flex">
                  {t("navRegions")} <ArrowRight size={10} />
                </button>
              </div>
            </div>
          </div>

          {/* detail */}
          <aside className="order-3 min-w-0">
            <div className="card overflow-hidden xl:sticky xl:top-[126px]">
              {selectedIncident ? (
                <IncidentPanel
                  incidentId={selectedIncident.id}
                  onClose={() => setSelection(null)}
                  onOpenGuide={onOpenGuide}
                  onOpenTimeline={onOpenTimeline}
                />
              ) : selectedRegion ? (
                <RegionPanel
                  name={selectedRegion.name}
                  onClose={() => setSelection(null)}
                  onSelectIncident={selectIncident}
                  onOpenGuide={onOpenGuide}
                  onOpenRegionPage={onOpenRegionPage}
                />
              ) : (
                <OverviewPanel
                  latest={latest}
                  broadHazardRegions={broadHazardRegions}
                  counts={Object.fromEntries(counts.events) as Record<HazardKey, number>}
                  onSelectIncident={selectIncident}
                  onSelectRegion={selectRegion}
                  onOpenGuide={onOpenGuide}
                  onOpenEmergency={onOpenEmergency}
                />
              )}
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function FeatureToggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      aria-pressed={checked}
      className="flex w-full items-center gap-2 rounded-md px-1.5 py-[5px] text-left hover:bg-[rgba(20,43,37,0.04)]"
    >
      <span
        className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-[3px] border ${
          checked ? "border-[var(--forest)] bg-[var(--forest)] text-white" : "border-[rgba(20,43,37,0.3)]"
        }`}
      >
        {checked && <Check size={9} strokeWidth={3.4} />}
      </span>
      <span className="text-[10px] leading-tight text-[var(--ink-2)]">{label}</span>
    </button>
  );
}

function PanelHeader({ onClose, kicker, color }: { onClose?: () => void; kicker: string; color?: string }) {
  const { t } = useI18n();
  return (
    <div className="flex items-center justify-between border-b border-[rgba(20,43,37,0.11)] px-3.5 py-2" style={color ? { borderTop: `3px solid ${color}` } : undefined}>
      <p className="eyebrow !text-[9px]">{kicker}</p>
      {onClose && (
        <button onClick={onClose} aria-label={t("close")} className="rounded-full p-1 text-[var(--muted)] hover:bg-[rgba(20,43,37,0.07)] hover:text-[var(--ink)]">
          <X size={14} />
        </button>
      )}
    </div>
  );
}

function OverviewPanel({
  latest,
  broadHazardRegions,
  counts,
  onSelectIncident,
  onSelectRegion,
  onOpenGuide,
  onOpenEmergency,
}: {
  latest: typeof INCIDENTS;
  broadHazardRegions: typeof REGIONS;
  counts: Record<HazardKey, number>;
  onSelectIncident: (id: string) => void;
  onSelectRegion: (name: string) => void;
  onOpenGuide: (h: HazardKey) => void;
  onOpenEmergency: () => void;
}) {
  const { t, bi, lang } = useI18n();
  return (
    <div className="max-h-[680px] overflow-y-auto scroll-area">
      <PanelHeader kicker={t("overview")} />
      <div className="p-4">
        <h2 className="display text-[21px] leading-tight">
          {lang === "en" ? "A small country with a long hazard record." : "პატარა ქვეყანა საფრთხეების ხანგრძლივი ისტორიით."}
        </h2>
        <p className="mt-2 text-[11.5px] leading-relaxed text-[var(--muted)]">{t("selectPromptBody")}</p>

        <div className="mt-3.5 grid grid-cols-2 gap-1.5">
          <button onClick={() => onOpenGuide("earthquake")} className="rounded-lg border border-[rgba(20,43,37,0.13)] bg-white/45 px-2.5 py-2 text-left hover:border-[rgba(20,43,37,0.3)]">
            <ShieldAlert size={14} className="text-[var(--clay)]" />
            <p className="mt-1 text-[10px] font-bold leading-tight text-[var(--ink)]">{t("prepareNow")}</p>
          </button>
          <button onClick={onOpenEmergency} className="rounded-lg border border-[rgba(185,84,47,0.25)] bg-[rgba(185,84,47,0.07)] px-2.5 py-2 text-left hover:border-[rgba(185,84,47,0.5)]">
            <Phone size={14} className="text-[var(--clay)]" />
            <p className="mt-1 text-[10px] font-bold leading-tight text-[#6b3f26]">112 · {t("emergencyBtn")}</p>
          </button>
        </div>

        <div className="mt-4">
          <p className="eyebrow mb-1.5 !text-[9px]">{t("howWeKnow")}</p>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-[10px] text-[var(--ink-2)]">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--clay)] text-white">
                <MapPin size={10} />
              </span>
              {t("legendPin")}
            </div>
            <div className="flex items-center gap-2 text-[10px] text-[var(--ink-2)]">
              <span className="h-4 w-5 rounded-sm border border-dashed border-[var(--gold)] bg-[var(--gold)]/20" />
              {t("legendZone")}
            </div>
          </div>
        </div>

        <div className="mt-4">
          <p className="eyebrow mb-2 !text-[9px]">{t("documentedEvents")}</p>
          <div className="space-y-1">
            {HAZARD_KEYS.filter((h) => counts[h] > 0).map((h) => (
              <button
                key={h}
                onClick={() => onOpenGuide(h)}
                className="group flex w-full items-center gap-2 text-left"
                title={bi(HAZARD_META[h].label)}
              >
                <span className="w-[13px]" style={{ color: HAZARD_META[h].color }}>
                  <HazardGlyph hazard={h} size={12} />
                </span>
                <span className="w-[92px] shrink-0 truncate text-[9px] text-[var(--ink-2)]">{bi(HAZARD_META[h].label)}</span>
                <span className="h-[5px] flex-1 overflow-hidden rounded-full bg-[rgba(20,43,37,0.08)]">
                  <span
                    className="block h-full rounded-full"
                    style={{ width: `${(counts[h] / 4) * 100}%`, background: HAZARD_META[h].color, opacity: 0.8 }}
                  />
                </span>
                <span className="w-3 text-right text-[9px] font-bold tabular-nums text-[var(--muted)]">{counts[h]}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <p className="eyebrow mb-1.5 !text-[9px]">{lang === "en" ? "Latest records" : "ბოლო ჩანაწერები"}</p>
          <div className="divide-y divide-[rgba(20,43,37,0.09)]">
            {latest.map((i) => (
              <button
                key={i.id}
                onClick={() => onSelectIncident(i.id)}
                className="group flex w-full items-start gap-2 py-1.5 text-left"
              >
                <span className="mt-0.5 shrink-0" style={{ color: HAZARD_META[i.hazard].color }}>
                  <HazardGlyph hazard={i.hazard} size={13} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[10.5px] font-semibold leading-tight text-[var(--ink)] group-hover:underline">
                    {bi(i.title)}
                  </span>
                  <span className="block text-[9px] text-[var(--muted)]">{bi(i.dateLabel)}</span>
                </span>
                <ChevronRight size={11} className="mt-1 shrink-0 text-[var(--line)] group-hover:text-[var(--forest)]" />
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <p className="eyebrow mb-1.5 !text-[9px]">{t("dangerHotspots")}</p>
          <div className="flex flex-wrap gap-1">
            {broadHazardRegions.map((r) => (
              <button key={r.id} onClick={() => onSelectRegion(r.name)} className="chip !text-[9px] hover:border-[rgba(20,43,37,0.35)]">
                {lang === "en" ? r.name.split(" and ")[0] : r.nameKa.split(" და ")[0]}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function IncidentPanel({
  incidentId,
  onClose,
  onOpenGuide,
  onOpenTimeline,
}: {
  incidentId: string;
  onClose: () => void;
  onOpenGuide: (h: HazardKey) => void;
  onOpenTimeline: (id?: string) => void;
}) {
  const { t, bi, lang } = useI18n();
  const incident = INCIDENTS.find((i) => i.id === incidentId);
  if (!incident) return null;
  const meta = HAZARD_META[incident.hazard];
  const severityLabel = { catastrophic: t("catastrophic"), major: t("major"), moderate: t("moderate") }[incident.severity];
  const sources = incident.sources.map((id) => SOURCE_INDEX.get(id)).filter(Boolean);
  return (
    <div className="max-h-[680px] overflow-y-auto scroll-area">
      <PanelHeader kicker={bi({ en: "Historical incident", ka: "ისტორიული მოვლენა" })} color={meta.color} onClose={onClose} />
      <div className="p-4">
        <div className="flex items-start gap-2.5">
          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white" style={{ background: meta.color }}>
            <HazardGlyph hazard={incident.hazard} size={19} />
          </span>
          <div className="min-w-0">
            <p className="text-[9px] font-bold uppercase tracking-[0.1em]" style={{ color: meta.dark }}>
              {bi(meta.label)}
            </p>
            <h2 className="display mt-0.5 text-[22px] leading-[1.1]">{bi(incident.title)}</h2>
          </div>
        </div>

        <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
          <span
            className="rounded-full px-2 py-0.5 text-[8.5px] font-bold uppercase tracking-wide text-white"
            style={{ background: meta.color }}
          >
            {severityLabel}
          </span>
          <span className="chip !py-0.5 !text-[8.5px]">{t(incident.confidence === "documented" ? "documented" : incident.confidence === "partial" ? "partial" : "figuresDisputed")}</span>
          <span className="chip !py-0.5 !text-[8.5px]">{incident.precision === "municipality" ? t("locatedApprox") : t("sitePrecision")}</span>
        </div>

        <div className="mt-3 space-y-1.5 border-y border-[rgba(20,43,37,0.1)] py-2.5">
          <div className="flex items-start gap-2 text-[11px]">
            <CalendarDays size={13} className="mt-0.5 shrink-0 text-[var(--muted)]" />
            <span className="font-semibold text-[var(--ink)]">{bi(incident.dateLabel)}</span>
          </div>
          <div className="flex items-start gap-2 text-[11px]">
            <MapPin size={13} className="mt-0.5 shrink-0 text-[var(--muted)]" />
            <span className="text-[var(--ink-2)]">{bi(incident.location)}</span>
          </div>
        </div>

        <div className="mt-3 space-y-2">
          <InfoRow label={t("killed")} value={bi(incident.casualties)} />
          <InfoRow label={t("affected")} value={bi(incident.affected)} />
          <InfoRow label={t("damage")} value={bi(incident.damage)} />
        </div>

        <div className="mt-3.5">
          <p className="eyebrow mb-1 !text-[9px]">{t("eventSummary")}</p>
          <p className="text-[11.5px] leading-relaxed text-[var(--ink-2)]">{bi(incident.summary)}</p>
        </div>

        <div className="mt-3">
          <p className="eyebrow mb-1 !text-[9px]">{t("context")}</p>
          <p className="text-[11px] leading-relaxed text-[var(--muted)]">{bi(incident.context)}</p>
        </div>

        {incident.confidenceNote && (
          <div className="mt-3 rounded-lg border border-[#dcc59d] bg-[#f4ead6] p-2.5">
            <p className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wide text-[#7f5a27]">
              <CircleAlert size={11} /> {t("evidenceNote")}
            </p>
            <p className="mt-1 text-[10px] leading-relaxed text-[#6f5630]">{bi(incident.confidenceNote)}</p>
          </div>
        )}

        <div className="mt-3.5">
          <p className="eyebrow mb-1 !text-[9px]">{t("eventSources")}</p>
          <div className="space-y-1">
            {sources.map(
              (s) =>
                s && (
                  <a
                    key={s.id}
                    href={s.url}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-start gap-1.5 rounded px-1 py-1 text-[10px] leading-snug text-[var(--ink-2)] hover:bg-[rgba(20,43,37,0.04)]"
                  >
                    <ArrowUpRight size={10} className="mt-0.5 shrink-0 text-[var(--forest)]" />
                    <span>
                      <span className="font-semibold group-hover:underline">{s.publisher}</span>
                      <span className="text-[var(--muted)]"> · {s.title}</span>
                      <span className="text-[var(--muted)]"> ({s.year})</span>
                    </span>
                  </a>
                )
            )}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-1.5">
          <button onClick={() => onOpenGuide(incident.hazard)} className="btn btn-primary !px-2 !py-2 !text-[10px]">
            {t("readGuide")} <ArrowRight size={11} />
          </button>
          <button onClick={() => onOpenTimeline(incident.id)} className="btn btn-ghost !px-2 !py-2 !text-[10px]">
            {t("viewTimeline")} <ArrowRight size={11} />
          </button>
        </div>
        <p className="mt-2 text-[8.5px] leading-snug text-[var(--muted)]">
          {lang === "en"
            ? "Impact class is an editorial summary, not an official rating. No photograph is shown where its licence or authenticity could not be verified."
            : "ზეგავლენის კლასი რედაქციული შეჯამებაა და არა ოფიციალური შეფასება. ფოტო არ ჩანს, თუ ლიცენზია ან ავთენტურობა ვერ დადასტურდა."}
        </p>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[106px_1fr] gap-2">
      <span className="text-[9px] font-bold uppercase leading-tight tracking-[0.05em] text-[var(--muted)]">{label}</span>
      <span className="text-[10.5px] leading-snug text-[var(--ink-2)]">{value}</span>
    </div>
  );
}

function RegionPanel({
  name,
  onClose,
  onSelectIncident,
  onOpenGuide,
  onOpenRegionPage,
}: {
  name: string;
  onClose: () => void;
  onSelectIncident: (id: string) => void;
  onOpenGuide: (h: HazardKey) => void;
  onOpenRegionPage: (id: string) => void;
}) {
  const { t, bi, lang } = useI18n();
  const region = REGIONS.find((r) => r.name === name);
  const geoRegion = GEO.regions.find((r) => r.name === name);
  if (!region) return null;
  const incidents = region.incidents.map((id) => INCIDENTS.find((i) => i.id === id)).filter(Boolean);
  return (
    <div className="max-h-[680px] overflow-y-auto scroll-area">
      <PanelHeader kicker={t("regionProfile")} onClose={onClose} color="#2f5547" />
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-[9px] font-bold uppercase tracking-[0.1em] text-[var(--forest)]">{region.code}</p>
            <h2 className="display mt-0.5 text-[23px] leading-tight">{lang === "en" ? region.name : region.nameKa}</h2>
            <p className="mt-0.5 flex items-center gap-1 text-[10px] text-[var(--muted)]">
              <MapPin size={10} /> {bi(region.center)}
            </p>
          </div>
          {geoRegion && <RegionMiniMap regionName={region.name} className="h-16 w-20 shrink-0 opacity-90" />}
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-[var(--ink-2)]">{bi(region.blurb)}</p>

        <div className="mt-3.5">
          <p className="eyebrow mb-1 !text-[9px]">{t("regionalHazards")}</p>
          <div className="flex flex-wrap gap-1">
            {region.hazards.map((h) => (
              <button
                key={h}
                onClick={() => onOpenGuide(h)}
                className="flex items-center gap-1 rounded-full border px-1.5 py-[3px] text-[9px] font-semibold hover:bg-white"
                style={{ borderColor: `${HAZARD_META[h].color}55`, color: HAZARD_META[h].dark, background: `${HAZARD_META[h].soft}88` }}
              >
                <HazardGlyph hazard={h} size={10} />
                {bi(HAZARD_META[h].label)}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3.5">
          <p className="eyebrow mb-1 !text-[9px]">{t("documentedHistory")}</p>
          {incidents.length === 0 ? (
            <p className="rounded-md border border-dashed border-[rgba(20,43,37,0.2)] px-2 py-2 text-[10px] leading-relaxed text-[var(--muted)]">
              {t("noIncidents")}
            </p>
          ) : (
            <div className="divide-y divide-[rgba(20,43,37,0.09)]">
              {incidents.map(
                (i) =>
                  i && (
                    <button key={i.id} onClick={() => onSelectIncident(i.id)} className="group flex w-full items-center gap-2 py-1.5 text-left">
                      <span style={{ color: HAZARD_META[i.hazard].color }}>
                        <HazardGlyph hazard={i.hazard} size={13} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[10.5px] font-semibold text-[var(--ink)] group-hover:underline">{bi(i.title)}</span>
                        <span className="block text-[9px] text-[var(--muted)]">
                          {bi(i.dateLabel)} · {bi(i.casualties)}
                        </span>
                      </span>
                      <ChevronRight size={11} className="text-[var(--line)]" />
                    </button>
                  )
              )}
            </div>
          )}
        </div>

        <div className="mt-3.5">
          <p className="eyebrow mb-1 !text-[9px]">{t("vulnerabilities")}</p>
          <ul className="space-y-1.5">
            {region.vulnerabilities.map((v, i) => (
              <li key={i} className="flex gap-1.5 text-[10px] leading-relaxed text-[var(--ink-2)]">
                <span className="mt-[5px] h-1 w-1 shrink-0 rounded-full bg-[var(--clay)]" />
                {bi(v)}
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-3">
          <p className="eyebrow mb-1 !text-[9px]">{t("prepRecommendations")}</p>
          <ul className="space-y-1">
            {region.preparedness.map((v, i) => (
              <li key={i} className="flex gap-1.5 text-[10px] leading-relaxed text-[var(--ink-2)]">
                <Check size={10} className="mt-0.5 shrink-0 text-[var(--forest)]" strokeWidth={3} />
                {bi(v)}
              </li>
            ))}
          </ul>
        </div>

        {region.dataCaveat && (
          <div className="mt-3 rounded-lg border border-[#dcc59d] bg-[#f4ead6] p-2.5">
            <p className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wide text-[#7f5a27]">
              <CircleAlert size={11} /> {t("dataGap")}
            </p>
            <p className="mt-1 text-[9.5px] leading-relaxed text-[#6f5630]">{bi(region.dataCaveat)}</p>
          </div>
        )}

        <button onClick={() => onOpenRegionPage(region.id)} className="btn btn-primary mt-3 w-full !py-2 !text-[10.5px]">
          {t("exploreRegion")} <ArrowRight size={12} />
        </button>
        <p className="mt-2 text-[8.5px] leading-snug text-[var(--muted)]">{t("regionDataNote")}</p>
      </div>
    </div>
  );
}
