import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BookOpenCheck,
  Check,
  CircleHelp,
  Ear,
  ExternalLink,
  ListChecks,
  Phone,
  Printer,
  RotateCcw,
  ShieldCheck,
  Siren,
  TriangleAlert,
  Users,
} from "lucide-react";
import { useI18n, useLocalStorageState } from "../i18n";
import { HAZARD_META, type HazardKey } from "../types";
import { GUIDES } from "../data/guides";
import { HazardGlyph } from "../components/HazardGlyph";

const OFFICIAL_LINKS = [
  { label: "112 — unified emergency line", url: "https://112.gov.ge/", desc: "Police, fire-rescue, ambulance; free from any phone." },
  { label: "National Environmental Agency", url: "https://nea.gov.ge/", desc: "Weather, hydrology and geological hazard information." },
  { label: "Emergency Situations Management Service", url: "https://police.ge/en", desc: "Rescue, evacuation and civil protection." },
  { label: "Georgian Red Cross", url: "https://redcross.ge/en/", desc: "First aid, relief and psychosocial support." },
];

export function GuidesPage({
  selectedHazard,
  onSelectHazard,
  onOpenEmergency,
}: {
  selectedHazard: HazardKey;
  onSelectHazard: (h: HazardKey) => void;
  onOpenEmergency: () => void;
}) {
  const { t, bi, lang } = useI18n();
  const guide = GUIDES.find((g) => g.id === selectedHazard) ?? GUIDES[0];
  const meta = HAZARD_META[guide.id];
  const [checks, setChecks] = useLocalStorageState<Record<string, boolean>>("hazard-atlas-checklist-v1", {});
  const [claimed, setClaimed] = useState(false);

  const progress = useMemo(() => {
    const done = guide.checklist.filter((_, i) => checks[`${guide.id}:${i}`]).length;
    return { done, total: guide.checklist.length, pct: Math.round((done / guide.checklist.length) * 100) };
  }, [checks, guide]);

  const toggle = (index: number) => {
    setChecks({ ...checks, [`${guide.id}:${index}`]: !checks[`${guide.id}:${index}`] });
    setClaimed(false);
  };

  const reset = () => {
    const next = { ...checks };
    guide.checklist.forEach((_, i) => delete next[`${guide.id}:${i}`]);
    setChecks(next);
    setClaimed(false);
  };

  return (
    <div>
      <section className="bg-[#132b25] text-[var(--cream)]">
        <div className="mx-auto max-w-[1440px] px-4 pb-8 pt-9 sm:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_360px] lg:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2.5">
                <span className="h-px w-6 bg-[#e09b72]" />
                <p className="eyebrow !text-[#e9c2a7]">{t("guideKicker")}</p>
              </div>
              <h1 className="display text-[36px] leading-[1.03] sm:text-[46px]">{t("guideTitle")}</h1>
              <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[#c1cbbf]">{t("guideIntro")}</p>
            </div>
            <div className="rounded-xl border border-white/15 bg-white/[0.045] p-4">
              <p className="eyebrow !text-[#a9b8a8]">{t("emergencyContacts")}</p>
              <a href="tel:112" className="mt-1 flex items-end gap-2 text-white">
                <span className="display text-[38px] leading-none">112</span>
                <span className="pb-1 text-[10px] uppercase tracking-wide text-[#a9b8a8]">24/7 · free</span>
              </a>
              <p className="mt-1 text-[11px] leading-snug text-[#b7c2b6]">{t("emergencyShort")}</p>
              <button onClick={onOpenEmergency} className="mt-2.5 flex items-center gap-1 text-[11px] font-bold text-[#f0b48f] hover:text-white">
                {t("emergencyBtn")} <ArrowRight size={12} />
              </button>
            </div>
          </div>

          <div className="mt-6">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.12em] text-[#a9b8a8]">{t("chooseHazard")}</p>
            <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 scroll-area">
              {GUIDES.map((g) => {
                const m = HAZARD_META[g.id];
                const active = g.id === guide.id;
                return (
                  <button
                    key={g.id}
                    onClick={() => onSelectHazard(g.id)}
                    aria-pressed={active}
                    className={`flex min-w-[122px] flex-1 flex-col gap-1.5 rounded-lg border px-2.5 py-2.5 text-left transition-all ${
                      active ? "border-transparent bg-[var(--cream)] text-[var(--ink)] shadow-md" : "border-white/15 bg-white/[0.04] text-[#dfe6db] hover:bg-white/[0.09]"
                    }`}
                  >
                    <span style={{ color: active ? m.color : "#cbd6c9" }}>
                      <HazardGlyph hazard={g.id} size={20} />
                    </span>
                    <span className="text-[10.5px] font-bold leading-tight">{bi(m.label)}</span>
                    <span className={`text-[8.5px] leading-snug ${active ? "text-[var(--muted)]" : "text-[#9fb0a0]"}`}>
                      {g.checklist.length} {lang === "en" ? "checks" : "შემოწმება"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6">
        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_286px]">
          <div className="min-w-0">
            <div className="card overflow-hidden">
              <div className="h-1.5 w-full" style={{ background: meta.color }} />
              <div className="p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: meta.color }}>
                      <HazardGlyph hazard={guide.id} size={25} />
                    </span>
                    <div>
                      <p className="text-[9.5px] font-bold uppercase tracking-[0.12em]" style={{ color: meta.dark }}>
                        {lang === "en" ? "Hazard guide" : "საფრთხის გიდი"}
                      </p>
                      <h2 className="display text-[27px] leading-tight sm:text-[31px]">{bi(meta.label)}</h2>
                      <p className="mt-1 max-w-xl text-[12px] leading-snug text-[var(--muted)]">{bi(guide.tagline)}</p>
                    </div>
                  </div>
                  <div className="rounded-lg border border-[rgba(20,43,37,0.15)] bg-white/50 px-3 py-2">
                    <p className="text-[8.5px] font-bold uppercase tracking-wide text-[var(--muted)]">{t("checklistProgress")}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="h-1.5 w-20 overflow-hidden rounded-full bg-[rgba(20,43,37,0.11)]">
                        <span className="block h-full rounded-full transition-all" style={{ width: `${progress.pct}%`, background: meta.color }} />
                      </span>
                      <span className="text-[10px] font-bold tabular-nums text-[var(--ink)]">
                        {progress.done}/{progress.total}
                      </span>
                    </div>
                  </div>
                </div>

                <div id="why" className="guide-section mt-4 rounded-xl border border-[rgba(20,43,37,0.12)] bg-[rgba(47,85,71,0.045)] p-3.5">
                  <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] text-[var(--forest)]">
                    <CircleHelp size={13} /> {t("whyGeorgia")}
                  </p>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--ink-2)]">{bi(guide.why)}</p>
                </div>

                <div id="signs" className="guide-section mt-4 rounded-xl border border-[#e0c9a4] bg-[#f7eddc] p-3.5">
                  <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] text-[#85592a]">
                    <Siren size={13} /> {t("warningSigns")}
                  </p>
                  <ul className="mt-1.5 space-y-1.5">
                    {guide.signs.map((s, i) => (
                      <li key={i} className="flex gap-2 text-[11.5px] leading-relaxed text-[#624b2d]">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#b9863e]" />
                        {bi(s)}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-5 space-y-5">
                  <StageSection
                    stage="before"
                    title={t("before")}
                    subtitle={lang === "en" ? "Preparation that reduces harm" : "მომზადება, რომელიც ზიანს ამცირებს"}
                    steps={guide.before.map(bi)}
                    color="var(--forest)"
                    icon="check"
                  />
                  <StageSection
                    stage="during"
                    title={t("during")}
                    subtitle={lang === "en" ? "Act immediately, in this order" : "იმოქმედეთ დაუყოვნებლივ, ამ თანმიმდევრობით"}
                    steps={guide.during.map(bi)}
                    color={meta.color}
                    icon="alert"
                  />
                  <StageSection
                    stage="after"
                    title={t("after")}
                    subtitle={lang === "en" ? "Return safely and recover" : "დაბრუნება და აღდგენა"}
                    steps={guide.after.map(bi)}
                    color="var(--gold)"
                    icon="shield"
                  />
                </div>

                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-[#d9b6a4] bg-[#f7e7df] p-3.5">
                    <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] text-[#8a3e23]">
                      <TriangleAlert size={13} /> {t("mistakes")}
                    </p>
                    <ul className="mt-2 space-y-2">
                      {guide.mistakes.map((m, i) => (
                        <li key={i} className="flex gap-1.5 text-[10.5px] leading-relaxed text-[#6c3f2b]">
                          <AlertTriangle size={11} className="mt-0.5 shrink-0 text-[#b9542f]" />
                          {bi(m)}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-xl border border-[rgba(47,85,71,0.22)] bg-[rgba(47,85,71,0.06)] p-3.5">
                    <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] text-[var(--forest)]">
                      <Users size={13} /> {t("vulnerable")}
                    </p>
                    <p className="mt-1.5 text-[10.5px] leading-relaxed text-[var(--ink-2)]">{bi(guide.vulnerable)}</p>
                  </div>
                </div>
              </div>
            </div>

            <div id="checklist" className="guide-section card mt-4 overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[rgba(20,43,37,0.11)] px-4 py-3">
                <div className="flex items-center gap-2">
                  <ListChecks size={16} className="text-[var(--forest)]" />
                  <h3 className="text-[13px] font-bold text-[var(--ink)]">{t("checklist")}</h3>
                  <span className="chip !py-0.5 !text-[9px]">{progress.done}/{progress.total}</span>
                </div>
                <button onClick={reset} className="flex items-center gap-1 text-[10px] font-semibold text-[var(--muted)] hover:text-[var(--clay)]">
                  <RotateCcw size={11} /> {t("resetChecklist")}
                </button>
              </div>
              <div className="p-3">
                <div className="space-y-0.5">
                  {guide.checklist.map((item, i) => {
                    const done = Boolean(checks[`${guide.id}:${i}`]);
                    return (
                      <button
                        key={i}
                        onClick={() => toggle(i)}
                        aria-pressed={done}
                        className={`checkline ${done ? "checkline-done" : ""}`}
                      >
                        <span
                          className={`mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-[4px] border ${
                            done ? "border-transparent text-white" : "border-[rgba(20,43,37,0.32)]"
                          }`}
                          style={{ width: 18, height: 18, background: done ? meta.color : "transparent" }}
                        >
                          {done && <Check size={12} strokeWidth={3} />}
                        </span>
                        <span className={`check-label text-[11.5px] leading-relaxed ${done ? "" : "text-[var(--ink-2)]"}`}>
                          {bi(item)}
                        </span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-2 flex items-center gap-2 px-2">
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[rgba(20,43,37,0.09)]">
                    <span className="block h-full rounded-full transition-all duration-300" style={{ width: `${progress.pct}%`, background: meta.color }} />
                  </span>
                  <span className="text-[10px] font-bold tabular-nums text-[var(--muted)]">{progress.pct}%</span>
                </div>
                {progress.pct === 100 && (
                  <div className="mt-2 flex items-start gap-2 rounded-lg border border-[rgba(47,85,71,0.25)] bg-[rgba(47,85,71,0.08)] px-3 py-2">
                    <ShieldCheck size={15} className="mt-0.5 shrink-0 text-[var(--forest)]" />
                    <p className="text-[10.5px] leading-relaxed text-[var(--forest)]">
                      {lang === "en"
                        ? "Your household checklist is complete. Review it twice a year and replace expired supplies."
                        : "თქვენი ოჯახის ჩამონათვალი შესრულებულია. გადახედეთ წელიწადში ორჯერ და შეცვალეთ ვადაგასული მარაგები."}
                    </p>
                  </div>
                )}
                <p className="mt-2 px-2 text-[9px] leading-snug text-[var(--muted)]">{t("savedNote")}</p>
              </div>
            </div>

            <div className="card mt-4 p-4 no-print">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <BookOpenCheck size={16} className="text-[var(--forest)]" />
                  <p className="text-[12px] font-bold text-[var(--ink)]">{lang === "en" ? "Make it official in your household" : "გააკეთეთ ოჯახური გეგმა"}</p>
                </div>
                <button onClick={() => window.print()} className="btn btn-ghost !py-1.5 !text-[10px]">
                  <Printer size={12} /> {t("printGuide")}
                </button>
              </div>
              <p className="mt-1.5 text-[10.5px] leading-relaxed text-[var(--muted)]">
                {lang === "en"
                  ? "Write down two meeting points, an out-of-area contact, utility shut-off locations and who is responsible for children, older relatives and pets. Practise it, then store a copy with your documents."
                  : "ჩაწერეთ ორი შეხვედრის ადგილი, რეგიონგარე კონტაქტი, კომუნიკაციების ჩამრთველების ადგილები და ვინ არის პასუხისმგებელი ბავშვებზე, მოხუცებსა და შინაურ ცხოველებზე. ივარჯიშეთ და ასლი დოკუმენტებთან შეინახეთ."}
              </p>
              <button onClick={() => setClaimed(true)} className="btn btn-primary mt-2.5 !py-1.5 !text-[10px]">
                {claimed ? <ShieldCheck size={13} /> : <Ear size={13} />}
                {claimed
                  ? lang === "en"
                    ? "Family plan noted in this session"
                    : "ოჯახის გეგმა ამ სესიაში აღნიშნულია"
                  : lang === "en"
                    ? "We have discussed this plan"
                    : "ჩვენ განვიხილეთ ეს გეგმა"}
              </button>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="card p-4 lg:sticky lg:top-[126px]">
              <p className="eyebrow">{t("officialsLinks")}</p>
              <div className="mt-2 divide-y divide-[rgba(20,43,37,0.09)]">
                {OFFICIAL_LINKS.map((l) => (
                  <a key={l.url} href={l.url} target="_blank" rel="noreferrer" className="group flex items-start gap-2 py-2">
                    <ExternalLink size={12} className="mt-0.5 shrink-0 text-[var(--forest)]" />
                    <span>
                      <span className="block text-[10.5px] font-semibold leading-tight text-[var(--ink)] group-hover:underline">{l.label}</span>
                      <span className="mt-0.5 block text-[9px] leading-snug text-[var(--muted)]">{l.desc}</span>
                    </span>
                  </a>
                ))}
              </div>
              <div className="mt-2 rounded-lg bg-[rgba(20,43,37,0.045)] p-2.5">
                <p className="flex items-center gap-1.5 text-[10px] font-bold text-[var(--ink)]">
                  <Phone size={11} className="text-[var(--clay)]" /> 112
                </p>
                <p className="mt-1 text-[9px] leading-relaxed text-[var(--muted)]">
                  {lang === "en"
                    ? "For an emergency in progress, call 112. This guide is educational and not a live alert."
                    : "მიმდინარე საგანგებო სიტუაციისას დარეკეთ 112-ში. გიდი საგანმანათლებლოა და არა ცოცხალი გაფრთხილება."}
                </p>
              </div>
            </div>

            <div className="card overflow-hidden">
              <div className="border-b border-[rgba(20,43,37,0.1)] px-4 py-2.5">
                <p className="eyebrow !text-[9px]">{lang === "en" ? "In this guide" : "ამ გიდში"}</p>
              </div>
              <div className="p-2">
                {[
                  { id: "why", label: t("whyGeorgia") },
                  { id: "signs", label: t("warningSigns") },
                  { id: "before", label: t("before") },
                  { id: "during", label: t("during") },
                  { id: "after", label: t("after") },
                  { id: "checklist", label: t("checklist") },
                ].map((item) => (
                  <a key={item.id} href={`#${item.id}`} className="flex items-center gap-2 rounded px-2 py-1.5 text-[10.5px] text-[var(--ink-2)] hover:bg-[rgba(20,43,37,0.05)]">
                    <span className="h-1 w-1 rounded-full bg-[var(--clay)]" />
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-[rgba(185,84,47,0.25)] bg-[rgba(185,84,47,0.06)] p-3.5">
              <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-[#7d3b21]">
                <TriangleAlert size={12} /> {lang === "en" ? "Do not use this as an alert" : "ნუ გამოიყენებთ გაფრთხილებად"}
              </p>
              <p className="mt-1 text-[9.5px] leading-relaxed text-[#6d4a35]">
                {lang === "en"
                  ? "Hazard zones and historical records describe risk, not current conditions. For live warnings use official channels linked above."
                  : "საფრთხის ზონები და ისტორიული ჩანაწერები რისკს აღწერს და არა მიმდინარე მდგომარეობას. ცოცხალი გაფრთხილებებისთვის გამოიყენეთ ზემოთ მოცემული ოფიციალური არხები."}
              </p>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function StageSection({
  stage,
  title,
  subtitle,
  steps,
  color,
  icon,
}: {
  stage: "before" | "during" | "after";
  title: string;
  subtitle: string;
  steps: string[];
  color: string;
  icon: "check" | "alert" | "shield";
}) {
  const Icon = icon === "check" ? Check : icon === "alert" ? AlertTriangle : ShieldCheck;
  return (
    <section id={`${stage}`} className="guide-section">
      <div className="flex items-center justify-between gap-2 border-b border-[rgba(20,43,37,0.11)] pb-1.5">
        <div className="flex items-baseline gap-2">
          <h3 className="display text-[19px] leading-none" style={{ color }}>
            {title}
          </h3>
          <p className="text-[9.5px] text-[var(--muted)]">{subtitle}</p>
        </div>
        <span className="flex h-6 w-6 items-center justify-center rounded-full text-white" style={{ background: color }}>
          <Icon size={13} />
        </span>
      </div>
      <ol className="mt-2.5 space-y-2">
        {steps.map((step, i) => (
          <li key={i} className="flex gap-2.5">
            <span
              className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[9px] font-bold"
              style={{ background: `color-mix(in srgb, ${color} 13%, transparent)`, color }}
            >
              {i + 1}
            </span>
            <p className="text-[11.5px] leading-relaxed text-[var(--ink-2)]">{step}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
