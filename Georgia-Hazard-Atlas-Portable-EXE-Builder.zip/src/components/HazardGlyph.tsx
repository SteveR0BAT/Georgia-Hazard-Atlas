import type { HazardKey } from "../types";

/** Compact, recognisable hazard pictograms drawn as SVG paths. */
export function HazardGlyph({
  hazard,
  size = 18,
  strokeWidth = 1.7,
  className,
}: {
  hazard: HazardKey;
  size?: number;
  strokeWidth?: number;
  className?: string;
}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
    "aria-hidden": true,
  };
  switch (hazard) {
    case "earthquake":
      return (
        <svg {...common}>
          <path d="M2 12h3.2l1.8-5 3 10 2.5-7 1.7 2.6H22" />
          <path d="M4 19.5l3.2-2.2M18 19.5l3-2.2" opacity={0.55} />
        </svg>
      );
    case "flood":
      return (
        <svg {...common}>
          <path d="M3 9.5c2-1.8 4-1.8 6 0s4 1.8 6 0 4-1.8 6 0" />
          <path d="M3 14c2-1.8 4-1.8 6 0s4 1.8 6 0 4-1.8 6 0" opacity={0.75} />
          <path d="M6 4.5h6.5M6 4.5v2" opacity={0.6} />
        </svg>
      );
    case "landslide":
      return (
        <svg {...common}>
          <path d="M3 19h18" />
          <path d="M4 19l6-9 4 5 3-4 4 8" />
          <circle cx="8" cy="16" r="0.8" fill="currentColor" />
          <circle cx="12" cy="17.5" r="0.8" fill="currentColor" />
          <circle cx="15.5" cy="15.5" r="0.7" fill="currentColor" />
          <path d="M17 5l1.8 2.5L21 6" opacity={0.6} />
        </svg>
      );
    case "avalanche":
      return (
        <svg {...common}>
          <path d="M2 20h20" />
          <path d="M3.5 20L10 7l4 7 2-3 5 9" />
          <path d="M8 12.5c1.2.4 2.4.3 3.5-.2" opacity={0.6} />
          <path d="M17 4v3M15.5 5.5h3" opacity={0.6} />
        </svg>
      );
    case "wildfire":
      return (
        <svg {...common}>
          <path d="M12.5 3c.6 3-1.8 4.2-1.8 6.2 0 1 .8 1.8 1.8 1.8s1.8-.9 1.8-2.3c2.2 1.7 3.4 3.6 3.4 6 0 3.4-2.8 5.6-6.2 5.6S5.3 18 5.3 14.6c0-4.1 3.6-6.4 7.2-11.6z" />
          <path d="M12 20c-1.4 0-2.6-1.1-2.6-2.7 0-1.8 1.5-2.8 2.6-4.6 1.1 1.8 2.6 2.8 2.6 4.6 0 1.6-1.2 2.7-2.6 2.7z" opacity={0.55} />
        </svg>
      );
    case "drought":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2.2M12 19.8V22M2 12h2.2M19.8 12H22M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M19.1 4.9l-1.6 1.6M6.5 17.5l-1.6 1.6" />
        </svg>
      );
    case "storm":
      return (
        <svg {...common}>
          <path d="M3 8h10.5a2.5 2.5 0 100-5H9" />
          <path d="M3 12.5h15a2.7 2.7 0 110 5.4H8" />
          <path d="M3 17h4.5" opacity={0.6} />
        </svg>
      );
    case "coastal":
      return (
        <svg {...common}>
          <circle cx="17.5" cy="6" r="2.3" opacity={0.6} />
          <path d="M2 13c2-1.8 4-1.8 6 0s4 1.8 6 0 4-1.8 6 0" />
          <path d="M2 17.5c2-1.8 4-1.8 6 0s4 1.8 6 0 4-1.8 6 0" opacity={0.7} />
          <path d="M7 9l2-4 2.5 4" />
        </svg>
      );
  }
}
