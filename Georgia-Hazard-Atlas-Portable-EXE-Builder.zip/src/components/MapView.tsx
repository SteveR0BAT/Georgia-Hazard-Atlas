import { useEffect, useRef, useState } from "react";
import { Minus, Plus, RotateCcw, X } from "lucide-react";
import { GEO } from "../data/geo";
import { INCIDENTS } from "../data/incidents";
import { ZONES } from "../data/zones";
import { CITIES, LAKES, NEIGHBOURS, RANGES, RIVERS } from "../data/places";
import { HAZARD_KEYS, HAZARD_META, REGION_NAME_KA, polygonPath, project, linePath, type HazardKey, type MapSelection } from "../types";
import { useI18n } from "../i18n";
import { HazardGlyph } from "./HazardGlyph";

const [, , VB_W, VB_H] = GEO.viewBox.split(" ").map(Number);
const VB0 = { x: 0, y: 0, w: VB_W, h: VB_H };
const RATIO = VB_H / VB_W;

const REGION_LABELS: Record<string, { short: string; shortKa: string; lon: number; lat: number; size?: number }> = {
  Abkhazia: { short: "Abkhazia", shortKa: "აფხაზეთი", lon: 41.5, lat: 43.05 },
  "Samegrelo-Zemo Svaneti": { short: "Samegrelo · Svaneti", shortKa: "სამეგრელო · სვანეთი", lon: 42.05, lat: 42.6, size: 0.86 },
  "Racha-Lechkhumi and Kvemo Svaneti": { short: "Racha-Lechkhumi", shortKa: "რაჭა-ლეჩხუმი", lon: 43.0, lat: 42.42, size: 0.8 },
  Imereti: { short: "Imereti", shortKa: "იმერეთი", lon: 43.05, lat: 42.19 },
  Guria: { short: "Guria", shortKa: "გურია", lon: 42.28, lat: 42.0 },
  Adjara: { short: "Adjara", shortKa: "აჭარა", lon: 41.92, lat: 41.57 },
  "Samtskhe–Javakheti": { short: "Samtskhe–Javakheti", shortKa: "სამცხე-ჯავახეთი", lon: 43.3, lat: 41.5, size: 0.82 },
  "Kvemo Kartli": { short: "Kvemo Kartli", shortKa: "ქვემო ქართლი", lon: 44.72, lat: 41.4 },
  "Shida Kartli": { short: "Shida Kartli", shortKa: "შიდა ქართლი", lon: 43.82, lat: 42.05 },
  "Mtskheta-Mtianeti": { short: "Mtskheta-Mtianeti", shortKa: "მცხეთა-მთიანეთი", lon: 44.75, lat: 42.5, size: 0.82 },
  Kakheti: { short: "Kakheti", shortKa: "კახეთი", lon: 45.9, lat: 41.72 },
  Tbilisi: { short: "", shortKa: "", lon: 44.83, lat: 41.69 },
};

const SEA_POLYGON: [number, number][] = [
  [39.9, 43.6], [41.28, 43.36], [41.55, 43.05], [41.5, 42.7], [41.58, 42.35],
  [41.62, 42.0], [41.7, 41.7], [41.93, 41.5], [41.6, 41.35], [41.3, 41.18], [41.0, 41.09], [39.9, 41.08],
];

const MARKER_OFFSETS: Record<string, [number, number]> = {
  "tbilisi-2002": [-9, -9],
  "tbilisi-2015": [9, 7],
  "borjomi-2017": [-9, -5],
  "tsaghveri-2017": [9, 6],
  "kakheti-2012": [-8, -5],
  "kakheti-2023": [8, 6],
  "drought-2000": [0, -10],
};

function clampView(v: { x: number; y: number; w: number; h: number }) {
  const w = Math.min(VB_W, Math.max(230, v.w));
  const h = w * RATIO;
  const x = Math.min(VB_W - w + 30, Math.max(-30, v.x));
  const y = Math.min(VB_H - h + 25, Math.max(-25, v.y));
  return { x, y, w, h };
}

export interface MapProps {
  visibleHazards: Set<HazardKey>;
  showZones: boolean;
  showIncidents: boolean;
  showMunicipalities: boolean;
  showRivers: boolean;
  showCities: boolean;
  showBoundaries: boolean;
  selection: MapSelection;
  onSelectIncident: (id: string) => void;
  onSelectRegion: (name: string) => void;
  onClearSelection: () => void;
  focus?: { lon: number; lat: number; token: number } | null;
}

export function MapView({
  visibleHazards,
  showZones,
  showIncidents,
  showMunicipalities,
  showRivers,
  showCities,
  showBoundaries,
  selection,
  onSelectIncident,
  onSelectRegion,
  onClearSelection,
  focus,
}: MapProps) {
  const { t, bi } = useI18n();
  const [vb, setVb] = useState(VB0);
  const [hovered, setHovered] = useState<string | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [boxWidth, setBoxWidth] = useState(1000);
  const wrapRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ px: number; py: number; vb: typeof VB0 } | null>(null);
  const moved = useRef(false);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ dist: number; vb: typeof VB0 } | null>(null);

  useEffect(() => {
    if (!focus) return;
    const [px, py] = project(focus.lon, focus.lat);
    const w = 430;
    const h = w * RATIO;
    setVb(clampView({ x: px - w / 2, y: py - h / 2, w, h }));
  }, [focus?.token, focus]);

  const zoom = (factor: number) => {
    setVb((v) => {
      const w = v.w * factor;
      const cx = v.x + v.w / 2;
      const cy = v.y + v.h / 2;
      const h = w * RATIO;
      return clampView({ x: cx - w / 2, y: cy - h / 2, w, h });
    });
  };

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      zoom(e.deltaY > 0 ? 1.14 : 0.875);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w) setBoxWidth(w);
    });
    ro.observe(el);
    return () => {
      el.removeEventListener("wheel", onWheel);
      ro.disconnect();
    };
  }, []);

  const onPointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 1) {
      moved.current = false;
      drag.current = { px: e.clientX, py: e.clientY, vb };
      (e.currentTarget as Element).setPointerCapture(e.pointerId);
    } else if (pointers.current.size === 2) {
      const pts = [...pointers.current.values()];
      pinch.current = {
        dist: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y),
        vb,
      };
      drag.current = null;
    }
  };

  const onPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2 && pinch.current) {
      const pts = [...pointers.current.values()];
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const base = pinch.current;
      const nextW = Math.min(VB_W, Math.max(230, base.vb.w * (base.dist / Math.max(20, dist))));
      const nextH = nextW * RATIO;
      const cx = base.vb.x + base.vb.w / 2;
      const cy = base.vb.y + base.vb.h / 2;
      moved.current = true;
      setVb(clampView({ x: cx - nextW / 2, y: cy - nextH / 2, w: nextW, h: nextH }));
      return;
    }
    if (!drag.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const dx = ((e.clientX - drag.current.px) / rect.width) * drag.current.vb.w;
    const dy = ((e.clientY - drag.current.py) / Math.max(1, rect.height)) * drag.current.vb.h;
    if (Math.abs(e.clientX - drag.current.px) + Math.abs(e.clientY - drag.current.py) > 5) moved.current = true;
    setVb(
      clampView({
        x: drag.current.vb.x - dx,
        y: drag.current.vb.y - dy,
        w: drag.current.vb.w,
        h: drag.current.vb.h,
      })
    );
  };

  const endPointer = (e: React.PointerEvent<SVGSVGElement>) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinch.current = null;
    if (pointers.current.size === 0) drag.current = null;
  };

  const hoveredIncident = INCIDENTS.find((i) => i.id === hovered);
  const visiblePins = INCIDENTS.filter((i) => visibleHazards.has(i.hazard));
  const selectedId = selection?.kind === "incident" ? selection.id : null;
  // Units-per-pixel: keep labels and pins at a readable screen size at every zoom level.
  const upp = vb.w / Math.max(240, boxWidth);
  const ls = upp;
  const ms = Math.max(0.55, upp * 1.02);

  return (
    <div
      ref={wrapRef}
      className="map-sea relative h-[330px] w-full overflow-hidden sm:h-[500px] lg:h-[600px]"
      style={{ touchAction: "none" }}
    >
      <svg
        viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`}
        className="h-full w-full cursor-grab active:cursor-grabbing"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
        onPointerLeave={endPointer}
        role="application"
        aria-label={t("mapAria")}
      >
        <defs>
          {HAZARD_KEYS.map((h) => (
            <pattern
              key={h}
              id={`hatch-${h}`}
              width="7"
              height="7"
              patternUnits="userSpaceOnUse"
              patternTransform="rotate(32)"
            >
              <rect width="7" height="7" fill={HAZARD_META[h].color} fillOpacity="0.045" />
              <line x1="0" y1="0" x2="0" y2="7" stroke={HAZARD_META[h].color} strokeWidth="0.9" strokeOpacity="0.2" />
            </pattern>
          ))}
          <filter id="pin-shadow" x="-60%" y="-60%" width="220%" height="220%">
            <feDropShadow dx="0" dy="1.4" stdDeviation="1.5" floodColor="#142b25" floodOpacity="0.35" />
          </filter>
          <linearGradient id="map-land" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#eae4d5" />
            <stop offset="100%" stopColor="#e4dcc9" />
          </linearGradient>
        </defs>

        <rect x={-4000} y={-4000} width={9000} height={9000} fill="#e9e4d7" />
        <path d={polygonPath(SEA_POLYGON)} fill="#dbeae7" />
        <path d={polygonPath(SEA_POLYGON)} fill="none" stroke="#9dbdb7" strokeWidth="0.7" opacity="0.6" />

        {/* graticule */}
        <g opacity="0.45">
          {[41.3, 41.8, 42.3, 42.8, 43.3].map((lat) => {
            const [, y] = project(40, lat);
            return (
              <line
                key={lat}
                x1={0}
                x2={VB_W}
                y1={y}
                y2={y}
                stroke="#8aa39d"
                strokeWidth="0.5"
                strokeDasharray="1 5"
              />
            );
          })}
          {[40.5, 41.5, 42.5, 43.5, 44.5, 45.5, 46.5].map((lon) => {
            const [x] = project(lon, 42);
            return (
              <line
                key={lon}
                x1={x}
                x2={x}
                y1={0}
                y2={VB_H}
                stroke="#8aa39d"
                strokeWidth="0.5"
                strokeDasharray="1 5"
              />
            );
          })}
        </g>

        {/* neighbouring country labels */}
        <g>
          {NEIGHBOURS.map((n) => {
            const [x, y] = project(n.lon, n.lat);
            if (n.sea) {
              return (
                <text
                  key={n.label}
                  x={x}
                  y={y}
                  fill="#4c7e7d"
                  fontSize={10.5 * upp}
                  fontWeight="700"
                  letterSpacing={1.6 * upp}
                  opacity="0.68"
                  transform={`rotate(-69 ${x} ${y})`}
                  style={{ fontFamily: "var(--font-sans)" }}
                >
                  BLACK SEA
                </text>
              );
            }
            return (
              <text
                key={n.label}
                x={x}
                y={y}
                textAnchor="middle"
                fill="#8a9383"
                fontSize={9.5 * upp}
                fontWeight="700"
                letterSpacing={1.4 * upp}
                opacity="0.9"
                style={{ fontFamily: "var(--font-sans)" }}
              >
                {n.label}
              </text>
            );
          })}
          {[41.3, 42.3, 43.3].map((lat) => {
            const [x, y] = project(40.15, lat);
            return (
              <text key={lat} x={x} y={y} fill="#6f8b86" fontSize={7.5 * upp} opacity="0.85">
                {lat.toFixed(1)}°N
              </text>
            );
          })}
          {[41, 42, 43, 44, 45, 46].map((lon) => {
            const [x, y] = project(lon, 41.12);
            return (
              <text key={lon} x={x} y={y} fill="#6f8b86" fontSize={7.5 * upp} opacity="0.85" textAnchor="middle">
                {lon}°E
              </text>
            );
          })}
        </g>

        {/* regions */}
        <g>
          {GEO.regions.map((r) => {
            const selected = selection?.kind === "region" && selection.name === r.name;
            const hover = hoveredRegion === r.name;
            return (
              <path
                key={r.name}
                d={r.d}
                fill="url(#map-land)"
                stroke={selected ? "#5a3d22" : hover ? "#7d6a4f" : "#a59a80"}
                strokeWidth={selected ? 2.1 : hover ? 1.5 : 0.8}
                strokeLinejoin="round"
                vectorEffect="non-scaling-stroke"
                className="transition-[fill,stroke-width] duration-150"
                style={{ cursor: "pointer" }}
                onPointerEnter={() => setHoveredRegion(r.name)}
                onPointerLeave={() => setHoveredRegion(null)}
                onClick={() => {
                  if (!moved.current) onSelectRegion(r.name);
                }}
                role="button"
                aria-label={r.name}
              >
                <title>{r.name}</title>
              </path>
            );
          })}
        </g>

        {showMunicipalities && (
          <g pointerEvents="none">
            {GEO.municipalities.map((m) => (
              <path
                key={`${m.region}-${m.name}`}
                d={m.d}
                fill="none"
                stroke="#7f7563"
                strokeWidth="0.5"
                strokeOpacity="0.72"
                vectorEffect="non-scaling-stroke"
                strokeDasharray="2.4 1.8"
              />
            ))}
          </g>
        )}

        {showRivers && (
          <g pointerEvents="none">
            {RANGES.map((range) => (
              <g key={range.name.en}>
                <path
                  d={linePath(range.points)}
                  fill="none"
                  stroke="#9d8768"
                  strokeWidth="2.4"
                  strokeOpacity="0.55"
                  strokeDasharray="0.5 2.8"
                  strokeLinecap="round"
                />
                <text
                  x={project(range.labelAt[0], range.labelAt[1])[0]}
                  y={project(range.labelAt[0], range.labelAt[1])[1]}
                  textAnchor="middle"
                  fill="#8a755a"
                  fontSize={8.5 * upp}
                  fontWeight="700"
                  letterSpacing={0.8 * upp}
                  transform={`rotate(-8 ${project(range.labelAt[0], range.labelAt[1])[0]} ${project(range.labelAt[0], range.labelAt[1])[1]})`}
                >
                  {range.name.en}
                </text>
              </g>
            ))}
            {RIVERS.map((river) => {
              const [mx, my] = project(
                river.points[Math.floor(river.points.length / 2)][0] + 0.22,
                river.points[Math.floor(river.points.length / 2)][1]
              );
              return (
                <g key={river.name.en}>
                  <path
                    d={linePath(river.points)}
                    fill="none"
                    stroke="#6ea3ae"
                    strokeWidth={river.width}
                    strokeOpacity="0.82"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <text x={mx} y={my} fontSize={7.8 * upp} fill="#3f7681" fontStyle="italic" opacity="0.9">
                    {bi(river.name)}
                  </text>
                </g>
              );
            })}
            {LAKES.map((lake) => {
              const [x, y] = project(lake.lon, lake.lat);
              return (
                <g key={lake.name.en}>
                  <ellipse cx={x} cy={y} rx={lake.rx} ry={lake.ry} fill="#9cc5cc" stroke="#6ea3ae" strokeWidth="0.6" />
                  <text x={x + lake.rx + 1.5} y={y + 1.2} fontSize={7.2 * upp} fill="#3f7681" fontStyle="italic">
                    {bi(lake.name)}
                  </text>
                </g>
              );
            })}
          </g>
        )}

        {/* generalised hazard zones */}
        {showZones && (
          <g>
            {ZONES.filter((z) => visibleHazards.has(z.hazard)).map((z) => {
              const [lx, ly] = project(z.labelAt[0], z.labelAt[1]);
              return (
                <g key={z.id} pointerEvents="none">
                  <path
                    d={polygonPath(z.polygon)}
                    fill={z.strength === "higher" ? `url(#hatch-${z.hazard})` : `${HAZARD_META[z.hazard].color}0e`}
                    stroke={HAZARD_META[z.hazard].color}
                    strokeWidth="0.75"
                    strokeOpacity={z.strength === "higher" ? 0.5 : 0.3}
                    strokeDasharray={z.strength === "higher" ? "3.4 2.2" : "1.8 3"}
                    opacity={z.strength === "higher" ? 0.9 : 0.75}
                    vectorEffect="non-scaling-stroke"
                  >
                    <title>{`${bi(z.name)} — ${bi(z.note)}`}</title>
                  </path>
                  {z.strength === "higher" && vb.w < 450 && (
                    <text
                      x={lx}
                      y={ly}
                      textAnchor="middle"
                      fontSize={7.2 * upp}
                      fontWeight="700"
                      fill={HAZARD_META[z.hazard].dark}
                      stroke="#f3efe4"
                      strokeWidth={2 * upp}
                      paintOrder="stroke"
                      letterSpacing="0.35"
                    >
                      {bi(z.name).toUpperCase()}
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        )}

        {/* region labels */}
        {showBoundaries && (
          <g pointerEvents="none">
            {GEO.regions.map((r) => {
              const selected = selection?.kind === "region" && selection.name === r.name;
              const o = REGION_LABELS[r.name];
              const label = o ? bi({ en: o.short, ka: o.shortKa }) : bi({ en: r.name, ka: REGION_NAME_KA[r.name] ?? r.name });
              if (!label) return null;
              const [x, y] = o ? project(o.lon, o.lat) : [r.lx, r.ly];
              const factor = o?.size ?? 1;
              return (
                <text
                  key={`label-${r.name}`}
                  x={x}
                  y={y}
                  textAnchor="middle"
                  fontSize={(selected ? 14 : 12.2) * upp * factor}
                  fontWeight={selected ? 800 : 700}
                  fill={selected ? "#3f2d1c" : "#4b5c4d"}
                  stroke="#f5f1e6"
                  strokeWidth={2.4 * upp}
                  paintOrder="stroke"
                  style={{ letterSpacing: "0.1px" }}
                >
                  {label}
                </text>
              );
            })}
          </g>
        )}

        {/* calls / city labels */}
        {showCities && (
          <g>
            {CITIES.filter((c) => c.size !== "town" || vb.w < 690).map((city) => {
              const [x, y] = project(city.lon, city.lat);
              const isCap = city.size === "capital";
              return (
                <g key={city.name.en} pointerEvents="none">
                  {isCap ? (
                    <rect x={x - 3.4 * upp} y={y - 3.4 * upp} width={6.8 * upp} height={6.8 * upp} rx={0.8 * upp} fill="#142b25" stroke="#fbf9f2" strokeWidth={1.15 * upp} />
                  ) : (
                    <circle cx={x} cy={y} r={(city.size === "major" ? 2.9 : 2.3) * upp} fill="#223c32" stroke="#fbf9f2" strokeWidth={1 * upp} />
                  )}
                  {city.name.en !== "Tbilisi" ? (
                    <text
                      x={x + 4.6 * upp}
                      y={y + 2.8 * upp}
                      fontSize={(isCap ? 11.5 : city.size === "major" ? 9.8 : 8.8) * upp}
                      fontWeight={isCap ? 800 : 600}
                      fill="#263b31"
                      stroke="#f3efe4"
                      strokeWidth={1.8 * upp}
                      paintOrder="stroke"
                    >
                      {bi(city.name)}
                    </text>
                  ) : (
                    <text
                      x={x + 4.8 * upp}
                      y={y + 11 * upp}
                      fontSize={10.5 * upp}
                      fontWeight={800}
                      fill="#1d332a"
                      stroke="#f3efe4"
                      strokeWidth={2.4 * upp}
                      paintOrder="stroke"
                    >
                      {bi(city.name)}
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        )}

        {/* historical incident pins */}
        {showIncidents && (
          <g>
            {visiblePins.map((incident) => {
              const [x, y] = project(incident.lon, incident.lat);
              const [dx, dy] = MARKER_OFFSETS[incident.id] ?? [0, 0];
              const selected = selectedId === incident.id;
              const meta = HAZARD_META[incident.hazard];
              return (
                <g
                  key={incident.id}
                  transform={`translate(${x + dx * ms},${y + dy * ms})`}
                  onPointerDown={(e) => e.stopPropagation()}
                  onMouseEnter={() => setHovered(incident.id)}
                  onMouseLeave={() => setHovered(null)}
                  onFocus={() => setHovered(incident.id)}
                  onBlur={() => setHovered(null)}
                  onClick={() => onSelectIncident(incident.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      onSelectIncident(incident.id);
                    }
                  }}
                  className="marker-hit"
                  role="button"
                  tabIndex={0}
                  aria-label={`${bi(incident.title)}, ${bi(incident.dateLabel)}`}
                  style={{ outline: "none" }}
                >
                  <title>{`${bi(incident.title)} · ${bi(incident.dateLabel)}`}</title>
                  <g transform={`scale(${ms})`}>
                    {selected && (
                      <circle r="13" fill="none" stroke={meta.color} strokeWidth="1.3" className="marker-pulse" />
                    )}
                    <g filter="url(#pin-shadow)">
                      <circle
                        r={selected ? 9.8 : 8.2}
                        fill={meta.color}
                        stroke="#fbf9f2"
                        strokeWidth={selected ? 2.2 : 1.7}
                      />
                      <g transform="translate(-5.4,-5.4)" color="#fbf9f2">
                        <HazardGlyph hazard={incident.hazard} size={10.8} strokeWidth={2} />
                      </g>
                    </g>
                  </g>
                </g>
              );
            })}
          </g>
        )}
      </svg>

      {/* hover tooltip */}
      {hoveredIncident && (
        <div className="pointer-events-none absolute left-1/2 top-3 z-10 max-w-[calc(100%-150px)] -translate-x-1/2 rounded-lg border border-[rgba(20,43,37,0.16)] bg-[rgba(251,249,242,0.97)] px-3 py-2 shadow-lg">
          <p className="flex items-center gap-1.5 text-[11.5px] font-bold leading-tight text-[var(--ink)]">
            <span style={{ color: HAZARD_META[hoveredIncident.hazard].color }}>
              <HazardGlyph hazard={hoveredIncident.hazard} size={13} />
            </span>
            {bi(hoveredIncident.title)}
          </p>
          <p className="mt-0.5 text-[10px] text-[var(--muted)]">{bi(hoveredIncident.dateLabel)}</p>
        </div>
      )}

      {/* map controls */}
      <div className="absolute right-3 top-3 z-10 flex flex-col overflow-hidden rounded-lg border border-[rgba(20,43,37,0.2)] bg-[var(--cream)]/95 shadow-md">
        <button onClick={() => zoom(0.78)} className="p-2 text-[var(--ink)] hover:bg-[rgba(20,43,37,0.08)]" aria-label={t("zoomIn")} title={t("zoomIn")}>
          <Plus size={16} />
        </button>
        <div className="h-px bg-[rgba(20,43,37,0.13)]" />
        <button onClick={() => zoom(1.28)} className="p-2 text-[var(--ink)] hover:bg-[rgba(20,43,37,0.08)]" aria-label={t("zoomOut")} title={t("zoomOut")}>
          <Minus size={16} />
        </button>
        <div className="h-px bg-[rgba(20,43,37,0.13)]" />
        <button
          onClick={() => {
            setVb(VB0);
            onClearSelection();
          }}
          className="p-2 text-[var(--ink)] hover:bg-[rgba(20,43,37,0.08)]"
          aria-label={t("resetView")}
          title={t("resetView")}
        >
          <RotateCcw size={15} />
        </button>
      </div>

      {/* legend */}
      <Legend visibleHazards={visibleHazards} />

      <div className="pointer-events-none absolute bottom-1 right-2 z-10 max-w-[68%] text-right text-[8.5px] leading-tight text-[var(--muted)]">
        {t("mapCredit")}
      </div>

      {selection && (
        <button
          onClick={onClearSelection}
          className="absolute right-3 bottom-9 z-10 flex items-center gap-1 rounded-full border border-[rgba(20,43,37,0.18)] bg-[var(--cream)]/95 px-2.5 py-1.5 text-[10px] font-semibold text-[var(--ink)] shadow-sm hover:bg-white"
        >
          <X size={11} /> {t("close")}
        </button>
      )}
    </div>
  );
}

function Legend({ visibleHazards }: { visibleHazards: Set<HazardKey> }) {
  const { t, bi } = useI18n();
  const [open, setOpen] = useState(() => (typeof window === "undefined" ? true : window.innerWidth >= 768));
  return (
    <div className="absolute left-3 top-3 z-10 max-w-[214px] overflow-hidden rounded-lg border border-[rgba(20,43,37,0.18)] bg-[var(--cream)]/95 shadow-md backdrop-blur-sm">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-2 px-2.5 py-1.5 text-[9px] font-bold uppercase tracking-[0.11em] text-[var(--ink)]"
        aria-expanded={open}
      >
        {t("legend")}
        <span className="text-[var(--muted)]">{open ? "−" : "+"}</span>
      </button>
      {open && (
        <div className="border-t border-[rgba(20,43,37,0.1)] px-2.5 py-2">
          <div className="mb-1.5 flex items-center gap-1.5 text-[9px] text-[var(--ink-2)]">
            <span className="relative flex h-4 w-4 items-center justify-center">
              <span className="absolute h-3.5 w-3.5 rounded-full bg-[var(--clay)]" />
              <span className="relative h-1.5 w-1.5 rounded-full border border-white bg-[var(--clay)]" />
            </span>
            {t("legendPin")}
          </div>
          <div className="mb-1.5 flex items-center gap-1.5 text-[9px] text-[var(--ink-2)]">
            <span className="h-3.5 w-4 rounded-sm border border-dashed border-[var(--gold)] bg-[var(--gold)]/15" />
            {t("legendZone")}
          </div>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1 border-t border-[rgba(20,43,37,0.09)] pt-1.5">
            {HAZARD_KEYS.filter((h) => visibleHazards.has(h)).map((h) => (
              <div key={h} className="flex min-w-0 items-center gap-1">
                <span
                  className="flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full text-white"
                  style={{ background: HAZARD_META[h].color }}
                >
                  <HazardGlyph hazard={h} size={8} strokeWidth={2.4} />
                </span>
                <span className="truncate text-[8px] leading-tight text-[var(--ink-2)]">{bi(HAZARD_META[h].label)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
