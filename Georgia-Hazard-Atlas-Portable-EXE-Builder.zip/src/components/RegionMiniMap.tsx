import { GEO } from "../data/geo";

/** Minimal path-bounds parser for the generated Georgia region paths. */
function pathBounds(d: string): { x: number; y: number; w: number; h: number } {
  const nums = d.match(/-?\d+(?:\.\d+)?/g)?.map(Number) ?? [];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (let i = 0; i + 1 < nums.length; i += 2) {
    minX = Math.min(minX, nums[i]);
    maxX = Math.max(maxX, nums[i]);
    minY = Math.min(minY, nums[i + 1]);
    maxY = Math.max(maxY, nums[i + 1]);
  }
  if (!Number.isFinite(minX)) return { x: 0, y: 0, w: 1000, h: 508.6 };
  return { x: minX, y: minY, w: Math.max(1, maxX - minX), h: Math.max(1, maxY - minY) };
}

const cache = new Map<string, string>();

/** Cropped silhouette of a region so small units remain recognisable. */
export function RegionMiniMap({
  regionName,
  className = "",
  stroke = "rgba(20,43,37,0.45)",
  fill = "rgba(20,43,37,0.09)",
  strokeWidth = 5,
}: {
  regionName: string;
  className?: string;
  stroke?: string;
  fill?: string;
  strokeWidth?: number;
}) {
  const region = GEO.regions.find((r) => r.name === regionName);
  if (!region) return null;
  let viewBox = cache.get(region.name);
  if (!viewBox) {
    const b = pathBounds(region.d);
    const pad = Math.max(b.w, b.h) * 0.09 + 8;
    viewBox = `${(b.x - pad).toFixed(1)} ${(b.y - pad).toFixed(1)} ${(b.w + pad * 2).toFixed(1)} ${(b.h + pad * 2).toFixed(1)}`;
    cache.set(region.name, viewBox);
  }
  return (
    <svg viewBox={viewBox} className={className} aria-hidden="true" preserveAspectRatio="xMidYMid meet">
      <path d={region.d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />
    </svg>
  );
}
