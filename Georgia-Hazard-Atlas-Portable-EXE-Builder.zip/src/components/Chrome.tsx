import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  BookOpen,
  ChevronRight,
  Clock3,
  ExternalLink,
  Languages,
  Map as MapIcon,
  MapPinned,
  Menu,
  Phone,
  Search,
  ShieldAlert,
  X,
  Library,
  Compass,
} from "lucide-react";
import { useI18n } from "../i18n";
import type { HazardKey, Lang, Page, RegionInfo } from "../types";
import { HAZARD_META, REGION_NAME_KA } from "../types";
import { INCIDENTS } from "../data/incidents";
import { REGIONS } from "../data/regions";
import { GUIDES } from "../data/guides";
import { GEO } from "../data/geo";
import { CITIES } from "../data/places";
import { HazardGlyph } from "./HazardGlyph";

export function BrandMark({ size = 42 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <rect width="48" height="48" rx="11" fill="#142b25" />
      <path d="M8 33.5l9.5-17 6 9.5 3.2-5L34 33.5H8z" fill="#f3efe4" opacity="0.92" />
      <path d="M8 37h32" stroke="#b9542f" strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="33" cy="12.5" r="3.1" fill="#b68a34" />
    </svg>
  );
}

const NAV: { page: Page; key: "navMap" | "navGuide" | "navTimeline" | "navRegions" | "navSources"; icon: typeof MapIcon }[] = [
  { page: "map", key: "navMap", icon: MapIcon },
  { page: "guides", key: "navGuide", icon: BookOpen },
  { page: "timeline", key: "navTimeline", icon: Clock3 },
  { page: "regions", key: "navRegions", icon: MapPinned },
  { page: "sources", key: "navSources", icon: Library },
];

export function Header({
  page,
  onNavigate,
  onSearch,
  onEmergency,
  lang,
  setLang,
}: {
  page: Page;
  onNavigate: (p: Page) => void;
  onSearch: () => void;
  onEmergency: () => void;
  lang: Lang;
  setLang: (l: Lang) => void;
}) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 no-print">
      <div className="bg-[#0e2620] text-[#ece6d7]">
        <div className="mx-auto flex h-9 max-w-[1440px] items-center justify-between gap-3 px-4 text-[11px] sm:px-6">
          <a href="tel:112" className="flex items-center gap-1.5 font-semibold tracking-wide hover:text-white">
            <Phone size={12} strokeWidth={2.4} />
            {t("ribbonPrefix")} <span className="text-[#f0b48f]">112</span>
          </a>
          <p className="hidden items-center gap-2 text-[#c8c2b3] md:flex">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#b68a34]" />
            {t("notLive")} · {t("staticChip")}
          </p>
          <button
            onClick={onEmergency}
            className="flex items-center gap-1 font-semibold text-[#e7d4bc] hover:text-white"
          >
            {t("emergencyBtn")}
            <ChevronRight size={12} />
          </button>
        </div>
      </div>
      <div className="border-b border-[rgba(20,43,37,0.14)] bg-[rgba(251,249,242,0.96)] backdrop-blur-md">
        <div className="mx-auto flex h-[70px] max-w-[1440px] items-center gap-4 px-4 sm:px-6">
          <button
            onClick={() => onNavigate("map")}
            className="flex shrink-0 items-center gap-3 text-left"
            aria-label={`${t("brand")} — ${t("navMap")}`}
          >
            <BrandMark size={40} />
            <span>
              <span className="display block text-[16px] font-semibold leading-none text-[var(--ink)] sm:text-[19px]">
                <span className="sm:hidden">{t("brandShort")}</span>
                <span className="hidden sm:inline">{t("brand")}</span>
              </span>
              <span className="mt-1 hidden text-[10px] font-semibold uppercase tracking-[0.13em] text-[var(--muted)] sm:block">
                {t("brandSub")}
              </span>
            </span>
          </button>

          <nav className="ml-3 hidden items-center gap-0.5 lg:flex" aria-label="Primary">
            {NAV.map((item) => {
              const active = page === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => onNavigate(item.page)}
                  aria-current={active ? "page" : undefined}
                  className={`relative rounded-full px-3.5 py-2 text-[12.5px] font-semibold transition-colors ${
                    active
                      ? "text-[var(--ink)]"
                      : "text-[var(--muted)] hover:bg-[rgba(20,43,37,0.05)] hover:text-[var(--ink)]"
                  }`}
                >
                  {t(item.key)}
                  {active && (
                    <span className="absolute inset-x-3.5 -bottom-[1px] h-[2px] rounded-full bg-[var(--clay)]" />
                  )}
                </button>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={onSearch}
              className="flex h-9 items-center gap-2 rounded-full border border-[rgba(20,43,37,0.16)] bg-white/50 px-2.5 text-[12px] text-[var(--muted)] transition-colors hover:border-[rgba(20,43,37,0.3)] hover:text-[var(--ink)] sm:px-3"
              aria-label={t("search")}
            >
              <Search size={15} />
              <span className="hidden md:inline">{t("search")}</span>
              <kbd className="hidden rounded border border-[rgba(20,43,37,0.16)] bg-white/70 px-1.5 py-0.5 text-[9px] font-semibold text-[var(--muted)] md:inline">
                /
              </kbd>
            </button>
            <div
              className="flex h-9 items-center rounded-full border border-[rgba(20,43,37,0.16)] bg-white/50 p-0.5"
              role="group"
              aria-label="Language"
            >
              <Languages size={13} className="ml-1.5 hidden text-[var(--muted)] sm:block" />
              <button
                onClick={() => setLang("en")}
                aria-pressed={lang === "en"}
                className={`rounded-full px-2 py-1 text-[10.5px] font-bold transition-colors ${
                  lang === "en" ? "bg-[var(--ink)] text-[var(--cream)]" : "text-[var(--muted)] hover:text-[var(--ink)]"
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLang("ka")}
                aria-pressed={lang === "ka"}
                className={`rounded-full px-2 py-1 text-[10.5px] font-bold transition-colors ${
                  lang === "ka" ? "bg-[var(--ink)] text-[var(--cream)]" : "text-[var(--muted)] hover:text-[var(--ink)]"
                }`}
              >
                ქა
              </button>
            </div>
            <button
              onClick={onEmergency}
              className="hidden h-9 items-center gap-1.5 rounded-full bg-[var(--clay)] px-3.5 text-[11.5px] font-bold text-white transition-colors hover:bg-[#9f4527] sm:flex"
            >
              <ShieldAlert size={14} />
              112
            </button>
            <button
              onClick={() => setOpen((v) => !v)}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[rgba(20,43,37,0.16)] bg-white/50 text-[var(--ink)] lg:hidden"
              aria-label={t("menu")}
              aria-expanded={open}
            >
              {open ? <X size={17} /> : <Menu size={17} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="border-t border-[rgba(20,43,37,0.12)] bg-[var(--cream)] px-4 py-2 lg:hidden">
            {NAV.map((item) => (
              <button
                key={item.page}
                onClick={() => {
                  onNavigate(item.page);
                  setOpen(false);
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-semibold ${
                  page === item.page ? "bg-[rgba(47,85,71,0.1)] text-[var(--ink)]" : "text-[var(--muted)]"
                }`}
              >
                <item.icon size={16} />
                {t(item.key)}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}

/* ------------------------------- search ------------------------------- */

type Result =
  | { kind: "incident"; id: string; title: string; meta: string; hazard: HazardKey }
  | { kind: "region"; id: string; title: string; meta: string }
  | { kind: "place"; id: string; title: string; meta: string; regionName: string }
  | { kind: "guide"; id: HazardKey; title: string; meta: string };

const CITY_REGION: Record<string, string> = {
  Tbilisi: "Tbilisi", Batumi: "Adjara", Kutaisi: "Imereti", Rustavi: "Kvemo Kartli",
  Gori: "Shida Kartli", Zugdidi: "Samegrelo-Zemo Svaneti", Telavi: "Kakheti",
  Akhaltsikhe: "Samtskhe–Javakheti", Mtskheta: "Mtskheta-Mtianeti", Poti: "Samegrelo-Zemo Svaneti",
  Ozurgeti: "Guria", Ambrolauri: "Racha-Lechkhumi and Kvemo Svaneti", Mestia: "Samegrelo-Zemo Svaneti",
  Oni: "Racha-Lechkhumi and Kvemo Svaneti", Borjomi: "Samtskhe–Javakheti", Kobuleti: "Adjara",
  Stepantsminda: "Mtskheta-Mtianeti", Dusheti: "Mtskheta-Mtianeti", Kvareli: "Kakheti",
  Sukhumi: "Abkhazia", Gagra: "Abkhazia", Tsageri: "Racha-Lechkhumi and Kvemo Svaneti",
};

export function SearchDialog({
  onClose,
  onPickIncident,
  onPickRegion,
  onPickGuide,
}: {
  onClose: () => void;
  onPickIncident: (id: string) => void;
  onPickRegion: (region: RegionInfo) => void;
  onPickGuide: (hazard: HazardKey) => void;
}) {
  const { t, lang, bi } = useI18n();
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const results = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (query.length < 2) return { regions: [] as Result[], incidents: [] as Result[], guides: [] as Result[], places: [] as Result[] };
    const match = (values: string[]) => values.some((v) => v.toLowerCase().includes(query));

    const regions: Result[] = REGIONS.filter((r) =>
      match([r.name, r.nameKa, r.center.en, r.center.ka])
    )
      .slice(0, 4)
      .map((r) => ({
        kind: "region",
        id: r.id,
        title: lang === "en" ? r.name : r.nameKa,
        meta: `${bi(r.center)} · ${lang === "en" ? "regional profile" : "რეგიონული პროფილი"}`,
      }));

    const seen = new Set<string>();
    const places: Result[] = [
      ...GEO.municipalities.map((m) => ({
        name: m.name,
        regionName: m.region,
        type: lang === "en" ? "Municipality" : "მუნიციპალიტეტი",
      })),
      ...CITIES.map((c) => ({
        name: bi(c.name),
        regionName: CITY_REGION[c.name.en] ?? "",
        type: lang === "en" ? "City / town" : "ქალაქი / დაბა",
      })),
    ]
      .filter((p) => p.regionName && match([p.name]))
      .filter((p) => {
        const key = `${p.name}-${p.regionName}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, 6)
      .map((p) => ({
        kind: "place" as const,
        id: `${p.name}-${p.regionName}`,
        title: p.name,
        meta: `${p.type} · ${lang === "en" ? p.regionName : REGION_NAME_KA[p.regionName] ?? p.regionName}`,
        regionName: p.regionName,
      }));

    const incidents: Result[] = INCIDENTS.filter((i) =>
      match([
        i.title.en,
        i.title.ka,
        i.location.en,
        i.location.ka,
        i.region,
        REGION_NAME_KA[i.region] ?? "",
        i.dateLabel.en,
        String(new Date(i.startDate).getFullYear()),
        bi(HAZARD_META[i.hazard].label),
      ])
    )
      .slice(0, 6)
      .map((i) => ({
        kind: "incident",
        id: i.id,
        title: bi(i.title),
        meta: `${bi(i.dateLabel)} · ${bi(i.location)}`,
        hazard: i.hazard,
      }));

    const guides: Result[] = GUIDES.filter((g) => match([g.id, bi(HAZARD_META[g.id].label), ...g.signs.map(bi)]))
      .slice(0, 4)
      .map((g) => ({ kind: "guide", id: g.id, title: bi(HAZARD_META[g.id].label), meta: bi(g.tagline) }));

    return { regions, incidents, guides, places };
  }, [q, lang, bi]);

  const pick = (r: Result) => {
    if (r.kind === "incident") onPickIncident(r.id);
    if (r.kind === "guide") onPickGuide(r.id);
    if (r.kind === "region") {
      const region = REGIONS.find((x) => x.id === r.id);
      if (region) onPickRegion(region);
    }
    if (r.kind === "place") {
      const region = REGIONS.find((x) => x.name === r.regionName);
      if (region) onPickRegion(region);
    }
  };

  const group = (label: string, items: Result[]) =>
    items.length > 0 && (
      <div className="mb-3">
        <p className="eyebrow mb-1.5 px-2">{label}</p>
        <div className="space-y-0.5">
          {items.map((r) => (
            <button
              key={`${r.kind}-${r.id}`}
              onClick={() => pick(r)}
              className="flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-[rgba(20,43,37,0.06)]"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[rgba(47,85,71,0.1)] text-[var(--forest)]">
                {r.kind === "incident" ? (
                  <HazardGlyph hazard={r.hazard} size={16} />
                ) : r.kind === "guide" ? (
                  <BookOpen size={15} />
                ) : (
                  <MapPinned size={15} />
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13px] font-semibold text-[var(--ink)]">{r.title}</span>
                <span className="block truncate text-[11px] text-[var(--muted)]">{r.meta}</span>
              </span>
              <ChevronRight size={14} className="shrink-0 text-[var(--muted)]" />
            </button>
          ))}
        </div>
      </div>
    );

  const any = results.regions.length + results.incidents.length + results.guides.length + results.places.length > 0;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center bg-[rgba(10,27,23,0.55)] px-3 pt-[8vh] backdrop-blur-[2px] sm:px-6"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={t("search")}
    >
      <div className="w-full max-w-[620px] overflow-hidden rounded-2xl border border-[rgba(20,43,37,0.18)] bg-[var(--cream)] shadow-2xl fade-up">
        <div className="flex items-center gap-3 border-b border-[rgba(20,43,37,0.12)] px-4 py-3">
          <Search size={19} className="text-[var(--muted)]" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("searchPlaceholder")}
            className="min-w-0 flex-1 bg-transparent py-1 text-[15px] text-[var(--ink)] outline-none placeholder:text-[var(--muted)]/80"
            aria-label={t("search")}
          />
          <button onClick={onClose} aria-label={t("searchClose")} className="rounded-full p-1.5 hover:bg-[rgba(20,43,37,0.08)]">
            <X size={17} />
          </button>
        </div>
        <div className="max-h-[58vh] overflow-y-auto px-2 py-3 scroll-area">
          {q.trim().length < 2 ? (
            <div className="px-3 py-6 text-center">
              <p className="text-[13px] text-[var(--muted)]">{t("searchHint")}</p>
              <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                {(["earthquake", "flood", "landslide", "wildfire"] as HazardKey[]).map((h) => (
                  <button
                    key={h}
                    onClick={() => onPickGuide(h)}
                    className="chip hover:border-[rgba(20,43,37,0.35)]"
                    style={{ color: HAZARD_META[h].dark }}
                  >
                    <HazardGlyph hazard={h} size={13} />
                    {bi(HAZARD_META[h].label)}
                  </button>
                ))}
              </div>
            </div>
          ) : !any ? (
            <p className="px-3 py-8 text-center text-[13px] text-[var(--muted)]">{t("searchNoRes")}</p>
          ) : (
            <>
              {group(t("searchIncidents"), results.incidents)}
              {group(t("searchPlaces"), results.places)}
              {group(lang === "en" ? "Regional profiles" : "რეგიონული პროფილები", results.regions)}
              {group(t("searchGuides"), results.guides)}
            </>
          )}
        </div>
        <div className="flex items-center justify-between border-t border-[rgba(20,43,37,0.1)] bg-[rgba(20,43,37,0.025)] px-4 py-2 text-[10px] text-[var(--muted)]">
          <span>112 · {t("notLive")}</span>
          <span className="hidden sm:inline">Esc</span>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------- emergency panel ---------------------------- */

const MONITORING_LINKS = [
  { label: "112 Georgia", desc: "Police, fire-rescue & ambulance", url: "https://112.gov.ge/", tag: "Official" },
  { label: "National Environmental Agency", desc: "Hydrometeorology, geology & forecasts", url: "https://nea.gov.ge/", tag: "Official" },
  { label: "Emergency Situations Management Service", desc: "Rescue, evacuation & civil protection", url: "https://police.ge/en", tag: "Official" },
  { label: "Georgian Red Cross", desc: "First aid, preparedness & relief", url: "https://redcross.ge/en/", tag: "Agency" },
  { label: "USGS Latest Earthquakes", desc: "Live seismic feed (external)", url: "https://earthquake.usgs.gov/earthquakes/map/", tag: "Live, external" },
  { label: "EMSC — Caucasus", desc: "Live seismic catalogue (external)", url: "https://www.emsc-csem.org/", tag: "Live, external" },
];

export function EmergencyPanel({
  onClose,
  onPickGuide,
}: {
  onClose: () => void;
  onPickGuide: (h: HazardKey) => void;
}) {
  const { t, bi } = useI18n();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[60] flex justify-end bg-[rgba(10,27,23,0.55)] backdrop-blur-[2px]"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={t("emergencyTitle")}
    >
      <div className="slide-over h-full w-full max-w-[540px] overflow-y-auto bg-[var(--paper)] scroll-area">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[rgba(20,43,37,0.15)] bg-[#132b25] px-5 py-4 text-[var(--cream)]">
          <div className="flex items-center gap-2.5">
            <ShieldAlert size={19} className="text-[#f0b48f]" />
            <p className="text-sm font-bold uppercase tracking-[0.1em]">{t("emergencyTitle")}</p>
          </div>
          <button onClick={onClose} aria-label={t("close")} className="rounded-full p-1.5 hover:bg-white/10">
            <X size={19} />
          </button>
        </div>

        <div className="space-y-5 p-5">
          <div className="overflow-hidden rounded-2xl border border-[rgba(185,84,47,0.3)] bg-[var(--cream)]">
            <div className="flex items-center justify-between bg-[var(--clay)] px-5 py-3 text-white">
              <div>
                <p className="eyebrow !text-white/80">{t("emergencyContacts")}</p>
                <p className="display mt-0.5 text-[42px] leading-none">112</p>
              </div>
              <Phone size={38} strokeWidth={1.4} className="text-white/85" />
            </div>
            <div className="p-4">
              <p className="text-[12.5px] leading-relaxed text-[var(--ink-2)]">{t("emergencySub")}</p>
              <a href="tel:112" className="btn btn-primary mt-3 w-full !bg-[var(--clay)] hover:!bg-[#9f4527]">
                <Phone size={15} /> {t("call112")}
              </a>
            </div>
          </div>

          <section>
            <h3 className="mb-2 text-sm font-bold text-[var(--ink)]">{t("whatToSay")}</h3>
            <ol className="space-y-2">
              {[t("whatToSay1"), t("whatToSay2"), t("whatToSay3"), t("whatToSay4")].map((line, i) => (
                <li key={i} className="flex gap-2.5 text-[12.5px] leading-relaxed text-[var(--ink-2)]">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[rgba(47,85,71,0.12)] text-[10px] font-bold text-[var(--forest)]">
                    {i + 1}
                  </span>
                  {line}
                </li>
              ))}
            </ol>
          </section>

          <div className="rounded-xl border border-[#d8b894] bg-[#f6ead8] p-3.5">
            <p className="text-[12px] font-bold text-[#7f4a22]">{t("noLiveTitle")}</p>
            <p className="mt-1 text-[11.5px] leading-relaxed text-[#6a4a30]">{t("noLiveBody")}</p>
          </div>

          <section>
            <h3 className="mb-2 text-sm font-bold text-[var(--ink)]">{t("officialMonitoring")}</h3>
            <div className="divide-y divide-[rgba(20,43,37,0.1)] overflow-hidden rounded-xl border border-[rgba(20,43,37,0.14)] bg-[var(--cream)]">
              {MONITORING_LINKS.map((link) => (
                <a
                  key={link.url}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 px-3.5 py-2.5 transition-colors hover:bg-[rgba(20,43,37,0.04)]"
                >
                  <ExternalLink size={14} className="shrink-0 text-[var(--forest)]" />
                  <span className="min-w-0 flex-1">
                    <span className="block text-[12.5px] font-semibold leading-tight text-[var(--ink)]">{link.label}</span>
                    <span className="mt-0.5 block text-[10.5px] text-[var(--muted)]">{link.desc}</span>
                  </span>
                  <span className="shrink-0 rounded-full bg-[rgba(20,43,37,0.06)] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-[var(--muted)]">
                    {link.tag}
                  </span>
                </a>
              ))}
            </div>
          </section>

          <section>
            <h3 className="mb-2 text-sm font-bold text-[var(--ink)]">{t("guidesForAll")}</h3>
            <div className="grid grid-cols-2 gap-1.5">
              {GUIDES.map((g) => (
                <button
                  key={g.id}
                  onClick={() => onPickGuide(g.id)}
                  className="flex items-center gap-2 rounded-lg border border-[rgba(20,43,37,0.14)] bg-[var(--cream)] px-2.5 py-2 text-left text-[11.5px] font-semibold text-[var(--ink-2)] hover:border-[rgba(20,43,37,0.3)]"
                >
                  <span style={{ color: HAZARD_META[g.id].color }}>
                    <HazardGlyph hazard={g.id} size={15} />
                  </span>
                  <span className="leading-tight">{bi(HAZARD_META[g.id].label)}</span>
                </button>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- footer -------------------------------- */

export function Footer({
  onNavigate,
  onEmergency,
  onSearch,
}: {
  onNavigate: (p: Page) => void;
  onEmergency: () => void;
  onSearch: () => void;
}) {
  const { t } = useI18n();
  return (
    <footer className="mt-14 bg-[#122a24] text-[#ded8c9] no-print">
      <div className="mx-auto max-w-[1440px] px-4 py-10 sm:px-6">
        <div className="grid gap-8 md:grid-cols-[1.4fr_1fr_1fr_1.1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <BrandMark size={34} />
              <div>
                <p className="display text-base font-semibold text-[var(--cream)]">{t("brand")}</p>
                <p className="text-[10px] uppercase tracking-[0.12em] text-[#9fac9f]">{t("brandSub")}</p>
              </div>
            </div>
            <p className="mt-3 max-w-xs text-[11.5px] leading-relaxed text-[#aab6aa]">{t("footDisclaimer")}</p>
          </div>
          <div>
            <p className="eyebrow !text-[#b9c3b7]">{t("navMap")}</p>
            <div className="mt-2 space-y-1.5 text-[12px]">
              {(["map", "guides", "timeline", "regions"] as Page[]).map((p) => (
                <button key={p} onClick={() => onNavigate(p)} className="block text-left hover:text-white">
                  {p === "map" ? t("navMap") : p === "guides" ? t("navGuide") : p === "timeline" ? t("navTimeline") : t("navRegions")}
                </button>
              ))}
              <button onClick={onSearch} className="block text-left hover:text-white">
                {t("search")}
              </button>
            </div>
          </div>
          <div>
            <p className="eyebrow !text-[#b9c3b7]">{t("officialsLinks")}</p>
            <div className="mt-2 space-y-1.5 text-[12px]">
              <a href="https://112.gov.ge/" target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-white">
                112 Georgia <ArrowUpRight size={11} />
              </a>
              <a href="https://nea.gov.ge/" target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-white">
                National Environmental Agency <ArrowUpRight size={11} />
              </a>
              <a href="https://police.ge/en" target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-white">
                Emergency Situations Service <ArrowUpRight size={11} />
              </a>
              <button onClick={() => onNavigate("sources")} className="block text-left hover:text-white">
                {t("bibliography")}
              </button>
            </div>
          </div>
          <div className="rounded-xl border border-white/15 bg-white/[0.04] p-4">
            <p className="eyebrow !text-[#eebfa2]">{t("emergencyContacts")}</p>
            <a href="tel:112" className="display mt-1 block text-3xl text-white hover:text-[#f0b48f]">
              112
            </a>
            <p className="mt-1 text-[11px] leading-relaxed text-[#aab6aa]">{t("emergencyShort")}</p>
            <button onClick={onEmergency} className="btn mt-2.5 w-full !border-white/25 !bg-transparent !text-[#e8e2d4] hover:!bg-white/10">
              <ShieldAlert size={13} /> {t("emergencyBtn")}
            </button>
          </div>
        </div>
        <div className="mt-8 flex flex-col gap-2 border-t border-white/12 pt-4 text-[10px] text-[#89968a] sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 Hazard Atlas Georgia · research compilation, not an official government product.</p>
          <p className="flex items-center gap-1.5">
            <Compass size={11} /> Vector boundaries: geoBoundaries · CC BY 3.0
          </p>
        </div>
      </div>
    </footer>
  );
}
