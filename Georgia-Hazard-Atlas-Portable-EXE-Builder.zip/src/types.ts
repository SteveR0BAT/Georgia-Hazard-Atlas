import { GEO } from "./data/geo";

export type Lang = "en" | "ka";
export type Page = "map" | "guides" | "timeline" | "regions" | "sources";
export type MapSelection = { kind: "incident"; id: string } | { kind: "region"; name: string } | null;
export type Loc<T = string> = { en: T; ka: T };

export type HazardKey =
  | "earthquake"
  | "flood"
  | "landslide"
  | "avalanche"
  | "wildfire"
  | "drought"
  | "storm"
  | "coastal";

export const HAZARD_KEYS: HazardKey[] = [
  "earthquake",
  "flood",
  "landslide",
  "avalanche",
  "wildfire",
  "drought",
  "storm",
  "coastal",
];

export const HAZARD_META: Record<
  HazardKey,
  { color: string; soft: string; dark: string; icon: string; label: Loc }
> = {
  earthquake: {
    color: "#b8542f",
    soft: "#f6e3d8",
    dark: "#7d3620",
    icon: "wave",
    label: { en: "Earthquake", ka: "მიწისძვრა" },
  },
  flood: {
    color: "#2f6f8f",
    soft: "#dcebf1",
    dark: "#1d4a61",
    icon: "drop",
    label: { en: "Flood & flash flood", ka: "წყალდიდობა და მყისიერი წყალდიდობა" },
  },
  landslide: {
    color: "#8a6a2f",
    soft: "#efe6d2",
    dark: "#5e4720",
    icon: "slope",
    label: { en: "Landslide & mudflow", ka: "მეწყერი და ღვარცოფი" },
  },
  avalanche: {
    color: "#5c7597",
    soft: "#e3e9f1",
    dark: "#3e5069",
    icon: "mountain",
    label: { en: "Avalanche & heavy snow", ka: "ზვავი და თოვლი" },
  },
  wildfire: {
    color: "#c05a1c",
    soft: "#f8e4d1",
    dark: "#863c11",
    icon: "flame",
    label: { en: "Wildfire", ka: "ტყის ხანძარი" },
  },
  drought: {
    color: "#a88624",
    soft: "#f3ecd3",
    dark: "#745d16",
    icon: "sun",
    label: { en: "Drought & extreme heat", ka: "გვალვა და ექსტრემალური სიცხე" },
  },
  storm: {
    color: "#5c6e5b",
    soft: "#e4eae1",
    dark: "#3f4d3e",
    icon: "wind",
    label: { en: "Storm, wind & hail", ka: "ქარიშხალი, ქარი და სეტყვა" },
  },
  coastal: {
    color: "#3c7c78",
    soft: "#dcecea",
    dark: "#285652",
    icon: "coast",
    label: { en: "Coastal hazard", ka: "სანაპირო საფრთხე" },
  },
};

export type Severity = "catastrophic" | "major" | "moderate";

export interface Incident {
  id: string;
  title: Loc;
  hazard: HazardKey;
  secondary?: HazardKey[];
  startDate: string;
  endDate?: string;
  dateLabel: Loc;
  location: Loc;
  region: string;
  affectedRegions?: string[];
  municipalities?: string[];
  lat: number;
  lon: number;
  precision: "site" | "municipality" | "region";
  severity: Severity;
  casualties: Loc;
  affected: Loc;
  damage: Loc;
  summary: Loc;
  context: Loc;
  sources: string[];
  confidence: "documented" | "figures-disputed" | "partial";
  confidenceNote?: Loc;
}

export interface RegionInfo {
  id: string;
  name: string;
  nameKa: string;
  code: string;
  center: Loc;
  blurb: Loc;
  hazards: HazardKey[];
  incidents: string[];
  vulnerabilities: Loc[];
  preparedness: Loc[];
  officialNote?: Loc;
  dataCaveat?: Loc;
  lat?: number;
  lon?: number;
  partialData?: boolean;
}

export interface HazardZone {
  id: string;
  hazard: HazardKey;
  name: Loc;
  strength: "higher" | "moderate";
  polygon: [number, number][];
  labelAt: [number, number];
  note: Loc;
}

export interface Guide {
  id: HazardKey;
  tagline: Loc;
  why: Loc;
  signs: Loc[];
  before: Loc[];
  during: Loc[];
  after: Loc[];
  mistakes: Loc[];
  checklist: Loc[];
  vulnerable: Loc;
}

export interface Source {
  id: string;
  publisher: string;
  title: string;
  year: string;
  url: string;
  type: "official" | "scientific" | "database" | "news" | "encyclopedia" | "data";
  supports: string;
  language: string;
}

/* Match the projection used to generate src/data/geo.ts */
const [, , VB_W, VB_H] = GEO.viewBox.split(" ").map(Number);
const PAD = 18;
const B = GEO.bounds;
const mapWidthUnits = (B.maxLon - B.minLon) * B.cosLat;
const mapHeightUnits = B.maxLat - B.minLat;

export function project(lon: number, lat: number): [number, number] {
  const x = PAD + ((lon - B.minLon) * B.cosLat * (VB_W - PAD * 2)) / mapWidthUnits;
  const y = PAD + ((B.maxLat - lat) * (VB_H - PAD * 2)) / mapHeightUnits;
  return [x, y];
}

export function polygonPath(points: [number, number][]): string {
  return (
    points
      .map(([lon, lat], i) => {
        const [x, y] = project(lon, lat);
        return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ") + " Z"
  );
}

export function linePath(points: [number, number][]): string {
  const pts = points.map(([lon, lat]) => project(lon, lat));
  if (pts.length < 3) {
    return pts.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  }
  // Quadratic smoothing through midpoints keeps small vector datasets legible.
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 1; i < pts.length - 1; i++) {
    const [x, y] = pts[i];
    const [nx, ny] = pts[i + 1];
    d += ` Q${x.toFixed(1)},${y.toFixed(1)} ${((x + nx) / 2).toFixed(1)},${((y + ny) / 2).toFixed(1)}`;
  }
  const last = pts[pts.length - 1];
  d += ` L${last[0].toFixed(1)},${last[1].toFixed(1)}`;
  return d;
}

export const REGION_NAME_KA: Record<string, string> = {
  Abkhazia: "აფხაზეთი",
  Kakheti: "კახეთი",
  "Kvemo Kartli": "ქვემო ქართლი",
  Tbilisi: "თბილისი",
  "Mtskheta-Mtianeti": "მცხეთა-მთიანეთი",
  "Samtskhe–Javakheti": "სამცხე-ჯავახეთი",
  Adjara: "აჭარა",
  Guria: "გურია",
  "Shida Kartli": "შიდა ქართლი",
  Imereti: "იმერეთი",
  "Racha-Lechkhumi and Kvemo Svaneti": "რაჭა-ლეჩხუმი და ქვემო სვანეთი",
  "Samegrelo-Zemo Svaneti": "სამეგრელო-ზემო სვანეთი",
};

export const REGION_ID: Record<string, string> = {
  Abkhazia: "abkhazia",
  Kakheti: "kakheti",
  "Kvemo Kartli": "kvemo-kartli",
  Tbilisi: "tbilisi",
  "Mtskheta-Mtianeti": "mtskheta-mtianeti",
  "Samtskhe–Javakheti": "samtskhe-javakheti",
  Adjara: "adjara",
  Guria: "guria",
  "Shida Kartli": "shida-kartli",
  Imereti: "imereti",
  "Racha-Lechkhumi and Kvemo Svaneti": "racha",
  "Samegrelo-Zemo Svaneti": "samegrelo",
};
