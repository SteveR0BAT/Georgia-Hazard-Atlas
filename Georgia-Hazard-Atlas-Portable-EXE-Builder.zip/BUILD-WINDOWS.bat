@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build Hazard Atlas Georgia - Portable EXE

echo.
echo ============================================================
echo        HAZARD ATLAS GEORGIA - PORTABLE EXE BUILDER
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 goto no_node
where npm >nul 2>&1
if errorlevel 1 goto no_npm

echo [1/2] Installing the project and packaging dependencies...
call npm install
if errorlevel 1 goto failed

echo.
echo [2/2] Building the Windows portable executable...
call npm run build:portable
if errorlevel 1 goto failed

if not exist "release\Hazard-Atlas-Georgia-Portable.exe" goto missing_exe

echo.
echo ============================================================
echo BUILD COMPLETE!
echo.
echo Your single-file application is here:
echo %CD%\release\Hazard-Atlas-Georgia-Portable.exe
echo.
echo Send ONLY that EXE to the person who will use the atlas.
echo ============================================================
echo.
start "" "%CD%\release"
pause
exit /b 0

:no_node
echo ERROR: Node.js is not installed.
echo Install the current Node.js LTS version from https://nodejs.org/
echo Then run this file again.
start "" "https://nodejs.org/en/download"
pause
exit /b 1

:no_npm
echo ERROR: npm was not found. Reinstall Node.js LTS from https://nodejs.org/
echo Make sure the option to add Node.js to PATH is enabled.
pause
exit /b 1

:missing_exe
echo ERROR: The build command finished, but the expected portable EXE was not found.
echo Check the release folder and the error messages above.
echo If the build failed, send the contents of this window to the person helping you.
pause
exit /b 1

:failed
echo.
echo BUILD FAILED. The error messages above should identify the cause.
echo Check your internet connection, then run BUILD-WINDOWS.bat again.
pause
exit /b 1
