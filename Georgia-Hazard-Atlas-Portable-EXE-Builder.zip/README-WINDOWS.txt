HAZARD ATLAS GEORGIA — PORTABLE WINDOWS APP
============================================

WHAT THIS BUILDS
----------------
A single Windows x64 file named:
  Hazard-Atlas-Georgia-Portable.exe

The recipient does not need Node.js, a terminal, or an installation wizard.
They simply double-click the EXE. The app opens in its own desktop window.

HOW TO BUILD IT (ON THE WINDOWS PC THAT WILL CREATE THE EXE)
------------------------------------------------------------
1. Install Node.js LTS from https://nodejs.org/ if it is not already installed.
2. Extract this ZIP into a normal folder (not inside the ZIP viewer).
3. Double-click BUILD-WINDOWS.bat.
4. Let it install the required packages and finish the build.
5. The release folder opens automatically. It contains
   Hazard-Atlas-Georgia-Portable.exe.

WHAT TO SEND
------------
Send only:
  release\Hazard-Atlas-Georgia-Portable.exe

Do not send the source folder or the release folder contents as a bundle.
The portable target embeds the application and its runtime into one EXE.

NOTES
-----
- This builder targets 64-bit Windows.
- The map, guides, timeline, region profiles, and built-in data are bundled
  into the app. A network connection is needed only for external links and
  other online resources, not for the built-in atlas content.
- The language choice is saved locally on the computer where the app runs.
- On first launch, Windows SmartScreen may show an unknown-publisher warning
  because the app is not code-signed. This is normal for an unsigned personal
  build; only run it if you trust who provided it.
