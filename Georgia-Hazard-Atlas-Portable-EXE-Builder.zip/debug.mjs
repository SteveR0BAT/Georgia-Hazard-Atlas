import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
page.on('pageerror', e=>console.log('PAGEERROR', e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
const info = await page.evaluate(() => {
  const svg = document.querySelector('svg[role="application"]');
  const paths = [...svg.querySelectorAll('path')].slice(0,3).map(p=>p.getAttribute('d')?.slice(0,40));
  return { vb: svg.getAttribute('viewBox'), pathCount: svg.querySelectorAll('path').length, paths };
});
console.log(info);
await browser.close();
