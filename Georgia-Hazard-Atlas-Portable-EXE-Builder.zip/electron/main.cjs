const { app, BrowserWindow, shell } = require("electron");
const path = require("node:path");

const APP_ID = "ge.georgia.hazardatlas";
const isExternalUrl = (url) => /^https?:\/\//i.test(url);

app.setAppUserModelId(APP_ID);

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 960,
    minWidth: 900,
    minHeight: 620,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: "#142b25",
    title: "Hazard Atlas Georgia",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
    },
  });

  // Links to official agencies and external references open in the user's browser.
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (isExternalUrl(url)) {
      shell.openExternal(url).catch((error) => {
        console.error("Could not open external link:", error);
      });
    }
    return { action: "deny" };
  });

  window.webContents.on("will-navigate", (event, url) => {
    if (isExternalUrl(url)) {
      event.preventDefault();
      shell.openExternal(url).catch((error) => {
        console.error("Could not open external link:", error);
      });
    }
  });

  const entryFile = path.join(app.getAppPath(), "dist", "index.html");
  window.loadFile(entryFile);
  window.once("ready-to-show", () => window.show());
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
