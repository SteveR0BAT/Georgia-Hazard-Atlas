import { chromium } from 'playwright';
const browser = await chromium.launch();
const errors=[];
const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
page.on('console', m=>{ if(m.type()==='error') errors.push(m.text()) });
page.on('pageerror', e=>errors.push('PAGEERROR: '+e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(400);
// click a marker to verify detail panel
const marker = page.locator('svg g[role="button"][tabindex="0"]').first();
await marker.click({ force: true });
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-detail.png' });
// guides
await page.getByRole('button', { name: 'Preparedness' }).first().click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-guides.png' });
// check nav to timeline
await page.getByRole('button', { name: 'Timeline' }).first().click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-timeline.png' });
await page.getByRole('button', { name: 'Regions' }).first().click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-regions.png' });
await page.getByRole('button', { name: 'Sources' }).first().click();
await page.waitForTimeout(400);
await page.screenshot({ path: '/home/user/sandbox/qa-sources.png' });
// mobile map
const m = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
m.on('pageerror', e=>errors.push('MOBILE PAGEERROR: '+e.message));
await m.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await m.waitForTimeout(400);
await m.screenshot({ path: '/home/user/sandbox/qa-mobile.png', fullPage: false });
console.log('errors', errors.slice(0,8));
await browser.close();
