import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.getByRole('button', { name: 'Regions' }).first().click();
await page.waitForTimeout(400);
const info = await page.evaluate(() => {
  const svgs = [...document.querySelectorAll('svg')].filter(s=>s.getAttribute('viewBox')==='0 0 1000 508.6');
  return svgs.slice(0,3).map(s => {
    const path = s.querySelector('path');
    const bb = path?.getBBox?.();
    const r = s.getBoundingClientRect();
    return { cls: s.getAttribute('class'), rect: [r.width, r.height], d: path?.getAttribute('d')?.slice(0,30), bbox: bb ? [bb.x,bb.y,bb.width,bb.height] : null, fill: path?.getAttribute('fill'), cs: getComputedStyle(path).fill };
  });
});
console.log(JSON.stringify(info,null,1));
await browser.close();
